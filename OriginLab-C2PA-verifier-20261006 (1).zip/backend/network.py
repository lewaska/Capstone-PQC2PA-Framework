"""Public HTTPS only, with DNS pinning and redirect validation to prevent SSRF."""
import http.client
import ipaddress
import socket
import ssl
import time
from urllib.parse import urljoin, urlsplit

from fastapi import HTTPException


def public_target(url):
    try:
        target = urlsplit(url)
        if target.scheme != "https" or not target.hostname or target.username or target.password or target.port not in (None, 443):
            raise ValueError()
        host = target.hostname.encode("idna").decode()
        addresses = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
            raise ValueError()
        return target, host, addresses[0][4][0]
    except (ValueError, OSError, UnicodeError):
        raise HTTPException(400, "공개 HTTPS 파일 URL만 허용합니다. 로컬·내부 네트워크 주소는 사용할 수 없습니다.")


class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host, ip):
        super().__init__(host, timeout=15, context=ssl.create_default_context())
        self.pinned_ip = ip

    def connect(self):
        sock = socket.create_connection((self.pinned_ip, 443), timeout=self.timeout)
        try:
            self.sock = self._context.wrap_socket(sock, server_hostname=self.host)
        except Exception:
            sock.close()
            raise


def download(url, path, max_bytes):
    deadline = time.monotonic() + 60
    for _ in range(6):
        target, host, ip = public_target(url)
        conn = PinnedHTTPS(host, ip)
        try:
            conn.request("GET", (target.path or "/") + ("?" + target.query if target.query else ""), headers={
                "User-Agent": "C2PA-Lab/1.0", "Accept-Encoding": "identity"})
            response = conn.getresponse()
            if response.status in (301, 302, 303, 307, 308):
                location = response.getheader("Location")
                if not location:
                    raise HTTPException(400, "리디렉션 주소가 없습니다.")
                url = urljoin(url, location)
                continue
            if response.status != 200:
                raise HTTPException(400, f"파일 서버가 HTTP {response.status} 상태를 반환했습니다.")
            size = 0
            with open(path, "wb") as out:
                while True:
                    if time.monotonic() > deadline:
                        raise HTTPException(408, "파일 다운로드 제한 시간(60초)을 초과했습니다.")
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > max_bytes:
                        raise HTTPException(413, "파일은 최대 500 MB까지 허용합니다.")
                    out.write(chunk)
            if not size:
                raise HTTPException(400, "빈 파일입니다.")
            return url, response.getheader("Content-Type", "").split(";")[0]
        except (OSError, http.client.HTTPException) as exc:
            raise HTTPException(400, "파일을 가져오지 못했습니다. 주소와 HTTPS 연결을 확인해주세요.") from exc
        finally:
            conn.close()
    raise HTTPException(400, "리디렉션이 너무 많습니다.")
