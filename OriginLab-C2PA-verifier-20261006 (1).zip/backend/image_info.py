"""Bounded, image-only file inspection independent of C2PA metadata."""
import warnings
from pathlib import Path

from PIL import ExifTags, Image, UnidentifiedImageError


IMAGE_FORMATS = {
    "JPEG": ({".jpg", ".jpeg"}, "image/jpeg"),
    "PNG": ({".png"}, "image/png"),
    "WEBP": ({".webp"}, "image/webp"),
    "AVIF": ({".avif"}, "image/avif"),
}
EXIF_NAMES = {
    "Make", "Model", "LensModel", "DateTime", "DateTimeOriginal", "DateTimeDigitized",
    "Software", "Artist", "Copyright", "Orientation", "ExposureTime", "FNumber",
    "ISOSpeedRatings", "PhotographicSensitivity", "FocalLength", "Flash", "WhiteBalance",
    "ColorSpace", "ExposureProgram", "MeteringMode", "PixelXDimension", "PixelYDimension",
}
TEXT_NAMES = {"Title", "Description", "Comment", "Author", "Software", "Creation Time", "DateTime"}


class ImageInputError(ValueError):
    """A file is not a decodable image of its declared type."""


def _small_text(value):
    if isinstance(value, (bytes, bytearray)):
        return None
    if isinstance(value, (tuple, list)):
        value = ", ".join(str(part) for part in value[:8])
    elif not isinstance(value, (str, int, float, bool)):
        value = str(value)
    value = str(value).strip()
    return value[:240] if value else None


def inspect_image(path, filename, declared_mime=None):
    """Decode once to reject mislabeled or damaged images, then return safe facts."""
    suffix = Path(filename).suffix.lower()
    if suffix not in {ext for extensions, _ in IMAGE_FORMATS.values() for ext in extensions}:
        raise ImageInputError("JPG, PNG, WebP, AVIF 이미지만 검사할 수 있습니다.")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(path) as image:
                kind = image.format
                if kind not in IMAGE_FORMATS:
                    raise ImageInputError("지원하지 않는 이미지 형식입니다.")
                extensions, mime = IMAGE_FORMATS[kind]
                if suffix not in extensions or declared_mime not in (None, "", "application/octet-stream", mime):
                    raise ImageInputError("파일 이름, 형식, 실제 이미지 내용이 일치하지 않습니다.")
                image.verify()
            with Image.open(path) as image:
                exif = image.getexif()
                exif_values = dict(exif)
                try:
                    exif_values.update(exif.get_ifd(ExifTags.IFD.Exif))
                except (KeyError, TypeError, ValueError):
                    pass
                details = {}
                for tag, value in exif_values.items():
                    name = ExifTags.TAGS.get(tag, str(tag))
                    if name in EXIF_NAMES:
                        cleaned = _small_text(value)
                        if cleaned:
                            details[name] = cleaned
                for key, value in image.info.items():
                    if key in TEXT_NAMES and key not in details:
                        cleaned = _small_text(value)
                        if cleaned:
                            details[key] = cleaned
                dpi = image.info.get("dpi")
                return {
                    "format": kind, "mime": mime, "width": image.width, "height": image.height,
                    "mode": image.mode, "frames": getattr(image, "n_frames", 1),
                    "has_alpha": "A" in image.getbands() or "transparency" in image.info,
                    "has_icc_profile": bool(image.info.get("icc_profile")),
                    "gps_present": 34853 in exif_values,
                    "dpi": [_small_text(item) for item in dpi[:2]] if isinstance(dpi, (tuple, list)) else None,
                    "metadata": details,
                }
    except ImageInputError:
        raise
    except (UnidentifiedImageError, OSError, TypeError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ImageInputError("이미지를 읽을 수 없습니다. 파일이 손상되었거나 지원되지 않는 형식입니다.") from exc
