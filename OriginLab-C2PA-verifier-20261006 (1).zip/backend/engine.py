"""Real C2PA verification; never infer authenticity from metadata alone."""
import base64
import hashlib
import io
import json
import mimetypes
import os
import time
from pathlib import Path

import c2pa
from PIL import Image

from .image_info import ImageInputError, inspect_image

ROOT = Path(__file__).resolve().parents[1]
FORMATS = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".webp": "image/webp", ".tif": "image/tiff", ".tiff": "image/tiff",
    ".avif": "image/avif", ".heic": "image/heic", ".heif": "image/heif",
    ".gif": "image/gif", ".svg": "image/svg+xml", ".dng": "image/x-adobe-dng",
    ".mp4": "video/mp4", ".mov": "video/quicktime", ".avi": "video/x-msvideo",
    ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4",
    ".pdf": "application/pdf", ".c2pa": "application/c2pa"}


def checks_from_store(store):
    checks = []
    def visit(value, scope="activeManifest"):
        if not isinstance(value, dict):
            return
        for kind in ("success", "informational", "failure"):
            for entry in value.get(kind, []):
                checks.append({**entry, "kind": kind, "scope": scope})
        for key, child in value.items():
            if key in ("success", "informational", "failure"):
                continue
            if isinstance(child, dict):
                visit(child, key)
            elif isinstance(child, list):
                for item in child:
                    visit(item, key)
    visit(store.get("validation_results", {}))
    for entry in store.get("validation_status", []):
        if not any(c.get("code") == entry.get("code") and c.get("url") == entry.get("url") for c in checks):
            checks.append({**entry, "kind": "failure", "scope": "legacy"})
    return checks


def inspect_asset(path: str, name: str, trust_profile: str):
    started = time.perf_counter()
    source = Path(path)
    mime = FORMATS.get(Path(name).suffix.lower(), mimetypes.guess_type(name)[0])
    digest = hashlib.sha256()
    sha3_digest = hashlib.sha3_256()
    with source.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
            sha3_digest.update(chunk)
    result = {"filename": name, "size": source.stat().st_size, "mime": mime,
        "sha256": digest.hexdigest(), "sha3_256": sha3_digest.hexdigest(), "trust_profile": trust_profile,
        "state": "NoManifest", "store": {}, "checks": [], "actions": [],
        "ingredients": [], "ai": "unknown", "thumbnail": None,
        "network_policy": {"remote_manifests": False, "ocsp": False}}
    settings = {"verify": {"verify_after_reading": True, "verify_trust": True,
        "verify_timestamp_trust": True, "remote_manifest_fetch": False, "ocsp_fetch": False},
        "core": {"allowed_network_hosts": []}}
    if trust_profile == "lab":
        cert_path = ROOT / "samples" / "lab-root.pem"
        settings["trust"] = {"user_anchors": cert_path.read_text()}
    try:
        with c2pa.Context.from_dict(settings) as context:
            with source.open("rb") as stream, c2pa.Reader(mime, stream, context=context) as reader:
                store = json.loads(reader.json())
                result["store"] = store
                result["state"] = store.get("validation_state") or "Unknown"
                result["checks"] = checks_from_store(store)
                active = store.get("manifests", {}).get(store.get("active_manifest"), {})
                result["signature"] = active.get("signature_info", {})
                result["software"] = active.get("claim_generator_info", [])
                result["ingredients"] = active.get("ingredients", [])
                result["manifest_count"] = len(store.get("manifests", {}))
                for assertion in active.get("assertions", []):
                    if assertion.get("label", "").startswith("c2pa.actions"):
                        result["actions"].extend(assertion.get("data", {}).get("actions", []))
                sources = [a.get("digitalSourceType", "") for a in result["actions"]]
                if any(s.endswith(("trainedAlgorithmicMedia", "compositeWithTrainedAlgorithmicMedia", "algorithmicallyEnhanced")) for s in sources):
                    result["ai"] = "declared"
                thumb = active.get("thumbnail", {})
                if thumb.get("identifier") and thumb.get("format") in ("image/jpeg", "image/png", "image/webp"):
                    try:
                        output = io.BytesIO()
                        reader.resource_to_stream(thumb["identifier"], output)
                        if len(output.getvalue()) <= 2 * 1024 * 1024:
                            result["thumbnail"] = f"data:{thumb['format']};base64," + base64.b64encode(output.getvalue()).decode()
                    except c2pa.C2paError:
                        pass
                result["embedded"] = reader.is_embedded()
    except c2pa.C2paError as exc:
        message = str(exc)
        if "ManifestNotFound" in message or "JumbfNotFound" in message or "no JUMBF" in message:
            result["state"] = "NoManifest"
        elif "RemoteManifest" in message or "remote manifest" in message.lower():
            result["state"] = "RemoteUnavailable"
            result["error"] = "외부 매니페스트가 필요합니다. 현재 검증 정책은 외부 매니페스트 요청을 차단합니다."
        else:
            result["state"] = "Error"
            result["error"] = message[:1500]
    # Do not display a successful status when any manifest in the chain failed.
    if any(c["kind"] == "failure" for c in result["checks"]) and result["state"] == "Trusted":
        result["state"] = "Invalid"
    try:
        result["image_info"] = inspect_image(source, name)
    except ImageInputError:
        pass
    try:
        with Image.open(source) as image:
            result["dimensions"] = [image.width, image.height]
            if not result["thumbnail"]:
                image.thumbnail((720, 480))
                buffer = io.BytesIO()
                image.convert("RGB").save(buffer, format="JPEG", quality=80)
                result["thumbnail"] = "data:image/jpeg;base64," + base64.b64encode(buffer.getvalue()).decode()
    except (OSError, ValueError, Image.DecompressionBombError):
        pass
    result["elapsed_ms"] = round((time.perf_counter() - started) * 1000)
    return result
