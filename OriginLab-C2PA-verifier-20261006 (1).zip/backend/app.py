import asyncio
import hashlib
import html
import json
import os
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlsplit

from fastapi import FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool
from starlette.middleware.trustedhost import TrustedHostMiddleware

from . import storage
from .engine import FORMATS
from .image_info import IMAGE_FORMATS, ImageInputError, inspect_image
from .network import download

ROOT = Path(__file__).resolve().parents[1]
MAX_BYTES = 500 * 1024 * 1024
IMAGE_MAX_BYTES = 20 * 1024 * 1024
IMAGE_SUFFIXES = {ext for extensions, _ in IMAGE_FORMATS.values() for ext in extensions}
SAMPLES = {
    "signed": {"filename": "signed.jpg", "title": "정상 서명", "description": "우리 실험용 인증서로 서명한 이미지"},
    "tampered": {"filename": "tampered.jpg", "title": "변조된 파일", "description": "서명 후 이미지 픽셀을 변경한 이미지"},
    "unsigned": {"filename": "unsigned.jpg", "title": "C2PA 없음", "description": "C2PA 매니페스트가 없는 이미지"},
    "ai": {"filename": "ai-han-river-sunrise.png", "title": "AI 생성 선언", "description": "C2PA에 AI 생성 선언이 포함된 이미지"},
}
app = FastAPI(title="C2PA Lab API", version="1.0.0", description="C2PA SDK 기반 로컬 실험용 검증 API", docs_url=None, redoc_url=None)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "[::1]", "testserver"])
verification_slots = asyncio.Semaphore(2)


class BodyLimit:
    def __init__(self, app):
        self.app = app
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        size = 0
        async def limited_receive():
            nonlocal size
            message = await receive()
            size += len(message.get("body", b""))
            if size > MAX_BYTES + 2 * 1024 * 1024:
                raise HTTPException(413, "요청이 최대 파일 크기 500 MB를 초과했습니다.")
            return message
        await self.app(scope, limited_receive, send)


app.add_middleware(BodyLimit)


@app.middleware("http")
async def security(request, call_next):
    if request.method in ("POST", "DELETE", "PUT", "PATCH"):
        origin = request.headers.get("origin")
        # A mounted local viewer has a root_path, but Origin never includes it.
        expected_origin = f"{request.url.scheme}://{request.headers.get('host')}"
        if origin and origin != expected_origin:
            return Response("Cross-origin writes are blocked", status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; frame-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    if request.url.path.startswith(("/api", "/engine/api")):
        response.headers["Cache-Control"] = "no-store"
    return response


def profile(value):
    if value not in ("standard", "lab"):
        raise HTTPException(400, "알 수 없는 신뢰 정책입니다.")
    return value


def supported(name):
    if Path(name).suffix.lower() not in FORMATS:
        raise HTTPException(415, "지원하지 않는 확장자입니다. 이미지·영상·오디오·PDF 파일을 선택해주세요.")


async def verify(path, name, trust, source_url=None, asset_id=None):
    async with verification_slots:
        process = await asyncio.create_subprocess_exec(sys.executable, "-m", "backend.worker", path, name, profile(trust),
            cwd=ROOT, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            output, error = await asyncio.wait_for(process.communicate(), timeout=90)
        except (asyncio.TimeoutError, asyncio.CancelledError) as exc:
            process.kill()
            await process.wait()
            if isinstance(exc, asyncio.CancelledError):
                raise
            raise HTTPException(408, "C2PA 분석 제한 시간(90초)을 초과했습니다.")
        if process.returncode:
            raise HTTPException(422, "파일 분석에 실패했습니다. 손상된 파일이거나 지원되지 않는 형식일 수 있습니다.")
        result = json.loads(output)
    result.update({"id": uuid.uuid4().hex, "created_at": datetime.now(timezone.utc).isoformat(),
                   "source_url": source_url, "asset_id": asset_id})
    await run_in_threadpool(storage.save, result)
    return result


@app.get("/api/health")
def health():
    from importlib.metadata import version
    return {"status": "ok", "sdk": "c2pa-python", "sdk_version": version("c2pa-python"), "max_bytes": MAX_BYTES,
        "image_max_bytes": IMAGE_MAX_BYTES, "image_formats": sorted(IMAGE_SUFFIXES),
        "ai_generation": False, "policy": "offline validation; remote manifests and OCSP disabled"}


@app.post("/api/verify-image")
async def verify_image(file: UploadFile = File(...), trust_profile: str = Form("standard")):
    """Image-only viewer endpoint; never retain the uploaded original."""
    try:
        name = Path((file.filename or "image").replace("\\", "/")).name[:200]
        if Path(name).suffix.lower() not in IMAGE_SUFFIXES:
            raise HTTPException(415, "JPG, PNG, WebP, AVIF 이미지만 검사할 수 있습니다.")
        profile(trust_profile)
        with tempfile.TemporaryDirectory(prefix="c2pa-image-") as tmp:
            path = Path(tmp) / ("asset" + Path(name).suffix.lower())
            size = 0
            with path.open("wb") as out:
                while chunk := await file.read(1024 * 1024):
                    size += len(chunk)
                    if size > IMAGE_MAX_BYTES:
                        raise HTTPException(413, "이미지는 최대 20 MB까지 허용합니다.")
                    out.write(chunk)
            if not size:
                raise HTTPException(400, "빈 파일은 분석할 수 없습니다.")
            try:
                inspect_image(path, name, file.content_type)
            except ImageInputError as exc:
                raise HTTPException(422, str(exc)) from exc
            return await verify(str(path), name, trust_profile)
    finally:
        await file.close()


@app.post("/api/verify")
async def upload(file: UploadFile = File(...), trust_profile: str = Form("standard")):
    try:
        name = Path((file.filename or "file").replace("\\", "/")).name[:200]
        supported(name)
        profile(trust_profile)
        with tempfile.TemporaryDirectory(prefix="c2pa-lab-") as tmp:
            path = Path(tmp) / ("asset" + Path(name).suffix.lower())
            size = 0
            with path.open("wb") as out:
                while chunk := await file.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise HTTPException(413, "파일은 최대 500 MB까지 허용합니다.")
                    out.write(chunk)
            if not size:
                raise HTTPException(400, "빈 파일은 분석할 수 없습니다.")
            return await verify(str(path), name, trust_profile)
    finally:
        await file.close()


class URLRequest(BaseModel):
    url: str = Field(min_length=8, max_length=4096)
    trust_profile: str = "standard"


@app.post("/api/verify-url")
async def verify_url(body: URLRequest):
    profile(body.trust_profile)
    with tempfile.TemporaryDirectory(prefix="c2pa-url-") as tmp:
        path = str(Path(tmp) / "asset")
        url, mime = await run_in_threadpool(download, body.url, path, MAX_BYTES)
        name = Path(unquote(urlsplit(url).path)).name[:200] or "remote-file"
        if Path(name).suffix.lower() not in FORMATS:
            ext = next((ext for ext, content_type in FORMATS.items() if content_type == mime), None)
            if not ext:
                raise HTTPException(415, "URL은 지원하는 미디어 파일을 직접 가리켜야 합니다.")
            name += ext
        return await verify(path, name, body.trust_profile, body.url)


@app.get("/api/samples")
def samples():
    return [{"id": key, **value} for key, value in SAMPLES.items()]


@app.get("/api/samples/{sample_id}/file")
def sample_file(sample_id: str):
    if sample_id not in SAMPLES:
        raise HTTPException(404, "샘플을 찾을 수 없습니다.")
    name = SAMPLES[sample_id]["filename"]
    return FileResponse(ROOT / "samples" / name, media_type=FORMATS[Path(name).suffix.lower()])


@app.post("/api/samples/{sample_id}/verify")
async def verify_sample(sample_id: str, trust_profile: str = "lab"):
    if sample_id not in SAMPLES:
        raise HTTPException(404, "샘플을 찾을 수 없습니다.")
    name = SAMPLES[sample_id]["filename"]
    result = await verify(str(ROOT / "samples" / name), name, trust_profile)
    return result


@app.post("/api/assets", status_code=201)
async def register_asset(file: UploadFile = File(...), label: str = Form(""), source: str = Form(""),
                         notes: str = Form(""), tags: str = Form("")):
    """Keep an immutable original and its searchable metadata for later verification."""
    name = Path((file.filename or "file").replace("\\", "/")).name[:200]
    supported(name)
    if len(label) > 200 or len(source) > 500 or len(notes) > 2000 or len(tags) > 500:
        raise HTTPException(400, "자료 설명이 허용된 길이를 초과했습니다.")
    tag_list = list(dict.fromkeys(tag.strip() for tag in tags.split(",") if tag.strip()))
    if len(tag_list) > 20 or any(len(tag) > 40 for tag in tag_list):
        raise HTTPException(400, "태그는 최대 20개, 각각 40자까지 입력할 수 있습니다.")
    storage.ASSET_DIR.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        digest = hashlib.sha256()
        size = 0
        with tempfile.NamedTemporaryFile(prefix=".incoming-", dir=storage.ASSET_DIR, delete=False) as out:
            temp_path = Path(out.name)
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_BYTES:
                    raise HTTPException(413, "파일은 최대 500 MB까지 허용합니다.")
                digest.update(chunk)
                out.write(chunk)
        if not size:
            raise HTTPException(400, "빈 파일은 등록할 수 없습니다.")
        asset, duplicate = await run_in_threadpool(storage.register_asset, temp_path,
            filename=name, sha256=digest.hexdigest(), size=size, mime=FORMATS[Path(name).suffix.lower()],
            label=label.strip(), source=source.strip(), notes=notes.strip(), tags=tag_list)
        return {"asset": asset, "duplicate": duplicate}
    finally:
        await file.close()
        if temp_path:
            temp_path.unlink(missing_ok=True)


@app.get("/api/assets")
def list_assets(q: str = Query("", max_length=200), limit: int = Query(100, ge=1, le=200)):
    return storage.list_assets(q=q.strip(), limit=limit)


def require_asset(asset_id):
    asset = storage.get_asset(asset_id)
    if not asset:
        raise HTTPException(404, "등록된 자료를 찾을 수 없습니다.")
    return asset


@app.get("/api/assets/{asset_id}")
def get_asset(asset_id: str):
    return require_asset(asset_id)


@app.get("/api/assets/{asset_id}/download")
def download_asset(asset_id: str):
    asset = require_asset(asset_id)
    path = storage.asset_path(asset)
    if not path.is_file():
        raise HTTPException(410, "원본 파일이 저장소에 없습니다. 자료를 다시 등록해주세요.")
    return FileResponse(path, media_type="application/octet-stream", filename=asset["filename"], content_disposition_type="attachment")


@app.post("/api/assets/{asset_id}/verify")
async def verify_asset(asset_id: str, trust_profile: str = "standard"):
    asset = await run_in_threadpool(require_asset, asset_id)
    profile(trust_profile)
    path = storage.asset_path(asset)
    if not path.is_file():
        raise HTTPException(410, "원본 파일이 저장소에 없습니다. 자료를 다시 등록해주세요.")
    return await verify(str(path), asset["filename"], trust_profile, asset_id=asset_id)


@app.get("/api/history")
def history(q: str = Query("", max_length=200), state: str = Query("", max_length=40),
            trust_profile: str = Query("", max_length=40), asset_id: str = Query("", max_length=64),
            limit: int = Query(50, ge=1, le=200)):
    return storage.history(limit=limit, q=q.strip(), state=state, trust_profile=trust_profile, asset_id=asset_id)


@app.get("/api/reports/{report_id}")
def report(report_id: str):
    value = storage.get(report_id)
    if not value:
        raise HTTPException(404, "보고서가 없거나 삭제되었습니다.")
    return value


@app.delete("/api/reports/{report_id}")
def delete_report(report_id: str):
    if not storage.delete(report_id):
        raise HTTPException(404, "보고서를 찾을 수 없습니다.")
    return {"deleted": True}


@app.get("/api/reports/{report_id}/download")
def download_report(report_id: str, format: str = "json"):
    value = report(report_id)
    if format == "json":
        return Response(json.dumps(value, ensure_ascii=False, indent=2), media_type="application/json",
            headers={"Content-Disposition": f'attachment; filename="c2pa-report-{report_id}.json"'})
    if format == "html":
        # Escaping all user/manifest content makes this standalone report safe to open.
        text = html.escape(json.dumps(value, ensure_ascii=False, indent=2))
        return HTMLResponse(f'<!doctype html><html lang="ko"><meta charset="utf-8"><title>C2PA Lab Report</title>'
            f'<h1>C2PA Lab 검증 보고서</h1><p>상태: {html.escape(value["state"])}</p>'
            '<p>서명 검증 결과는 콘텐츠의 사실 여부를 보증하지 않습니다. 외부 매니페스트와 OCSP는 조회하지 않았습니다.</p>'
            f'<pre>{text}</pre></html>', headers={"Content-Disposition": f'attachment; filename="c2pa-report-{report_id}.html"'})
    raise HTTPException(400, "json 또는 html 형식을 선택해주세요.")


app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


@app.get("/")
def index():
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/docs", include_in_schema=False)
def docs():
    return FileResponse(ROOT / "static" / "docs.html")
