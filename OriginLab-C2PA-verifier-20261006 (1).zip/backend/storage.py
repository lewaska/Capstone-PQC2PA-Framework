"""Local research records. The database stores metadata; originals stay on disk."""
import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_DATA = Path(__file__).resolve().parents[1] / "data"
DEFAULT_DB = DEFAULT_DATA / "lab.sqlite3"
ASSET_DIR = DEFAULT_DATA / "assets"
SUMMARY_KEYS = ("id", "filename", "created_at", "state", "size", "mime", "dimensions",
                "sha256", "sha3_256", "image_info", "trust_profile", "elapsed_ms",
                "asset_id", "signer", "source_url")


def connect():
    path = Path(os.environ.get("C2PA_DB", DEFAULT_DB))
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("CREATE TABLE IF NOT EXISTS reports (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)")
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(reports)")}
    new_columns = {"filename": "TEXT", "state": "TEXT", "sha256": "TEXT", "trust_profile": "TEXT",
                   "signer": "TEXT", "source_url": "TEXT", "asset_id": "TEXT"}
    if any(name not in columns for name in new_columns):
        for name, kind in new_columns.items():
            if name not in columns:
                conn.execute(f"ALTER TABLE reports ADD COLUMN {name} {kind}")
        # Preserve existing reports when upgrading from the original JSON-only schema.
        for row in conn.execute("SELECT id, payload FROM reports"):
            data = json.loads(row["payload"])
            signature = data.get("signature") or {}
            conn.execute("UPDATE reports SET filename=?, state=?, sha256=?, trust_profile=?, signer=?, source_url=?, asset_id=? WHERE id=?",
                         (data.get("filename"), data.get("state"), data.get("sha256"), data.get("trust_profile"),
                          signature.get("common_name") or signature.get("issuer"), data.get("source_url"),
                          data.get("asset_id"), row["id"]))
        conn.execute("CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at DESC)")
        conn.commit()
    conn.execute("""CREATE TABLE IF NOT EXISTS assets (
        id TEXT PRIMARY KEY, sha256 TEXT NOT NULL UNIQUE, filename TEXT NOT NULL, extension TEXT NOT NULL,
        mime TEXT NOT NULL, size INTEGER NOT NULL, label TEXT NOT NULL, source TEXT NOT NULL,
        notes TEXT NOT NULL, tags TEXT NOT NULL, created_at TEXT NOT NULL
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_assets_created ON assets(created_at DESC)")
    conn.commit()
    return conn


def save(result):
    signature = result.get("signature") or {}
    with connect() as conn:
        conn.execute("""INSERT INTO reports
            (id, created_at, payload, filename, state, sha256, trust_profile, signer, source_url, asset_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (result["id"], result["created_at"], json.dumps(result, ensure_ascii=False),
             result.get("filename"), result.get("state"), result.get("sha256"), result.get("trust_profile"),
             signature.get("common_name") or signature.get("issuer"), result.get("source_url"), result.get("asset_id")))


def get(report_id):
    with connect() as conn:
        row = conn.execute("SELECT payload FROM reports WHERE id = ?", (report_id,)).fetchone()
    return json.loads(row["payload"]) if row else None


def history(limit=50, q="", state="", trust_profile="", asset_id=""):
    conditions, values = [], []
    if q:
        conditions.append("(instr(lower(coalesce(filename,'')),lower(?))>0 OR instr(lower(coalesce(sha256,'')),lower(?))>0 OR instr(lower(coalesce(signer,'')),lower(?))>0 OR instr(lower(coalesce(source_url,'')),lower(?))>0)")
        values.extend([q] * 4)
    if state:
        conditions.append("state = ?")
        values.append(state)
    if trust_profile:
        conditions.append("trust_profile = ?")
        values.append(trust_profile)
    if asset_id:
        conditions.append("asset_id = ?")
        values.append(asset_id)
    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    with connect() as conn:
        rows = conn.execute("SELECT payload FROM reports" + where + " ORDER BY created_at DESC LIMIT ?",
                            [*values, limit]).fetchall()
    return [{key: data.get(key) if key != "signer" else ((data.get("signature") or {}).get("common_name") or (data.get("signature") or {}).get("issuer"))
             for key in SUMMARY_KEYS} for row in rows for data in [json.loads(row["payload"])]]


def delete(report_id):
    with connect() as conn:
        return conn.execute("DELETE FROM reports WHERE id = ?", (report_id,)).rowcount > 0


def _asset(row):
    if not row:
        return None
    data = dict(row)
    data["tags"] = json.loads(data["tags"])
    return data


def get_asset(asset_id):
    with connect() as conn:
        return _asset(conn.execute("SELECT * FROM assets WHERE id = ?", (asset_id,)).fetchone())


def list_assets(q="", limit=100):
    where = " WHERE instr(lower(filename),lower(?))>0 OR instr(lower(label),lower(?))>0 OR instr(lower(source),lower(?))>0 OR instr(lower(tags),lower(?))>0 OR instr(lower(sha256),lower(?))>0" if q else ""
    parameters = [q] * 5 if q else []
    with connect() as conn:
        rows = conn.execute("""SELECT assets.*,
            (SELECT COUNT(*) FROM reports WHERE asset_id = assets.id) AS verification_count,
            (SELECT state FROM reports WHERE asset_id = assets.id ORDER BY created_at DESC LIMIT 1) AS latest_state
            FROM assets""" + where + " ORDER BY created_at DESC LIMIT ?", [*parameters, limit]).fetchall()
    return [_asset(row) for row in rows]


def asset_path(asset):
    return ASSET_DIR / (asset["sha256"] + asset["extension"])


def register_asset(temp_path, *, filename, sha256, size, mime, label="", source="", notes="", tags=None):
    """Deduplicate by content hash. Existing metadata is never silently replaced."""
    tags = tags or []
    ASSET_DIR.mkdir(parents=True, exist_ok=True)
    extension = Path(filename).suffix.lower()
    with connect() as conn:
        existing = conn.execute("SELECT * FROM assets WHERE sha256 = ?", (sha256,)).fetchone()
        if existing:
            return _asset(existing), True
        record = (uuid.uuid4().hex, sha256, filename, extension, mime, size, label or filename,
                  source, notes, json.dumps(tags, ensure_ascii=False), datetime.now(timezone.utc).isoformat())
        path = ASSET_DIR / (sha256 + extension)
        try:
            os.link(temp_path, path)
        except FileExistsError:
            pass
        try:
            conn.execute("INSERT INTO assets VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", record)
            conn.commit()
        except sqlite3.IntegrityError:
            conn.rollback()
            existing = conn.execute("SELECT * FROM assets WHERE sha256 = ?", (sha256,)).fetchone()
            if existing:
                return _asset(existing), True
            raise
        except Exception:
            path.unlink(missing_ok=True)
            raise
    return get_asset(record[0]), False
