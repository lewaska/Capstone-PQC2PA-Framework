"""Isolate native decoding from the web process, with resource/time limits."""
import json
import sys

if __name__ == "__main__":
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (75, 75))
        resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))
    except (ImportError, ValueError):
        pass
    from .engine import inspect_asset
    print(json.dumps(inspect_asset(*sys.argv[1:4]), ensure_ascii=False))
