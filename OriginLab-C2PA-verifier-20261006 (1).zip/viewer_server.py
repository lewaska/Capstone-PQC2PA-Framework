"""Serve the Origin Lab viewer and the existing C2PA verifier on one local origin."""
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from backend.app import app as verifier


ROOT = Path(__file__).resolve().parent
FRONTEND = ROOT / "pqc-c2pa-web"
app = FastAPI(title="Origin Lab Viewer", docs_url=None, redoc_url=None)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "[::1]", "testserver"])


def viewer_file(name: str, media_type: str):
    return FileResponse(FRONTEND / name, media_type=media_type, headers={"Cache-Control": "no-store"})


@app.get("/")
def index():
    return viewer_file("index.html", "text/html")


@app.get("/styles.css")
def styles():
    return viewer_file("styles.css", "text/css")


@app.get("/app.js")
def script():
    return viewer_file("app.js", "text/javascript")


@app.get("/resources.js")
def resources():
    return viewer_file("resources.js", "text/javascript")


app.mount("/assets", StaticFiles(directory=FRONTEND / "assets"), name="viewer-assets")
app.mount("/engine", verifier)
