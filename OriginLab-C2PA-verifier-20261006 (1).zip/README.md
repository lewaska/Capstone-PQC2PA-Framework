# C2PA Lab

C2PA 콘텐츠 출처 검증을 위한 로컬 실험용 웹사이트입니다. 간단한 한국어 프론트엔드와 Python/FastAPI 백엔드, 공식 `c2pa-python` 네이티브 SDK를 사용합니다. 결과를 흉내 내는 데모가 아니라 실제 파일 서명과 해시를 검증합니다.

## Origin Lab 이미지 검증 화면

이미지 전용 파란색 화면은 프로젝트 최상위에서 `bash run-viewer.sh`로 실행하고 <http://127.0.0.1:8765/>에서 엽니다. 이 명령은 `pqc-c2pa-web/` 화면과 기존 검증 API를 같은 주소에 연결합니다. 검사 결과, 상세 SDK 코드·Manifest JSON, 결과물, 실험 기록을 제공합니다. 기존 `run.sh`의 다중 매체 연구 화면과 API도 계속 사용할 수 있습니다. 이미지 화면의 사용법과 현재 구현 범위는 [웹 README](pqc-c2pa-web/README.md)를 참고하세요.

## 실행

Python 3.10 이상이 필요합니다. 이 작업 환경에는 가상환경과 의존성 설치가 완료되어 있습니다.

```bash
bash run.sh
```

브라우저에서 <http://127.0.0.1:8000>을 엽니다. API 문서는 <http://127.0.0.1:8000/docs>입니다. 이미 실행된 서버가 있다면 브라우저에서 바로 접속하면 됩니다.

새 컴퓨터에서는 다음과 같이 설치합니다.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
bash run.sh
```

다른 포트는 `C2PA_PORT=8001 bash run.sh`로 지정합니다. 서버는 기본적으로 `127.0.0.1`에만 바인딩합니다. Windows에서는 가상환경을 만든 뒤 `.venv\Scripts\python -m pip install -r requirements.txt`와 `.venv\Scripts\python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000`을 실행합니다.

## 구현한 기능

- 드래그 앤 드롭 및 파일 선택, 최대 10개 파일의 순차 검증, 파일당 500 MB 제한.
- 공개 HTTPS 파일 URL 검증, `/?url=URL_ENCODED_FILE_URL` 자동 검증, 신뢰 정책을 포함한 URL 재검증 링크 복사.
- C2PA 서명, 콘텐츠 해시, 인증서 신뢰, 타임스탬프 관련 검증 결과 표시.
- 서명자, 제작 도구, 서명 알고리즘, 서명 시간, AI 생성·편집 선언 조회.
- 편집 작업 이력, 재료(ingredients), 연결된 매니페스트 출처 조회.
- Raw JSON / 지연 렌더링 Tree 보기, JSON 키·값 검색, 복사, 원본 매니페스트 다운로드.
- SHA-256·검증 시간·신뢰 정책을 포함하는 JSON 및 독립형 HTML 보고서.
- SQLite 실험 기록 조회 및 삭제, `/?report=REPORT_ID`로 같은 로컬 서버의 저장된 결과 열기.
- 파일명·SHA-256·서명자·URL과 검증 상태·신뢰 정책으로 실험 기록 검색.
- 연구 자료 원본을 로컬 저장소에 등록, SHA-256 중복 감지, 자료명·수집 출처·태그·메모 저장, 원본 다운로드 및 반복 검증.
- 정상 서명, 픽셀 변조, 매니페스트 없음의 실제 JPEG 샘플.
- 기본 SDK 신뢰 목록과 실험용 CA를 추가하는 정책 비교.
- 이미지 썸네일; 직접 업로드한 영상·오디오는 해당 결과에서 브라우저 미리보기.
- WebMCP를 지원하는 브라우저에서 공개 HTTPS URL 분석 도구 등록.

JPEG, PNG, WebP, TIFF, AVIF, HEIC/HEIF, GIF, SVG, DNG, MP4, MOV, AVI, MP3, WAV, M4A, PDF, C2PA 확장자를 입력으로 허용합니다. 실제 파싱 가능 여부는 고정한 공식 SDK 버전과 파일 구조에 따라 다릅니다. JPEG/PNG/PDF 기본 흐름을 자동 검증했으며 모든 코덱·대용량 파일의 동작을 보증하는 것은 아닙니다. 이미지 썸네일은 Pillow가 읽을 수 있는 형식 또는 매니페스트의 내장 썸네일에서 제공합니다. PDF 본문 렌더링은 포함하지 않습니다.

## 참고 사이트와의 차이

[c2paviewer.com](https://c2paviewer.com/)의 파일·URL 검증, 서명 및 작업 이력, 출처 조회, JSON 검사, 보고서 사용 흐름을 참고했습니다. UI와 콘텐츠는 별도로 작성했습니다. 참고 사이트는 브라우저에서 처리하지만 이 프로젝트는 요청한 실험용 백엔드 API에서 처리합니다. 기사, 홍보 페이지, 외부 서비스 설명 페이지는 검증 프레임워크 범위에서 제외했습니다.

일회성 파일 검증은 임시 파일을 만들고 분석 완료/실패 시 삭제합니다. 자료 보관함에 등록한 파일은 원본을 `data/assets/`에 보관하고, 자료 설명과 결과 매니페스트·작은 미리보기는 `data/lab.sqlite3`에 저장합니다. 원본은 해시로 중복 식별하며 검증 기록과 연결됩니다. 영상·오디오 원본의 브라우저 미리보기는 일회성 업로드의 해당 브라우저 세션에 한정됩니다. 보고서 링크는 이 로컬 서버가 실행 중이고 데이터가 남아있을 때 사용할 수 있습니다. HTML/JSON 파일로 내보내면 다른 컴퓨터에서도 확인할 수 있습니다.

## 연구 자료 관리 흐름

1. **자료 보관함**에서 원본 파일을 등록하고 자료명, 수집 출처, 태그, 메모를 입력합니다. 여러 파일을 동시에 선택하면 공통 출처·태그·메모를 적용하고 각 파일명을 자료명으로 사용합니다.
2. 등록된 자료는 파일명·자료명·출처·태그·SHA-256으로 검색합니다. 같은 내용의 파일은 중복 저장하지 않으며, 기존 자료의 설명을 몰래 덮어쓰지 않습니다.
3. 자료별 신뢰 정책을 선택하고 **저장된 원본 검증**을 누르면 원본을 다시 업로드하지 않고 재검증합니다. 결과는 해당 자료와 연결됩니다.
4. **실험 기록**에서 파일명·해시·서명자·URL 검색과 상태·정책 필터를 함께 사용합니다. 화면에는 최근 검색 결과 최대 200건을 표시합니다.

기존 기록은 DB 변경 시 자동으로 검색용 열이 채워지며 삭제되지 않습니다. 원본은 자료 보관함에 명시적으로 등록한 경우에만 보관됩니다. 등록된 원본의 삭제 기능은 현재 제공하지 않습니다. 로컬 개발용 서비스이며 로그인·사용자별 권한 관리가 없으므로 다른 사람이 접속하는 주소로 열어서는 안 됩니다.

## 검증 정책과 해석

검증은 `Context`마다 설정을 분리합니다. 서명·타임스탬프 신뢰 검증을 활성화하고 외부 매니페스트 및 OCSP 네트워크 요청은 차단합니다. 기본 정책은 설치된 SDK의 신뢰 설정을 사용하며, 실시간 최신 C2PA 인증 기관 목록을 동기화하지 않습니다. 모든 발급자의 인증서가 기본 설정에서 신뢰되는 것은 아닙니다. 인증서 폐기 여부는 온라인으로 확인하지 않습니다. 원격 매니페스트만 가진 파일은 완전한 검증이 불가능할 수 있습니다.

| 상태 | 의미 |
| --- | --- |
| Trusted | 선택한 신뢰 정책에서 신뢰된 서명이며 무결성이 검증됨 |
| Valid | 암호학적으로 유효하지만 서명 인증서의 신뢰가 확인되지 않을 수 있음 |
| Invalid | 무결성·서명 등 검증 실패; 개별 코드를 확인해야 함 |
| NoManifest | 내장 C2PA 매니페스트를 찾지 못함 |
| RemoteUnavailable / Error | 원격 매니페스트 필요 또는 파싱 오류 등 분석 불가 |

`signingCredential.untrusted`와 `assertion.dataHash.mismatch`는 서로 다른 원인입니다. 전자는 신뢰 목록 문제, 후자는 파일 데이터와 서명에 기록된 해시의 불일치입니다. C2PA는 내용의 진실성이나 사람이 만들었다는 사실을 보증하지 않습니다. AI 선언이 없으면 '확인 가능한 선언 없음'으로 표시합니다.

샘플 버튼의 기본값은 실험용 CA를 포함한 정책입니다. 드롭다운에서 정책을 직접 선택하면 샘플 버튼도 그 선택을 따릅니다. 같은 정상 서명 샘플을 두 정책으로 반복 검증해 `Trusted`와 `Valid`의 차이를 관찰할 수 있습니다. API `/api/samples/signed/verify?trust_profile=standard`로도 비교할 수 있습니다. 실험용 CA는 공인 인증 기관이 아니며 샘플 인증서를 공개적으로 신뢰할 수 있다는 뜻이 아닙니다.

## API

| 메서드 | 경로 | 용도 |
| --- | --- | --- |
| GET | `/api/health` | SDK 버전, 크기 제한, 정책 |
| POST | `/api/verify` | multipart `file`, `trust_profile=standard\|lab` |
| POST | `/api/verify-url` | JSON `{ "url": "https://.../file.jpg", "trust_profile": "standard" }` |
| POST | `/api/assets` | multipart `file`, 선택 `label`, `source`, `tags`, `notes`; 원본 등록 |
| GET | `/api/assets?q=...` | 자료명·파일명·출처·태그·해시 검색 |
| GET | `/api/assets/{id}` | 등록된 자료 상세 |
| GET | `/api/assets/{id}/download` | 보관된 원본 다운로드 |
| POST | `/api/assets/{id}/verify?trust_profile=lab` | 보관된 원본 재검증 |
| GET | `/api/samples` | 샘플 목록 |
| GET | `/api/samples/{id}/file` | 실제 샘플 파일 |
| POST | `/api/samples/{id}/verify?trust_profile=lab` | 실제 샘플 검증 |
| GET | `/api/history?q=...&state=Invalid&trust_profile=lab&limit=50` | 검증 기록 검색·필터 |
| GET | `/api/reports/{id}` | 저장된 결과 |
| GET | `/api/reports/{id}/download?format=json\|html` | 보고서 다운로드 |
| DELETE | `/api/reports/{id}` | 기록과 저장된 썸네일 삭제 |

업로드 예시:

```bash
curl -F 'file=@samples/signed.jpg' -F 'trust_profile=lab' http://127.0.0.1:8000/api/verify
```

검증은 별도 프로세스에서 수행하며 동시에 최대 2개, 작업별 90초, CPU 75초로 제한합니다. URL 가져오기는 최대 60초, 리디렉션 최대 5회, HTTPS 443만 허용하고 DNS 응답의 모든 주소가 공인 IP인지 확인합니다. 실제 연결은 검증한 IP에 고정하면서 TLS 인증서 및 SNI는 원래 호스트로 검증합니다. 내부 주소·인증 정보 포함 URL은 차단합니다. SDK에서 파일에 포함된 외부 URL은 가져오지 않습니다.

`C2PA_DB=/path/to/lab.sqlite3`로 데이터베이스 경로를 바꿀 수 있습니다. 기본 경로의 `data/`는 Git에 포함되지 않습니다. 보고서에는 파일 이름, 매니페스트, 미리보기 등 개인 정보가 들어갈 수 있으니 실험 후 UI에서 삭제할 수 있습니다. 인증/멀티테넌트/운영 서비스 배포는 이 로컬 버전의 범위에 포함되지 않습니다.

## 구조

```text
backend/app.py        API, 임시 업로드 처리, 검증 프로세스 관리
backend/engine.py     공식 C2PA SDK와 결과 정규화
backend/worker.py     네이티브 분석의 별도 프로세스 실행
backend/network.py    DNS 고정 HTTPS 다운로드와 SSRF 차단
backend/storage.py    SQLite 보고서·연구 자료 메타데이터 저장과 이전 DB 자동 이전
static/              한국어 웹 UI, 반응형 CSS, 프론트 기능
samples/             실제 서명·변조·미서명 파일과 실험용 루트 CA
scripts/create_samples.py  샘플 생성기 (키는 메모리에만 존재)
tests/test_api.py     실제 SDK 통합 및 경계조건 테스트
```

확장 시 `backend/engine.py`에서 별도 assertion 파서·실험 지표를 추가하고 반환 결과와 프론트 상세 탭을 확장하면 됩니다. 샘플을 재생성하면 새로운 CA를 만들기 때문에 기존 결과와 정책이 달라질 수 있습니다. 최초 상태의 샘플은 프로젝트에 함께 제공됩니다.

## 검증

```bash
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
```

자동 테스트 37개가 통과했습니다. 실제 SDK 서명·해시 검증, 신뢰 정책 분리, 원본 등록·중복 감지·다운로드·재검증, 기존 기록 보존과 검색, 보고서 저장·다운로드·삭제, HTML 이스케이프, 파일 및 요청 크기 제한, 오류 파일, PNG/PDF, SSRF와 리디렉션 차단을 확인합니다. 이미지 전용 API에서 정상 서명·변조·Manifest 없음·AI 생성 선언, 손상되거나 형식이 다른 파일의 거부, C2PA가 없는 이미지의 메타데이터·체크섬 반환을 검사합니다. URL 성공 응답은 오프라인 자동 테스트에서 내려받기만 대체하고 실제 파일 검증은 SDK가 수행합니다.

브라우저에서 세 샘플의 다중 업로드, 정책을 바꾼 재검증, JSON 검색, 작업 이력, 출처 조회, 보고서 링크로 결과 재열기, API 문서의 실제 실행을 확인했습니다. `https://c2paviewer.com/samples/ski%20pole.jpg`를 실제 HTTPS로 가져와 C2PA 파싱, Adobe Firefly 서명과 AI 생성 선언을 읽는 것도 확인했습니다. 이 파일은 현재 SDK 기본 신뢰 설정에서 `signingCredential.untrusted`가 반환되어 `Valid`로 표시됩니다. 참고 사이트의 `Trusted`와 다른 이유는 신뢰 설정의 차이이며, 결과를 임의로 `Trusted`로 바꾸지 않습니다.

참고 문서: [공식 Python SDK](https://github.com/contentauth/c2pa-python), [Context 및 신뢰 설정](https://github.com/contentauth/c2pa-python/blob/main/docs/context-settings.md), [C2PA 규격](https://spec.c2pa.org/).
