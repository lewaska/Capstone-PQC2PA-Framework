import io
import json
import socket
from pathlib import Path

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from PIL import Image

from backend import network, storage
from backend.app import app, ROOT
from backend.engine import inspect_asset


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("C2PA_DB", str(tmp_path / "reports.sqlite3"))
    monkeypatch.setattr(storage, "ASSET_DIR", tmp_path / "assets")
    with TestClient(app) as client:
        yield client


def upload(client, name="signed.jpg", trust="lab"):
    return client.post("/api/verify", files={"file": (name, (ROOT / "samples" / name).read_bytes(), "image/jpeg")},
        data={"trust_profile": trust})


@pytest.mark.parametrize("name,state", [("signed.jpg", "Trusted"), ("tampered.jpg", "Invalid"), ("unsigned.jpg", "NoManifest")])
def test_real_c2pa_uploads(client, name, state):
    response = upload(client, name)
    assert response.status_code == 200
    result = response.json()
    assert result["state"] == state
    assert len(result["sha256"]) == 64
    assert result["thumbnail"].startswith("data:image/jpeg;base64,")
    assert result["network_policy"] == {"remote_manifests": False, "ocsp": False}
    if state == "Invalid":
        assert any("dataHash.mismatch" in c["code"] and c["kind"] == "failure" for c in result["checks"])
    if state == "Trusted":
        assert result["actions"][0]["action"] == "c2pa.created"
        assert result["signature"]["common_name"] == "C2PA Lab Test Signer"


def test_trust_profiles_are_isolated(client):
    assert upload(client, trust="lab").json()["state"] == "Trusted"
    standard = upload(client, trust="standard").json()
    assert standard["state"] == "Valid"
    assert any(c["code"] == "signingCredential.untrusted" for c in standard["checks"])
    assert upload(client, trust="lab").json()["state"] == "Trusted"


def test_history_report_download_delete(client):
    result = upload(client).json()
    report_id = result["id"]
    assert client.get("/api/history").json()[0]["id"] == report_id
    assert client.get(f"/api/reports/{report_id}").json() == result
    assert client.get(f"/api/reports/{report_id}/download").json() == result
    html = client.get(f"/api/reports/{report_id}/download?format=html")
    assert html.status_code == 200 and "attachment" in html.headers["content-disposition"]
    assert client.delete(f"/api/reports/{report_id}").status_code == 200
    assert client.get(f"/api/reports/{report_id}").status_code == 404
    assert client.get("/api/history").json() == []


def test_html_report_escapes_metadata(client):
    dangerous = '<img src=x onerror=alert(1)>.jpg'
    result = client.post("/api/verify", files={"file": (dangerous, (ROOT / "samples" / "unsigned.jpg").read_bytes())}).json()
    html = client.get(f'/api/reports/{result["id"]}/download?format=html').text
    assert "<img src=x" not in html
    assert "&lt;img src=x" in html


def test_errors_and_unsupported_file(client):
    assert client.post("/api/verify", files={"file": ("empty.jpg", b"")}).status_code == 400
    assert client.post("/api/verify", files={"file": ("program.exe", b"bytes")}).status_code == 415
    assert upload(client, trust="anything").status_code == 400
    assert client.get("/api/samples/missing/file").status_code == 404
    assert client.get("/api/reports/missing").status_code == 404
    assert client.post("/api/verify-url", json={"url": "http://127.0.0.1/private"}).status_code == 400


def test_corrupt_file_is_not_no_manifest(client):
    response = client.post("/api/verify", files={"file": ("corrupt.jpg", b"this is not a jpeg")})
    assert response.status_code == 200
    assert response.json()["state"] == "Error"


def test_png_and_pdf_without_manifest(client):
    image = Image.new("RGB", (20, 20), "white")
    for ext, mime in [("png", "image/png"), ("pdf", "application/pdf")]:
        stream = io.BytesIO(); image.save(stream, format=ext.upper())
        response = client.post("/api/verify", files={"file": (f"image.{ext}", stream.getvalue(), mime)})
        assert response.status_code == 200
        assert response.json()["state"] == "NoManifest"


def test_cross_origin_writes_blocked(client):
    response = client.post("/api/samples/signed/verify", headers={"Origin": "https://malicious.example"})
    assert response.status_code == 403
    assert client.post("/api/samples/signed/verify", headers={"Origin": "http://testserver"}).status_code == 200


@pytest.mark.parametrize("url", ["http://example.com/a.jpg", "https://user:pass@example.com/a.jpg", "https://127.0.0.1/a.jpg", "https://[::1]/a.jpg", "https://169.254.169.254/a.jpg", "https://example.com:8080/a.jpg"])
def test_ssrf_blocked(url, monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", lambda host,*args,**kwargs: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (host if host[0].isdigit() else "127.0.0.1", 443))])
    with pytest.raises(HTTPException):
        network.public_target(url)


def test_url_download_and_verification(client, monkeypatch):
    def fake_download(url, path, maximum):
        Path(path).write_bytes((ROOT / "samples" / "signed.jpg").read_bytes())
        return url, "image/jpeg"
    monkeypatch.setattr("backend.app.download", fake_download)
    response = client.post("/api/verify-url", json={"url": "https://example.com/image.jpg", "trust_profile": "lab"})
    assert response.status_code == 200
    assert response.json()["state"] == "Trusted"
    assert response.json()["source_url"] == "https://example.com/image.jpg"


def test_download_revalidates_redirect_and_pins_ip(tmp_path, monkeypatch):
    targets = []
    def lookup(host, *args, **kwargs):
        targets.append(host)
        ip = "93.184.215.14" if host == "example.com" else "127.0.0.1"
        return [(socket.AF_INET,socket.SOCK_STREAM,6,"",(ip,443))]
    monkeypatch.setattr(socket,"getaddrinfo",lookup)
    class Redirect:
        status = 302
        def getheader(self,name,*args): return "https://internal.example/private.jpg"
    class Connection:
        def __init__(self,host,ip): assert ip == "93.184.215.14"
        def request(self,*args,**kwargs): pass
        def getresponse(self): return Redirect()
        def close(self): pass
    monkeypatch.setattr(network,"PinnedHTTPS",Connection)
    with pytest.raises(HTTPException) as caught:
        network.download("https://example.com/file.jpg",tmp_path/"file",1024)
    assert caught.value.status_code == 400
    assert targets == ["example.com","internal.example"]


def test_sample_api_and_health(client):
    assert client.get("/api/health").json()["sdk_version"] == "0.37.12"
    assert len(client.get("/api/samples").json()) == 4
    assert client.get("/api/samples/signed/file").headers["content-type"] == "image/jpeg"
    assert client.post("/api/samples/tampered/verify").json()["state"] == "Invalid"


def test_upload_size_limit(client, monkeypatch):
    monkeypatch.setattr("backend.app.MAX_BYTES", 100)
    response = upload(client)
    assert response.status_code == 413


def test_whole_request_size_limit(client, monkeypatch):
    monkeypatch.setattr("backend.app.MAX_BYTES", 100)
    response = client.post("/api/verify",files={"file":("large.jpg", b"x" * (3 * 1024 * 1024))})
    assert response.status_code == 413


def test_offline_docs_and_openapi(client):
    response = client.get("/docs")
    assert response.status_code == 200
    assert "/static/api.js" in response.text
    assert "cdn.jsdelivr" not in response.text
    assert "/api/verify" in client.get("/openapi.json").json()["paths"]


def test_register_reuse_and_verify_saved_original(client):
    original = (ROOT / "samples" / "signed.jpg").read_bytes()
    form = {"label": "연구용 사진 01", "source": "실험 카메라", "notes": "첫 촬영본", "tags": "원본, 사진"}
    first = client.post("/api/assets", files={"file": ("signed.jpg", original, "image/jpeg")}, data=form)
    assert first.status_code == 201
    assert first.json()["duplicate"] is False
    asset = first.json()["asset"]
    assert asset["label"] == "연구용 사진 01"
    assert asset["tags"] == ["원본", "사진"]
    assert asset["sha256"] in str(storage.asset_path(asset))
    assert storage.asset_path(asset).read_bytes() == original
    assert client.get(f'/api/assets/{asset["id"]}/download').content == original
    assert "attachment" in client.get(f'/api/assets/{asset["id"]}/download').headers["content-disposition"]
    repeated = client.post("/api/assets", files={"file": ("other.jpg", original)}, data={"label": "다른 이름"})
    assert repeated.json()["duplicate"] is True
    assert repeated.json()["asset"]["id"] == asset["id"]
    assert repeated.json()["asset"]["label"] == "연구용 사진 01"
    assert len(list(storage.ASSET_DIR.glob("*.jpg"))) == 1
    assert client.get("/api/assets?q=실험 카메라").json()[0]["id"] == asset["id"]
    assert client.get("/api/assets?q=원본").json()[0]["id"] == asset["id"]
    assert client.get("/api/assets?q=없는자료").json() == []
    report = client.post(f'/api/assets/{asset["id"]}/verify?trust_profile=lab').json()
    assert report["state"] == "Trusted" and report["asset_id"] == asset["id"]
    assert client.get(f'/api/reports/{report["id"]}').json()["asset_id"] == asset["id"]
    second = client.post(f'/api/assets/{asset["id"]}/verify?trust_profile=standard').json()
    assert second["state"] == "Valid" and second["asset_id"] == asset["id"]
    assert storage.asset_path(asset).read_bytes() == original
    assert len(client.get(f'/api/history?asset_id={asset["id"]}').json()) == 2
    listed = client.get("/api/assets").json()[0]
    assert listed["verification_count"] == 2 and listed["latest_state"] == "Valid"


def test_search_existing_and_new_reports(client):
    first = upload(client, "signed.jpg", "lab").json()
    second = upload(client, "tampered.jpg", "lab").json()
    assert len(client.get("/api/history?q=signed").json()) == 1
    assert client.get("/api/history?q=signed").json()[0]["id"] == first["id"]
    assert client.get("/api/history?state=Invalid").json()[0]["id"] == second["id"]
    assert len(client.get("/api/history?state=Trusted&trust_profile=lab").json()) == 1
    assert client.get("/api/history?q=" + first["sha256"][:12]).json()[0]["id"] == first["id"]
    assert client.get("/api/history?q=Test%20Signer").json()[0]["id"] == second["id"]
    assert client.get("/api/history?q=missing").json() == []


def test_existing_json_reports_migrate_without_loss(tmp_path, monkeypatch):
    import sqlite3
    path = tmp_path / "legacy.sqlite3"
    old = {"id": "legacy", "created_at": "2026-01-01T00:00:00Z", "filename": "legacy.jpg",
           "state": "NoManifest", "sha256": "a" * 64, "trust_profile": "standard", "size": 100}
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE reports (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)")
        conn.execute("INSERT INTO reports VALUES (?, ?, ?)", (old["id"], old["created_at"], json.dumps(old)))
    monkeypatch.setenv("C2PA_DB", str(path))
    assert storage.get("legacy") == old
    assert storage.history(q="legacy")[0]["id"] == "legacy"
    assert storage.history(state="NoManifest")[0]["id"] == "legacy"


def test_asset_registration_limits_and_missing_original(client, monkeypatch):
    assert client.post("/api/assets", files={"file": ("bad.exe", b"x")}).status_code == 415
    assert client.post("/api/assets", files={"file": ("empty.jpg", b"")}).status_code == 400
    assert client.get("/api/assets/missing/download").status_code == 404
    monkeypatch.setattr("backend.app.MAX_BYTES", 100)
    assert client.post("/api/assets", files={"file": ("large.jpg", b"x" * 101)}).status_code == 413
    assert list(storage.ASSET_DIR.glob("*.jpg")) == []
