"""The blue image viewer and the native C2PA verifier work on one origin."""
import io
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from PIL import Image, PngImagePlugin

from viewer_server import app


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def viewer(tmp_path, monkeypatch):
    monkeypatch.setenv("C2PA_DB", str(tmp_path / "reports.sqlite3"))
    with TestClient(app) as client:
        yield client


@pytest.mark.parametrize(
    "sample,expected,expected_code",
    [
        ("signed.jpg", "Valid", "claimSignature.validated"),
        ("tampered.jpg", "Invalid", "assertion.dataHash.mismatch"),
        ("unsigned.jpg", "NoManifest", None),
    ],
)
def test_image_verification_from_viewer(viewer, sample, expected, expected_code):
    image = (ROOT / "samples" / sample).read_bytes()
    response = viewer.post(
        "/engine/api/verify-image",
        files={"file": (sample, image, "image/jpeg")},
        data={"trust_profile": "standard"},
        headers={"Origin": "http://testserver"},
    )
    assert response.status_code == 200
    result = response.json()
    assert result["state"] == expected
    assert result["filename"] == sample
    assert result["sha256"]
    assert len(result["sha3_256"]) == 64
    assert result["image_info"]["format"] == "JPEG"
    assert result["image_info"]["width"] == 1200
    if expected_code:
        assert expected_code in {check["code"] for check in result["checks"]}
    assert viewer.get(f"/engine/api/reports/{result['id']}").json() == result
    download = viewer.get(f"/engine/api/reports/{result['id']}/download?format=json")
    assert download.status_code == 200
    assert download.json() == result


def test_viewer_assets_and_origin_policy(viewer):
    assert "app.js" in viewer.get("/").text
    assert viewer.get("/").headers["cache-control"] == "no-store"
    assert "VERIFY_API_URL" in viewer.get("/app.js").text
    assert viewer.get("/engine/api/health").json()["status"] == "ok"
    response = viewer.post(
        "/engine/api/verify",
        files={"file": ("unsigned.jpg", (ROOT / "samples" / "unsigned.jpg").read_bytes(), "image/jpeg")},
        headers={"Origin": "https://outside.example"},
    )
    assert response.status_code == 403


def test_viewer_sample_button_route_uses_lab_policy(viewer):
    result = viewer.post("/engine/api/samples/signed/verify?trust_profile=lab").json()
    assert result["state"] == "Trusted"
    assert result["trust_profile"] == "lab"


def test_ai_declared_sample_is_real_signed_png(viewer):
    response = viewer.post("/engine/api/samples/ai/verify?trust_profile=standard")
    assert response.status_code == 200
    result = response.json()
    assert result["state"] == "Valid"
    assert result["ai"] == "declared"
    assert result["image_info"]["format"] == "PNG"
    assert result["manifest_count"] > 0


def test_uploaded_ai_png_keeps_its_c2pa_result(viewer):
    image = (ROOT / "samples" / "ai-han-river-sunrise.png").read_bytes()
    response = viewer.post("/engine/api/verify-image", files={"file": ("ai-han-river-sunrise.png", image, "image/png")})
    assert response.status_code == 200
    result = response.json()
    assert result["state"] == "Valid"
    assert result["ai"] == "declared"
    assert result["signature"]["common_name"] == "OpenAI Media Service"


@pytest.mark.parametrize("image_format,suffix,mime", [
    ("WEBP", ".webp", "image/webp"), ("AVIF", ".avif", "image/avif"),
])
def test_other_advertised_image_formats_return_information(viewer, image_format, suffix, mime):
    output = io.BytesIO()
    Image.new("RGB", (48, 32), "#4567ab").save(output, format=image_format)
    response = viewer.post("/engine/api/verify-image", files={"file": ("sample" + suffix, output.getvalue(), mime)})
    assert response.status_code == 200
    result = response.json()
    assert result["state"] == "NoManifest"
    assert result["image_info"]["format"] == image_format
    assert result["image_info"]["width"] == 48


def test_image_endpoint_rejects_wrong_or_damaged_input(viewer):
    jpeg = (ROOT / "samples" / "unsigned.jpg").read_bytes()
    wrong = viewer.post("/engine/api/verify-image", files={"file": ("wrong.png", jpeg, "image/png")})
    assert wrong.status_code == 422
    damaged = viewer.post("/engine/api/verify-image", files={"file": ("broken.jpg", b"not an image", "image/jpeg")})
    assert damaged.status_code == 422
    unsupported = viewer.post("/engine/api/verify-image", files={"file": ("notes.pdf", b"%PDF", "application/pdf")})
    assert unsupported.status_code == 415


def test_plain_image_still_returns_file_information(viewer):
    image = io.BytesIO()
    info = PngImagePlugin.PngInfo()
    info.add_text("Description", "연구용 풍경")
    Image.new("RGB", (320, 180), "#416fbd").save(image, format="PNG", pnginfo=info)
    response = viewer.post("/engine/api/verify-image", files={"file": ("new.png", image.getvalue(), "image/png")})
    assert response.status_code == 200
    result = response.json()
    assert result["state"] == "NoManifest"
    assert result["image_info"]["format"] == "PNG"
    assert result["image_info"]["width"] == 320
    assert result["image_info"]["metadata"]["Description"] == "연구용 풍경"
    assert result["thumbnail"].startswith("data:image/jpeg;base64,")
    report = viewer.get(f"/engine/api/reports/{result['id']}").json()
    assert report["image_info"] == result["image_info"]
