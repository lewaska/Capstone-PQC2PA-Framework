/* Real C2PA results come only from the local verifier, never from file metadata alone. */
const AI_API_URL = "/engine/api/ai/generate";
const VERIFY_API_URL = "/engine/api/verify-image";
const HEALTH_API_URL = "/engine/api/health";
const HISTORY_API_URL = "/engine/api/history?limit=200";
const REPORT_API_URL = id => `/engine/api/reports/${encodeURIComponent(id)}`;
const SAMPLE_API_URL = id => `/engine/api/samples/${encodeURIComponent(id)}/verify?trust_profile=lab`;
const STATE_LABELS = {
  Trusted: "신뢰 확인", Valid: "서명 유효 · 신뢰 미확인", Invalid: "검증 실패",
  NoManifest: "Manifest 없음", RemoteUnavailable: "원격 Manifest 확인 불가", Error: "분석 오류"
};
const STORAGE_KEY = "originlab_experiments_v1";
const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/avif"]);
const ALLOWED_SUFFIXES = [".jpg", ".jpeg", ".png", ".webp", ".avif"];
const MAX_BYTES = 20 * 1024 * 1024;
const VIEWS = new Set(["home", "result", "detail", "outputs", "history", "guide", "devices", "code", "trust"]);
const RESOURCE_VIEWS = new Set(["guide", "devices", "code", "trust"]);
const state = { file: null, objectUrl: null, imageDimensions: null, generatedBlob: null, generatedName: null, generatedUrl: null, selectedId: null, records: [], toastTimer: null, aiAvailable: false };
const $ = id => document.getElementById(id);
const $$ = selector => [...document.querySelectorAll(selector)];
const setText = (id, value) => { $(id).textContent = value; };

function toast(message) {
  const element = $("toast");
  element.textContent = message;
  element.hidden = false;
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => { element.hidden = true; }, 4500);
}

function formatSize(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "—";
  return bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "날짜 정보 없음" : new Intl.DateTimeFormat("ko-KR", {
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false
  }).format(date);
}
function makeId() {
  return typeof globalThis.crypto?.randomUUID === "function" ? globalThis.crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function stateLabel(value) { return STATE_LABELS[value] || "결과 확인 필요"; }
function summarizedAnalysis(result) {
  const signature = result.signature || {};
  const store = result.store || {};
  return {
    state: result.state || "Unknown", sha256: result.sha256 || "", sha3_256: result.sha3_256 || "",
    signer: signature.common_name || signature.issuer || "확인 불가",
    issuer: signature.issuer || "", algorithm: signature.alg || "확인 불가",
    ai: result.ai || "unknown", trustProfile: result.trust_profile || "standard", activeManifest: store.active_manifest || "",
    manifestCount: result.manifest_count || 0, elapsedMs: result.elapsed_ms || 0,
    imageInfo: result.image_info && typeof result.image_info === "object" ? result.image_info : null,
    checks: Array.isArray(result.checks) ? result.checks.map(check => ({
      code: String(check.code || ""), kind: String(check.kind || ""),
      explanation: String(check.explanation || "").slice(0, 250)
    })).slice(0, 80) : [],
    error: result.error || ""
  };
}
function loadRecords() {
  try {
    const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    if (!Array.isArray(list)) return [];
    return list.filter(item => item && typeof item.id === "string" && typeof item.name === "string").map(item => ({
      id: item.id, createdAt: typeof item.createdAt === "string" ? item.createdAt : "",
      name: item.name, mime: typeof item.mime === "string" ? item.mime : "",
      size: Number.isFinite(item.size) ? item.size : 0,
      width: Number.isSafeInteger(item.width) && item.width > 0 ? item.width : null,
      height: Number.isSafeInteger(item.height) && item.height > 0 ? item.height : null,
      kind: item.kind === "demo" ? "demo" : item.kind === "verified" ? "verified" : "pending",
      status: item.kind === "demo" ? "시연 데이터" : item.kind === "verified" ? stateLabel(item.analysis?.state) : "분석 대기",
      serverId: typeof item.serverId === "string" ? item.serverId : null,
      analysis: item.analysis && typeof item.analysis === "object" ? item.analysis : null,
      artifacts: item.kind === "verified" ? ["검증 보고서 JSON"] : []
    }));
  } catch { return []; }
}
function saveRecords() {
  const saved = state.records.map(({ full, ...record }) => record);
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(saved)); }
  catch { toast("브라우저 저장 공간을 사용할 수 없어 이번 세션에서만 기록이 보입니다."); }
}
function currentRecord() { return state.records.find(record => record.id === state.selectedId) || null; }

function clearInputPreview() {
  $("fileInput").value = "";
  $("uploadPreview").removeAttribute("src");
  $("uploadEmpty").hidden = false;
  $("uploadSelected").hidden = true;
  $("inspectButton").disabled = true;
  $("removeButton").disabled = true;
  setText("selectedName", "—");
  setText("selectedMeta", "—");
}
function releaseSelectedFile() {
  $("uploadPreview").removeAttribute("src");
  if (state.objectUrl) URL.revokeObjectURL(state.objectUrl);
  state.objectUrl = null;
  state.file = null;
  state.imageDimensions = null;
  clearInputPreview();
}
function clearGeneratedImage() {
  $("aiPreview").removeAttribute("src");
  if (state.generatedUrl) URL.revokeObjectURL(state.generatedUrl);
  state.generatedBlob = null;
  state.generatedName = null;
  state.generatedUrl = null;
  $("aiPreview").hidden = true;
  $("aiEmpty").hidden = false;
  $("useAiImage").disabled = true;
  setText("aiStatus", "생성 API 연결 대기");
}
function selectFile(file) {
  if (!file) return;
  if (!ALLOWED_SUFFIXES.some(suffix => file.name.toLowerCase().endsWith(suffix)) || (file.type && !ALLOWED_TYPES.has(file.type))) {
    toast("JPG, PNG, WebP, AVIF 이미지만 사용할 수 있습니다."); return;
  }
  if (file.size > MAX_BYTES) { toast("20 MB 이하의 이미지를 선택해 주세요."); return; }
  releaseSelectedFile();
  state.file = file;
  state.objectUrl = URL.createObjectURL(file);
  state.imageDimensions = null;
  $("uploadPreview").src = state.objectUrl;
  $("uploadEmpty").hidden = true;
  $("uploadSelected").hidden = false;
  setText("selectedName", file.name);
  setText("selectedMeta", `${file.type.replace("image/", "").toUpperCase()} · ${formatSize(file.size)}`);
  $("inspectButton").disabled = false;
  $("removeButton").disabled = false;
  toast("이미지가 선택되었습니다. 검사 실행 전까지 미리볼 수 있습니다.");
}
function addRecord(record) {
  state.records = state.records.filter(item => item.id !== record.id);
  state.records.unshift(record);
  state.selectedId = record.id;
  saveRecords();
  renderRecord();
  renderOutputs();
  renderHistory();
  view("result");
}
async function syncServerHistory() {
  try {
    const response = await fetch(HISTORY_API_URL, { cache: "no-store" });
    if (!response.ok) return;
    const list = await response.json();
    if (!Array.isArray(list)) return;
    const known = new Set(state.records.map(record => record.id));
    for (const item of list) {
      if (!item?.id || !item?.filename || known.has(item.id)) continue;
      if (!ALLOWED_SUFFIXES.some(suffix => item.filename.toLowerCase().endsWith(suffix))) continue;
      const dimensions = Array.isArray(item.dimensions) ? item.dimensions : [];
      state.records.push({
        id: item.id, serverId: item.id, createdAt: item.created_at || "", name: item.filename,
        mime: item.mime || "", size: item.size || 0, width: dimensions[0] || item.image_info?.width || null,
        height: dimensions[1] || item.image_info?.height || null, kind: "verified",
        status: stateLabel(item.state), artifacts: ["검증 보고서 JSON"],
        analysis: { state: item.state, sha256: item.sha256 || "", sha3_256: item.sha3_256 || "",
          signer: item.signer || "확인 불가", trustProfile: item.trust_profile || "standard",
          imageInfo: item.image_info || null, checks: [] }
      });
      known.add(item.id);
    }
    state.records.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (!state.selectedId) state.selectedId = state.records[0]?.id || null;
    saveRecords(); renderRecord(); renderOutputs(); renderHistory();
    if (["result", "detail"].includes(location.hash.slice(1))) ensureFull(currentRecord());
  } catch { /* Browser-only records remain available when the server is offline. */ }
}
function recordFromResult(result, fallbackName = "image") {
  const dimensions = Array.isArray(result.dimensions) ? result.dimensions : [];
  return {
    id: result.id, serverId: result.id, createdAt: result.created_at || new Date().toISOString(),
    name: result.filename || fallbackName, mime: result.mime || "", size: result.size || 0,
    width: dimensions[0] || result.image_info?.width || null, height: dimensions[1] || result.image_info?.height || null,
    kind: "verified", status: stateLabel(result.state), analysis: summarizedAnalysis(result),
    artifacts: ["검증 보고서 JSON"], full: result
  };
}
async function inspectImage() {
  if (!state.file) return;
  const button = $("inspectButton");
  const file = state.file;
  button.disabled = true;
  button.textContent = "검증 중…";
  try {
    const form = new FormData();
    form.append("file", file, file.name);
    form.append("trust_profile", "standard");
    const response = await fetch(VERIFY_API_URL, { method: "POST", body: form });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(typeof result.detail === "string" ? result.detail : `분석 서버 응답 오류 (${response.status})`);
    if (!result.id || !result.state) throw new Error("분석 결과 형식을 확인할 수 없습니다.");
    const record = recordFromResult(result, file.name);
    record.mime ||= file.type;
    record.size ||= file.size;
    record.width ||= state.imageDimensions?.width || null;
    record.height ||= state.imageDimensions?.height || null;
    releaseSelectedFile();
    clearGeneratedImage();
    addRecord(record);
    toast("실제 C2PA 검증을 마쳤습니다. 업로드 원본은 임시 처리 후 삭제되었습니다.");
  } catch (error) {
    toast(`검증하지 못했습니다. ${error.message || "분석 서버 상태를 확인해 주세요."}`);
  } finally {
    button.innerHTML = '검사 실행 <svg><use href="#i-arrow"/></svg>';
    button.disabled = !state.file;
  }
}
async function verifySample(button) {
  const sample = button.dataset.verifySample;
  if (!["signed", "tampered", "unsigned", "ai"].includes(sample)) return;
  button.disabled = true;
  const label = button.textContent;
  button.textContent = "검증 중…";
  try {
    const response = await fetch(SAMPLE_API_URL(sample), { method: "POST" });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(typeof result.detail === "string" ? result.detail : `서버 응답 오류 (${response.status})`);
    if (!result.id || !result.state) throw new Error("샘플 결과 형식을 확인할 수 없습니다.");
    releaseSelectedFile();
    clearGeneratedImage();
    addRecord(recordFromResult(result, `${sample}.jpg`));
    toast("실제 샘플 검증을 마쳤습니다. 상세 결과에서 SDK 코드를 확인하세요.");
  } catch (error) {
    toast(`샘플을 검증하지 못했습니다. ${error.message || "분석 서버를 확인해 주세요."}`);
  } finally {
    button.textContent = label;
    button.disabled = false;
  }
}
function showSample() {
  releaseSelectedFile();
  clearGeneratedImage();
  addRecord({
    id: makeId(), createdAt: new Date().toISOString(), name: "시연용 예시",
    mime: "", size: 0, width: null, height: null, kind: "demo", status: "시연 데이터", artifacts: []
  });
}
function removeFile() { releaseSelectedFile(); toast("선택한 이미지를 화면에서 제거했습니다."); }
function setInputMode(mode, clearSelection = true) {
  if (clearSelection && state.file) releaseSelectedFile();
  $("dropzone").hidden = mode !== "file";
  $("urlInputPanel").hidden = mode !== "url";
  $$("[data-input-mode]").forEach(button => {
    const active = button.dataset.inputMode === mode;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  if (mode === "url") $("urlInput").focus();
}
async function loadFromUrl() {
  const raw = $("urlInput").value.trim();
  let parsed;
  try {
    parsed = new URL(raw);
    if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("protocol");
  } catch { toast("http 또는 https 이미지 주소를 입력해 주세요."); return; }
  const button = $("urlLoadButton");
  button.disabled = true;
  button.textContent = "불러오는 중…";
  try {
    const response = await fetch(parsed.href, { credentials: "omit" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const type = (response.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    const reportedSize = Number(response.headers.get("content-length") || 0);
    if (!ALLOWED_TYPES.has(type)) throw new Error("image type");
    if (reportedSize > MAX_BYTES) throw new Error("image size");
    const blob = await response.blob();
    if (blob.size > MAX_BYTES) throw new Error("image size");
    const extension = type === "image/jpeg" ? "jpg" : type.split("/")[1];
    let name = decodeURIComponent(parsed.pathname.split("/").pop() || "").replace(/[^\w.\-\u3131-\uD79D]/g, "_");
    if (!name || name === "_") name = `linked-image.${extension}`;
    if (![".jpg", ".jpeg", ".png", ".webp", ".avif"].some(suffix => name.toLowerCase().endsWith(suffix))) name += `.${extension}`;
    selectFile(new File([blob], name, { type }));
    setInputMode("file", false);
    $("urlInput").value = "";
  } catch {
    toast("이 주소의 이미지를 브라우저에서 불러올 수 없습니다. 파일을 직접 선택해 주세요.");
  } finally {
    button.disabled = false;
    button.innerHTML = '이미지 불러오기 <svg><use href="#i-arrow"/></svg>';
  }
}

function checkOutcome(checks, match) {
  const hits = checks.filter(item => match(String(item.code || "").toLowerCase()));
  if (hits.some(item => item.kind === "failure")) return "실패";
  if (hits.some(item => item.kind === "success")) return "검증됨";
  return "확인되지 않음";
}
function resultDescription(value) {
  return {
    Trusted: "서명과 무결성이 유효하고, 선택한 신뢰 정책에서 서명자를 신뢰합니다. 이미지 내용의 사실 여부는 별개입니다.",
    Valid: "서명과 무결성은 유효하지만 서명자의 신뢰는 확인되지 않았습니다.",
    Invalid: "검증 실패 항목이 있습니다. 상세 결과에서 SDK 오류 코드와 이유를 확인하세요.",
    NoManifest: "C2PA Manifest는 없지만 사진 형식·크기와 촬영 메타데이터 유무를 확인했습니다. 이것만으로 조작 여부를 판단할 수 없습니다.",
    RemoteUnavailable: "원격 Manifest가 필요하지만 현재 검증 정책은 외부 조회를 차단합니다.",
    Error: "SDK가 파일을 분석하지 못했습니다. 상세 결과의 오류를 확인하세요."
  }[value] || "SDK 검증 결과를 상세 화면에서 확인하세요.";
}
function renderManifestData(record) {
  const full = record?.full;
  const verified = record?.kind === "verified";
  $("manifestDataReady").hidden = !verified || !full;
  $("manifestDataEmpty").hidden = verified && !!full;
  setText("manifestDataTag", verified ? full ? "SDK 보고서" : "보고서 불러오는 중" : "데이터 대기");
  if (!verified || !full) {
    setText("manifestEmptyTitle", verified ? record.loadError ? "보고서를 불러오지 못했습니다" : "검증 보고서를 불러오는 중" : "표시할 Manifest 데이터가 없습니다");
    setText("manifestEmptyText", verified ? record.loadError || "잠시 후 검증 코드와 Manifest가 표시됩니다." : "이미지를 검사하면 SDK의 검증 코드와 데이터를 확인할 수 있습니다.");
    return;
  }
  setText("manifestDigest", full.sha256 || "확인 불가");
  setText("manifestAlgorithm", full.signature?.alg || "정보 없음");
  setText("manifestActive", full.store?.active_manifest || "Manifest 없음");
  const list = $("validationCodes");
  list.replaceChildren();
  const checks = Array.isArray(full.checks) ? full.checks : [];
  if (!checks.length) list.append(node("p", "validation-empty", full.error || "SDK 검증 코드가 없습니다."));
  checks.forEach(check => {
    const item = node("div", "validation-code", "");
    item.append(node("span", `code-kind ${check.kind || "informational"}`, check.kind === "failure" ? "실패" : check.kind === "success" ? "통과" : "정보"),
      node("strong", "", check.code || "코드 없음"), node("p", "", check.explanation || "설명 없음"));
    list.append(item);
  });
  $("manifestJson").textContent = JSON.stringify(full.store || {}, null, 2);
}
async function ensureFull(record) {
  if (!record || record.kind !== "verified" || !record.serverId || record.full || record.loading) return;
  record.loading = true;
  record.loadError = "";
  try {
    const response = await fetch(REPORT_API_URL(record.serverId), { cache: "no-store" });
    if (!response.ok) throw new Error(`보고서 조회 실패 (${response.status})`);
    record.full = await response.json();
  } catch (error) {
    record.loadError = error.message || "서버 연결을 확인해 주세요.";
  } finally {
    record.loading = false;
    if (currentRecord()?.id === record.id) renderRecord();
  }
}

const PHOTO_LABELS = {
  Make: "제조사", Model: "카메라 모델", LensModel: "렌즈", DateTime: "기록 시각",
  DateTimeOriginal: "촬영 시각", DateTimeDigitized: "디지털화 시각", Software: "소프트웨어",
  Artist: "제작자", Copyright: "저작권", Orientation: "방향", ExposureTime: "노출 시간",
  FNumber: "조리개", ISOSpeedRatings: "ISO", PhotographicSensitivity: "ISO",
  FocalLength: "초점 거리", Flash: "플래시", WhiteBalance: "화이트 밸런스",
  ColorSpace: "색 공간", ExposureProgram: "노출 프로그램", MeteringMode: "측광",
  Title: "제목", Description: "설명", Comment: "설명", Author: "제작자", "Creation Time": "생성 시각"
};
function renderPhotoInfo(record) {
  const verified = record?.kind === "verified";
  const analysis = record?.analysis || {};
  const info = record?.full?.image_info || analysis.imageInfo;
  setText("photoInfoTag", info ? "파일 분석 완료" : verified ? "정보 없음" : "검사 대기");
  setText("photoFormat", info?.format || (verified ? record.mime?.replace("image/", "").toUpperCase() : "—") || "—");
  setText("photoDimensions", info ? `${info.width} × ${info.height}` : record?.width && record?.height ? `${record.width} × ${record.height}` : "—");
  setText("photoColor", info ? `${info.mode || "정보 없음"}${info.has_alpha ? " · 투명도" : ""}${info.frames > 1 ? ` · ${info.frames}프레임` : ""}` : "—");
  setText("photoIcc", info ? info.has_icc_profile ? "포함" : "없음" : "—");
  setText("photoSha256", record?.full?.sha256 || analysis.sha256 || "—");
  setText("photoSha3", record?.full?.sha3_256 || analysis.sha3_256 || "—");
  const list = $("photoMetadata");
  list.replaceChildren();
  const entries = Object.entries(info?.metadata || {});
  if (!entries.length) list.append(node("p", "", info ? "표시할 촬영·제작 메타데이터가 없습니다." : "이미지를 검사하면 표시됩니다."));
  entries.forEach(([key, value]) => {
    const row = node("div", "", "");
    row.append(node("span", "", PHOTO_LABELS[key] || key), node("strong", "", String(value)));
    list.append(row);
  });
  setText("photoGpsNotice", info?.gps_present ? "위치 메타데이터가 포함되어 있습니다. 이 화면에는 좌표를 표시하지 않습니다." : "");
}
function renderProvenance(record) {
  const verified = record?.kind === "verified";
  const full = record?.full || {};
  const analysis = record?.analysis || {};
  const exists = verified && (full.manifest_count || analysis.manifestCount || 0) > 0;
  const loading = verified && !record.full && analysis.state !== "NoManifest" && !analysis.manifestCount;
  setText("provenanceTag", exists ? "Manifest 확인" : loading ? "상세 보고서 불러오는 중" : verified ? "Manifest 없음" : "검사 대기");
  setText("provenanceSigner", exists ? full.signature?.common_name || analysis.signer || "정보 없음" : "—");
  setText("provenanceIssuer", exists ? full.signature?.issuer || analysis.issuer || "정보 없음" : "—");
  setText("provenanceAlgorithm", exists ? full.signature?.alg || analysis.algorithm || "정보 없음" : "—");
  const software = Array.isArray(full.software) ? full.software[0] : null;
  setText("provenanceTool", exists ? software ? `${software.name || "이름 없음"}${software.version ? ` ${software.version}` : ""}` : "정보 없음" : "—");
  const actionList = $("provenanceActions");
  const ingredientList = $("provenanceIngredients");
  actionList.replaceChildren(); ingredientList.replaceChildren();
  const actions = Array.isArray(full.actions) ? full.actions : [];
  const ingredients = Array.isArray(full.ingredients) ? full.ingredients : [];
  if (!actions.length) actionList.append(node("li", "", loading ? "상세 보고서를 불러오고 있습니다." : exists ? "기록된 작업이 없습니다." : "Manifest에 작업 기록이 없습니다."));
  actions.slice(0, 30).forEach(action => {
    const agent = action.softwareAgent;
    const agentName = typeof agent === "string" ? agent : agent && typeof agent === "object"
      ? `${agent.name || ""}${agent.version ? ` ${agent.version}` : ""}`.trim() : "";
    actionList.append(node("li", "", `${action.action || "작업 이름 없음"}${agentName ? ` · ${agentName}` : ""}`));
  });
  if (!ingredients.length) ingredientList.append(node("li", "", loading ? "상세 보고서를 불러오고 있습니다." : exists ? "연결된 재료가 없습니다." : "Manifest에 재료 기록이 없습니다."));
  ingredients.slice(0, 30).forEach(ingredient => ingredientList.append(node("li", "", ingredient.title || ingredient.instance_id || ingredient.format || "이름 없는 재료")));
}

function renderRecord() {
  const record = currentRecord();
  const demo = record?.kind === "demo";
  const pending = record?.kind === "pending";
  const verified = record?.kind === "verified";
  const analysis = record?.analysis || {};
  const value = analysis.state || "Unknown";
  const checks = analysis.checks || [];
  $("resultBanner").className = `result-banner ${demo ? "is-demo" : verified ? `is-${value.toLowerCase()}` : ""}`;
  setText("bannerLabel", demo ? "화면 예시" : verified ? "C2PA SDK 검증 결과" : "검증 상태");
  setText("bannerTitle", demo ? "결과 화면 예시" : verified ? stateLabel(value) : pending ? "이전 미검증 기록" : "검사 기록이 없습니다");
  setText("bannerText", demo
    ? "아래 값은 화면 구성을 위한 시연 데이터입니다. 실제 C2PA 검증 결과가 아닙니다."
    : verified ? resultDescription(value)
    : pending ? "이 기록은 분석 서버 연결 전에 만들어져 파일 정보만 남았습니다. 원본을 다시 선택해 검사해 주세요."
      : "이미지를 선택하고 검사를 실행해 주세요.");
  setText("bannerTag", demo ? "시연 데이터" : verified ? value : pending ? "미검증" : "대기");
  setText("resultSigner", verified ? analysis.signer || "확인 불가" : demo ? "시연용" : "확인 전");
  const dataHash = checkOutcome(checks, code => code.includes("datahash"));
  setText("resultIntegrity", verified ? value === "NoManifest" ? "검증 불가" : dataHash : demo ? "시연용" : "확인 전");
  setText("resultAiFlag", verified ? analysis.ai === "declared" ? "AI 사용 선언" : "선언 확인 안 됨" : demo ? "시연용" : "확인 전");
  const thumbnail = verified && typeof record.full?.thumbnail === "string" ? record.full.thumbnail : "";
  if (thumbnail) $("resultThumbnail").src = thumbnail; else $("resultThumbnail").removeAttribute("src");
  $("resultThumbnail").hidden = !thumbnail;
  $("resultEmpty").hidden = !!thumbnail;
  setText("resultEmptyTitle", verified ? "축소 미리보기 없음" : record ? "원본 미리보기 해제됨" : "결과 이미지가 없습니다");
  setText("resultEmptyText", verified ? "검증 결과는 아래에서 확인하세요. 원본은 보관하지 않습니다." : record ? "원본 파일은 보관하지 않습니다." : "이미지를 검사하면 결과 상태가 표시됩니다.");
  setText("resultFileName", record?.name || "—");
  setText("resultFileMeta", demo ? "화면 시연용 기록" : record?.mime ? record.mime.replace("image/", "").toUpperCase() : "선택된 파일 없음");
  setText("resultFileSize", record ? formatSize(record.size) : "—");
  setText("resultImageDimensions", demo ? "예시" : record?.width && record?.height ? `${record.width} × ${record.height}` : "크기 확인 전");
  setText("detailFileName", record?.name || "선택된 파일 없음");
  setText("detailMode", demo ? "시연 데이터 · 실제 검증 아님" : verified ? `실제 SDK 결과 · ${record.status} · ${analysis.trustProfile === "lab" ? "연구용 CA 정책" : "기본 신뢰 정책"}` : pending ? "이전 미검증 기록" : "분석 결과 대기");
  setText("detailRecordMeta", record ? `${formatDate(record.createdAt)} · 기록 ID ${record.id}` : "기록 없음");
  setText("evidenceTag", demo ? "시연 데이터" : verified ? record.status : "분석 대기");
  const uri = checkOutcome(checks, code => code.includes("hasheduri"));
  const signature = checkOutcome(checks, code => code.startsWith("claimsignature"));
  const timestamp = checkOutcome(checks, code => code.includes("timestamp"));
  const trust = checkOutcome(checks, code => code.startsWith("signingcredential") && !code.includes("ocsp"));
  const claimSummary = dataHash === "실패" || uri === "실패" ? "실패" : dataHash === "검증됨" && uri === "검증됨" ? "검증됨" : "확인되지 않음";
  const summaries = demo ? ["구조 예시", "연결 예시", "서명 예시", "신뢰 예시"] : verified
    ? [value === "NoManifest" ? "없음" : analysis.activeManifest ? "있음" : "확인 불가", claimSummary, signature, timestamp]
    : ["확인 전", "확인 전", "확인 전", "확인 전"];
  ["summaryManifest", "summaryClaim", "summarySignature", "summaryTimestamp"].forEach((id, index) => setText(id, summaries[index]));
  const signerUntrusted = checks.some(check => check.code === "signingCredential.untrusted");
  const evidence = verified ? [summaries[0], dataHash, uri, signature, timestamp, signerUntrusted ? "신뢰 미확인" : trust === "검증됨" ? "신뢰 확인" : trust] : Array(6).fill(demo ? "시연용" : "미실행");
  ["evidenceManifest", "evidenceAssertion", "evidenceClaim", "evidenceSignature", "evidenceTimestamp", "evidenceTrust"]
    .forEach((id, index) => setText(id, evidence[index]));
  renderPhotoInfo(record);
  renderProvenance(record);
  renderManifestData(record);
  $("detailButton").disabled = !record;
  $("exportRecordButton").disabled = !record;
  setText("exportRecordButton", verified ? "검증 보고서 JSON 저장" : "기록 JSON 저장");
  filterChecks($("[data-check-filter].is-active")?.dataset.checkFilter || "all");
}
function matchesRecord(record, query) {
  if (!query) return true;
  return [record.name, record.id, formatDate(record.createdAt), record.status, record.mime, record.analysis?.sha256, record.analysis?.signer]
    .some(value => String(value).toLocaleLowerCase("ko-KR").includes(query));
}
function filteredRecords(searchId, filterId, sortId) {
  const query = $(searchId).value.trim().toLocaleLowerCase("ko-KR");
  const status = $(filterId).value;
  const sort = $(sortId).value;
  const result = state.records.filter(record => matchesRecord(record, query) &&
    (status === "all" || record.kind === status || record.analysis?.state === status));
  if (sort === "name") result.sort((a, b) => a.name.localeCompare(b.name, "ko-KR"));
  else result.sort((a, b) => sort === "oldest" ? a.createdAt.localeCompare(b.createdAt) : b.createdAt.localeCompare(a.createdAt));
  return result;
}
function node(tag, className, value) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  element.textContent = value;
  return element;
}
function openRecord(id, page) { state.selectedId = id; renderRecord(); view(page); }

function renderOutputs() {
  const filtered = filteredRecords("outputSearch", "outputFilter", "outputSort");
  const container = $("outputCards");
  container.replaceChildren();
  filtered.forEach(record => {
    const verified = record.kind === "verified";
    const card = document.createElement("article");
    card.className = "output-card";
    const top = node("div", "output-top", "");
    top.append(node("span", "output-icon", "▧"), node("span", `record-status ${record.kind === "demo" ? "is-demo" : record.kind === "verified" ? `is-${record.analysis?.state?.toLowerCase() || ""}` : ""}`, record.status));
    const artifact = node("div", "artifact-placeholder", "");
    artifact.append(node("strong", "", verified ? "검증 보고서 JSON" : "결과물 미생성"),
      node("span", "", verified ? `SDK 검증 코드와 Manifest 데이터 · ${record.analysis?.algorithm || "서명 정보 없음"}` : "검증된 보고서가 없습니다."));
    const footer = node("div", "output-footer", "");
    const button = node("button", "text-action", "결과 보기 →");
    button.type = "button";
    button.addEventListener("click", () => openRecord(record.id, "result"));
    footer.append(node("span", "record-id", `ID ${record.id}`), button);
    if (verified && record.serverId) {
      const download = node("a", "text-action", "JSON 저장 ↓");
      download.href = `${REPORT_API_URL(record.serverId)}/download?format=json`;
      download.setAttribute("download", `c2pa-report-${record.serverId}.json`);
      footer.append(download);
    }
    const dimensions = record.width && record.height ? ` · ${record.width} × ${record.height}` : "";
    card.append(top, node("h2", "", record.name), node("p", "output-meta", `${formatDate(record.createdAt)} · ${formatSize(record.size)}${dimensions}`), artifact, footer);
    container.append(card);
  });
  setText("outputCount", `${filtered.length}개 기록`);
  $("outputEmpty").hidden = filtered.length !== 0;
}
function renderHistory() {
  const filtered = filteredRecords("historySearch", "historyFilter", "historySort");
  const container = $("historyRows");
  container.replaceChildren();
  filtered.forEach(record => {
    const row = node("div", "history-row", "");
    row.setAttribute("role", "row");
    const date = node("span", "", formatDate(record.createdAt));
    date.setAttribute("role", "cell");
    const image = node("span", "history-image", "");
    image.setAttribute("role", "cell");
    image.append(node("strong", "", record.name), node("small", "", `ID ${record.id}`));
    const status = node("span", `record-status ${record.kind === "demo" ? "is-demo" : record.kind === "verified" ? `is-${record.analysis?.state?.toLowerCase() || ""}` : ""}`, record.status);
    status.setAttribute("role", "cell");
    const artifact = node("span", "history-artifact", record.kind === "verified" ? "JSON 보고서" : "없음");
    artifact.setAttribute("role", "cell");
    const action = node("span", "", "");
    action.setAttribute("role", "cell");
    const button = node("button", "text-action", "상세 보기 →");
    button.type = "button";
    button.addEventListener("click", () => openRecord(record.id, "detail"));
    action.append(button);
    row.append(date, image, status, artifact, action);
    container.append(row);
  });
  setText("historyCount", `${filtered.length}개 기록`);
  $("historyEmpty").hidden = filtered.length !== 0;
}
function view(name) {
  if (!VIEWS.has(name)) name = "home";
  if (name === "outputs") renderOutputs();
  if (name === "history") renderHistory();
  $("resourceNav").hidden = !RESOURCE_VIEWS.has(name);
  if (name === "result" || name === "detail") ensureFull(currentRecord());
  $$("[data-view]").forEach(element => { element.hidden = element.dataset.view !== name; });
  $$("[data-nav]").forEach(button => {
    const active = button.dataset.nav === name || (name === "detail" && button.dataset.nav === "result") || (RESOURCE_VIEWS.has(name) && button.dataset.nav === "guide");
    button.classList.toggle("is-active", active);
    if (active) button.setAttribute("aria-current", "page"); else button.removeAttribute("aria-current");
  });
  $$("[data-resource-nav]").forEach(button => {
    const active = button.dataset.resourceNav === name;
    button.classList.toggle("is-active", active);
    if (active) button.setAttribute("aria-current", "page"); else button.removeAttribute("aria-current");
  });
  if (location.hash !== `#${name}`) history.replaceState(null, "", `#${name}`);
  window.scrollTo(0, 0);
}
function filterChecks(kind) {
  $$("[data-check]").forEach(row => { row.hidden = kind !== "all" && row.dataset.check !== kind; });
  $$("[data-check-filter]").forEach(button => {
    const active = button.dataset.checkFilter === kind;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  const visibleCount = $$("[data-check]").filter(row => !row.hidden).length;
  setText("checkCount", `${visibleCount}개 항목 · ${currentRecord()?.status || "분석 대기"}`);
}
function exportRecord() {
  const record = currentRecord();
  if (!record) return;
  if (record.kind === "verified" && record.serverId) {
    const link = document.createElement("a");
    link.href = `${REPORT_API_URL(record.serverId)}/download?format=json`;
    link.download = `c2pa-report-${record.serverId}.json`;
    document.body.append(link);
    link.click();
    link.remove();
    return;
  }
  const payload = {
    recordId: record.id,
    createdAt: record.createdAt,
    file: { name: record.name, type: record.mime, bytes: record.size, width: record.width, height: record.height },
    status: record.status,
    checks: {
      manifest: "미실행", assertion: "미실행", claim: "미실행",
      claimSignature: "미실행", timestamp: "미실행", tsaCa: "미실행"
    },
    note: "브라우저 기록만 내보낸 파일입니다. C2PA 검증 결과나 이미지 원본은 포함되지 않습니다."
  };
  const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `originlab-record-${record.id}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("원본 이미지가 없는 기록 JSON 저장을 요청했습니다.");
}
async function copyManifest() {
  const value = $("manifestJson").textContent;
  try {
    await navigator.clipboard.writeText(value);
    toast("Manifest JSON을 복사했습니다.");
  } catch { toast("복사할 수 없습니다. JSON 영역에서 직접 선택해 주세요."); }
}
async function checkEngine() {
  const notice = $("engineNotice");
  try {
    const response = await fetch(HEALTH_API_URL, { cache: "no-store" });
    const info = response.ok ? await response.json() : null;
    if (!info || info.status !== "ok") throw new Error("unavailable");
    notice.textContent = `● 실제 C2PA 검증 가능 · ${info.sdk || "SDK"} 연결됨`;
    notice.classList.add("is-online");
    state.aiAvailable = info.ai_generation === true;
    $("aiGenerate").disabled = !state.aiAvailable;
    setText("aiStatus", state.aiAvailable ? "이미지 설명을 입력해 생성하세요." : "AI 생성 API 연결 전 · 아래 AI 선언 샘플로 검증을 시험할 수 있습니다.");
  } catch {
    notice.textContent = "● 분석 엔진 연결 필요 · 검사를 실행하려면 통합 서버로 열어 주세요.";
    notice.classList.remove("is-online");
    state.aiAvailable = false;
    $("aiGenerate").disabled = true;
    setText("aiStatus", "분석 엔진에 연결한 뒤 사용할 수 있습니다.");
  }
}
function toggleAi(force) {
  const opening = typeof force === "boolean" ? force : $("aiPanel").hidden;
  $("aiPanel").hidden = !opening;
  $("aiToggle").classList.toggle("is-open", opening);
  $("aiToggle").setAttribute("aria-expanded", String(opening));
  $("aiToggle").setAttribute("aria-label", opening ? "AI 이미지 생성 창 닫기" : "AI 이미지 생성 창 열기");
  if (opening) $("aiPrompt").focus();
}
async function generateAiImage() {
  if (!state.aiAvailable) { toast("AI 생성 API가 연결되면 사용할 수 있습니다. 지금은 AI 선언 샘플을 검사해 보세요."); return; }
  const prompt = $("aiPrompt").value.trim();
  if (prompt.length < 8) { toast("이미지 설명을 8자 이상 입력해 주세요."); $("aiPrompt").focus(); return; }
  const button = $("aiGenerate");
  button.disabled = true;
  setText("aiStatus", "생성 요청 중…");
  try {
    const response = await fetch(AI_API_URL, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, style: $("aiStyle").value, aspect_ratio: $("aiRatio").value })
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const contentType = response.headers.get("content-type") || "";
    let blob;
    let name = "ai-generated.png";
    if (contentType.startsWith("image/")) {
      blob = await response.blob();
      name = `ai-generated.${blob.type.split("/")[1] || "png"}`;
    } else if (contentType.includes("application/json")) {
      const data = await response.json();
      if (typeof data.image_url !== "string") throw new Error("image_url missing");
      const imageResponse = await fetch(data.image_url);
      if (!imageResponse.ok) throw new Error("image download failed");
      blob = await imageResponse.blob();
      name = data.file_name || name;
    } else throw new Error("unsupported content type");
    if (!ALLOWED_TYPES.has(blob.type) || blob.size > MAX_BYTES) throw new Error("unsupported image");
    clearGeneratedImage();
    state.generatedBlob = blob;
    state.generatedName = name;
    state.generatedUrl = URL.createObjectURL(blob);
    $("aiPreview").src = state.generatedUrl;
    $("aiPreview").hidden = false;
    $("aiEmpty").hidden = true;
    $("useAiImage").disabled = false;
    toast("이미지가 생성되었습니다. 검사에 사용할 수 있습니다.");
  } catch (error) {
    setText("aiStatus", "생성 API 연결 대기");
    toast("AI 이미지 생성 서버가 아직 연결되지 않았습니다.");
    console.info("AI endpoint unavailable:", error.message);
  } finally { button.disabled = false; }
}
function useGenerated() {
  if (!state.generatedBlob) return;
  selectFile(new File([state.generatedBlob], state.generatedName || "ai-generated.png", { type: state.generatedBlob.type }));
  clearGeneratedImage();
  toggleAi(false);
  view("home");
}
function init() {
  state.records = loadRecords();
  state.selectedId = state.records[0]?.id || null;
  const dropzone = $("dropzone");
  dropzone.addEventListener("click", () => $("fileInput").click());
  dropzone.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); $("fileInput").click(); } });
  $("fileInput").addEventListener("change", event => selectFile(event.target.files?.[0]));
  $("uploadPreview").addEventListener("load", () => {
    if (state.file) state.imageDimensions = { width: $("uploadPreview").naturalWidth, height: $("uploadPreview").naturalHeight };
  });
  ["dragenter", "dragover"].forEach(name => dropzone.addEventListener(name, event => { event.preventDefault(); dropzone.classList.add("is-dragging"); }));
  ["dragleave", "drop"].forEach(name => dropzone.addEventListener(name, event => { event.preventDefault(); dropzone.classList.remove("is-dragging"); }));
  dropzone.addEventListener("drop", event => selectFile(event.dataTransfer?.files?.[0]));
  $("sampleButton").addEventListener("click", showSample);
  $$('[data-verify-sample]').forEach(button => button.addEventListener("click", () => verifySample(button)));
  $$("[data-input-mode]").forEach(button => button.addEventListener("click", () => setInputMode(button.dataset.inputMode)));
  $("urlLoadButton").addEventListener("click", loadFromUrl);
  $("urlInput").addEventListener("keydown", event => { if (event.key === "Enter") loadFromUrl(); });
  $("removeButton").addEventListener("click", removeFile);
  $("inspectButton").addEventListener("click", inspectImage);
  $("detailButton").addEventListener("click", () => view("detail"));
  $("outputSearch").addEventListener("input", renderOutputs);
  $("historySearch").addEventListener("input", renderHistory);
  $("outputFilter").addEventListener("change", renderOutputs);
  $("outputSort").addEventListener("change", renderOutputs);
  $("historyFilter").addEventListener("change", renderHistory);
  $("historySort").addEventListener("change", renderHistory);
  $$("[data-check-filter]").forEach(button => button.addEventListener("click", () => filterChecks(button.dataset.checkFilter)));
  $$("[data-jump]").forEach(button => button.addEventListener("click", () => $(button.dataset.jump).scrollIntoView({ behavior: "smooth", block: "start" })));
  $("exportRecordButton").addEventListener("click", exportRecord);
  $("copyManifestButton").addEventListener("click", copyManifest);
  $$("[data-nav]").forEach(button => button.addEventListener("click", () => view(button.dataset.nav)));
  $$("[data-resource-nav]").forEach(button => button.addEventListener("click", () => view(button.dataset.resourceNav)));
  $$("[data-go]").forEach(button => button.addEventListener("click", () => view(button.dataset.go)));
  $("aiToggle").addEventListener("click", () => toggleAi());
  $("aiClose").addEventListener("click", () => toggleAi(false));
  $("aiGenerate").addEventListener("click", generateAiImage);
  $("useAiImage").addEventListener("click", useGenerated);
  document.addEventListener("keydown", event => { if (event.key === "Escape" && !$("aiPanel").hidden) toggleAi(false); });
  window.addEventListener("hashchange", () => view(location.hash.slice(1)));
  window.addEventListener("beforeunload", () => { releaseSelectedFile(); clearGeneratedImage(); });
  clearInputPreview();
  renderRecord();
  filterChecks("all");
  renderOutputs();
  renderHistory();
  view(location.hash.slice(1) || "home");
  checkEngine();
  syncServerHistory();
}
document.addEventListener("DOMContentLoaded", init);
