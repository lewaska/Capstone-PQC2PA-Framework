# Origin Lab · 이미지 C2PA 검증 웹

파란색 Origin Lab 화면에서 이미지를 업로드하면 같은 주소에서 실행되는 FastAPI 서버가 공식 `c2pa-python` SDK로 검사합니다. 화면은 결과 요약, 상세 검증 코드, Manifest JSON, 결과물, 실험 기록을 보여줍니다. [Metadata View](https://metadataview.com/c2pa)와 [C2PA Viewer](https://c2paviewer.com/)의 입력·결과 읽기 흐름을 참고해 별도로 디자인했습니다.

## 실행

프로젝트 최상위 폴더에서 실행합니다.

```bash
bash run-viewer.sh
```

브라우저 주소: <http://127.0.0.1:8765/>

새 컴퓨터에서 `.venv`가 없으면 실행 스크립트가 가상환경을 만들고 `requirements.txt`의 패키지를 설치합니다. 포트 변경: `C2PA_PORT=8766 bash run-viewer.sh`.

`python3 -m http.server`로 이 프런트엔드 폴더만 열면 검증 API가 없으므로 검사가 작동하지 않습니다.

## 사용 방법

1. JPG, PNG, WebP, AVIF 이미지 한 장을 선택하거나 드래그합니다. URL 입력은 브라우저가 해당 사이트에서 이미지를 읽을 수 있을 때만 사용합니다. 화면과 이미지 전용 API의 입력 한도는 20 MB입니다.
2. **검사 실행**을 누르면 파일을 `/engine/api/verify-image`로 보내고 기본 SDK 정책(`standard`)으로 검사합니다. 서버는 실제 이미지 내용·확장자·MIME·손상 여부를 확인합니다.
3. **결과**에서 `Trusted`, `Valid`, `Invalid`, `NoManifest` 등 C2PA 상태와 함께 실제 이미지의 형식·해상도·색상·촬영/제작 메타데이터·파일 전체 SHA-256 및 SHA3-256 체크섬을 확인합니다. C2PA가 없는 사진도 파일 정보는 표시됩니다.
4. **상세 결과**에서 서명자·발급자·제작 도구·작업 이력, 각 SDK 검증 코드와 설명, Manifest JSON을 확인하거나 JSON 보고서를 저장합니다.
5. **결과물**과 **실험 기록**에서 파일명·상태·해시·서명자 등을 검색하고 상태별로 필터링합니다.

`Valid`는 암호학적 서명·무결성이 유효해도 서명자 신뢰가 확인되지 않았을 수 있음을 뜻합니다. `NoManifest`는 C2PA 정보가 없다는 뜻이며 조작 판정이 아닙니다. **예시 결과 보기**는 화면 시연용 데이터입니다.

파일이 없어도 화면 아래 **실제 검증 샘플**에서 정상 서명·변조된 이미지·C2PA 없음·AI 생성 선언 버튼을 눌러 테스트할 수 있습니다. 샘플 버튼은 포함된 실험용 CA를 쓰는 `lab` 신뢰 정책으로 검사하므로 정상 서명 샘플은 `Trusted`가 됩니다. 사용자가 올린 이미지는 기본 `standard` 정책으로 검사합니다. AI 생성 선언 샘플은 OpenAI 서명 이미지이며 일반 신뢰 설정에서 `Valid`로 판정됩니다.

업로드 원본은 서버의 임시 파일로 분석한 뒤 삭제합니다. 사용자의 컴퓨터에 있는 파일 자체는 삭제하지 않습니다. 로컬 서버의 SQLite에는 보고서와 작은 축소 미리보기가, 브라우저 저장소에는 결과 요약이 남습니다. JSON 보고서에는 파일명·Manifest 등의 정보가 포함될 수 있습니다.

현재 C2PA 검증은 기존 C2PA SDK의 알고리즘과 기본 신뢰 정책을 사용합니다. 화면의 SHA3-256은 **파일 전체 체크섬**이며 C2PA Claim용 SHA-3이나 ML-DSA 서명 검증이 아닙니다. SHA-3 Claim, ML-DSA, 자체 TSA·CA 검증은 연구 확장 항목입니다. AI 이미지 생성 버튼은 생성 API가 없을 때 비활성화되고 연결 상태를 표시합니다.

## 관련 파일

```text
run-viewer.sh             통합 서버 실행
viewer_server.py          이 화면과 검증 API를 한 주소에 제공
backend/                  실제 C2PA SDK 검증, 보고서 저장
pqc-c2pa-web/index.html   화면 구조
pqc-c2pa-web/styles.css   반응형 디자인
pqc-c2pa-web/app.js       업로드, 결과, 기록, 보고서 동작
pqc-c2pa-web/resources.js 지원 기기·서비스와 코드 예제 동작
tests/test_viewer_integration.py 통합 검증 테스트
```

전체 백엔드와 API 설명은 프로젝트 최상위 [README](../README.md)에 있습니다.
