"""Create real signed/unsigned/tampered fixtures with a dedicated lab CA.

Private keys exist only in memory and are never saved. Not production credentials.
"""
import io
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import c2pa
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]


def create():
    dest = ROOT / "samples"
    dest.mkdir(exist_ok=True)
    now = datetime.now(timezone.utc)
    ca_key = ec.generate_private_key(ec.SECP256R1())
    leaf_key = ec.generate_private_key(ec.SECP256R1())
    ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "C2PA Lab Experimental Root"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Capstone C2PA Lab")])
    ca = (x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name).public_key(ca_key.public_key())
        .serial_number(x509.random_serial_number()).not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=1), critical=True)
        .add_extension(x509.KeyUsage(False, False, False, False, False, True, True, False, False), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), critical=False)
        .sign(ca_key, hashes.SHA256()))
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "C2PA Lab Test Signer"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Capstone C2PA Lab")])
    leaf = (x509.CertificateBuilder().subject_name(name).issuer_name(ca_name).public_key(leaf_key.public_key())
        .serial_number(x509.random_serial_number()).not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(True, False, False, False, False, False, False, False, False), critical=True)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.EMAIL_PROTECTION]), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(leaf_key.public_key()), critical=False)
        .sign(ca_key, hashes.SHA256()))
    pem = serialization.Encoding.PEM
    (dest / "lab-root.pem").write_bytes(ca.public_bytes(pem))
    cert = leaf.public_bytes(pem) + ca.public_bytes(pem)
    key = leaf_key.private_bytes(pem, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    # A real, generated calibration image, not a copied asset.
    image = Image.new("RGB", (1200, 800), "#edf2e8")
    draw = ImageDraw.Draw(image)
    for x in range(1200):
        draw.line((x, 0, x, 800), fill=(225 - x // 30, 237 - x // 50, 222 - x // 60))
    draw.ellipse((400, 135, 800, 535), fill="#184c3b")
    draw.ellipse((500, 235, 700, 435), fill="#c8e8a0")
    draw.text((65, 690), "C2PA LAB / SIGNATURE CALIBRATION / 01", fill="#184c3b", font_size=28)
    image.save(dest / "unsigned.jpg", quality=90)
    manifest = {"claim_generator_info": [{"name": "C2PA Lab", "version": "1.0.0"}],
        "title": "Lab calibration image", "format": "image/jpeg",
        "assertions": [{"label": "c2pa.actions.v2", "data": {"actions": [{"action": "c2pa.created",
            "softwareAgent": "C2PA Lab sample generator",
            "digitalSourceType": "http://cv.iptc.org/newscodes/digitalsourcetype/digitalArt"}]}}]}
    signer_info = c2pa.C2paSignerInfo(alg="es256", sign_cert=cert, private_key=key, ta_url=None)
    with c2pa.Signer.from_info(signer_info) as signer:
        with c2pa.Builder(manifest) as builder:
            with (dest / "unsigned.jpg").open("rb") as source, (dest / "signed.jpg").open("wb") as out:
                builder.sign(signer, "image/jpeg", source, out)
    # Keep APP11/JUMBF metadata byte-for-byte, replace only encoded image data.
    signed = (dest / "signed.jpg").read_bytes()
    with Image.open(io.BytesIO(signed)) as modified:
        modified = modified.convert("RGB")
        ImageDraw.Draw(modified).rectangle((560, 300, 640, 380), fill="#ee7755")
        output = io.BytesIO()
        modified.save(output, format="JPEG", quality=90)
    replacement = output.getvalue()
    metadata = bytearray()
    pos = 2
    while signed[pos:pos + 2] != b"\xff\xda":
        length = int.from_bytes(signed[pos + 2:pos + 4], "big")
        marker = signed[pos + 1]
        if 0xE0 <= marker <= 0xEF:
            metadata.extend(signed[pos:pos + length + 2])
        pos += length + 2
    # Insert original APP metadata into the recompressed valid JPEG.
    (dest / "tampered.jpg").write_bytes(replacement[:2] + metadata + replacement[2:])
    print("Created signed.jpg, tampered.jpg, unsigned.jpg and lab-root.pem")


if __name__ == "__main__":
    create()
