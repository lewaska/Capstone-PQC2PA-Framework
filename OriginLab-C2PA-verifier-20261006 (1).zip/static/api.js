"use strict";
const byId=id=>document.getElementById(id);
byId("api-operation").onchange=()=>{const value=byId("api-operation").value;byId("api-file-panel").hidden=value!=="verify";byId("api-asset-panel").hidden=value!=="asset";byId("api-url-panel").hidden=value!=="url";byId("api-sample-panel").hidden=value!=="sample";};
byId("api-form").onsubmit=async event=>{
  event.preventDefault(); const button=byId("api-run");button.disabled=true;byId("api-status").textContent="요청 실행 중…";
  try{
    const operation=byId("api-operation").value, trust=byId("api-trust").value;
    let path="/api/health",options={};
    if(operation==="verify"){const file=byId("api-file").files[0];if(!file)throw new Error("파일을 선택해주세요.");const form=new FormData();form.append("file",file);form.append("trust_profile",trust);path="/api/verify";options={method:"POST",body:form};}
    if(operation==="asset"){const file=byId("api-asset-file").files[0];if(!file)throw new Error("보관할 원본 파일을 선택해주세요.");const form=new FormData();form.append("file",file);form.append("label",byId("api-asset-label").value);path="/api/assets";options={method:"POST",body:form};}
    if(operation==="assets")path="/api/assets";
    if(operation==="url"){path="/api/verify-url";options={method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:byId("api-url").value,trust_profile:trust})};}
    if(operation==="sample"){path=`/api/samples/${byId("api-sample").value}/verify?trust_profile=${trust}`;options={method:"POST"};}
    if(operation==="history")path="/api/history";
    const response=await fetch(path,options),data=await response.json();byId("api-status").textContent=`${options.method||"GET"} ${path} → HTTP ${response.status}`;byId("api-response").textContent=JSON.stringify(data,null,2);
  }catch(error){byId("api-status").textContent=error.message;}finally{button.disabled=false;}
};
fetch("/openapi.json").then(response=>response.json()).then(schema=>{
  for(const [path,operations]of Object.entries(schema.paths))for(const [method,info]of Object.entries(operations)){
    const article=document.createElement("article"),heading=document.createElement("h2"),body=document.createElement("pre");heading.textContent=`${method.toUpperCase()} ${path}`;heading.className="api-endpoint-title";body.className="raw-json";body.textContent=JSON.stringify(info,null,2);article.append(heading,body);byId("api-endpoints").append(article);
  }
}).catch(error=>{byId("api-endpoints").textContent=error.message;});
