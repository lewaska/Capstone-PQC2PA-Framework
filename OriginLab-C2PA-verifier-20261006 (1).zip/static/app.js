"use strict";
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const formatBytes = n => n >= 1024 * 1024 ? (n / 1024 / 1024).toFixed(1) + " MB" : (n / 1024).toFixed(1) + " KB";
const states = {Trusted:["신뢰된 서명","trusted"], Valid:["유효 · 신뢰 미확인","valid"], Invalid:["검증 실패","invalid"], NoManifest:["C2PA 없음","none"], Error:["분석 오류","error"], Unknown:["상태 미확인","unknown"], RemoteUnavailable:["외부 매니페스트 필요","unknown"]};
const badge = state => {const [label, cls] = states[state] || states.Unknown; return `<span class="badge ${cls}">${label}</span>`;};
let current = null, batch = [], busy = false, activeDetail = "overview", jsonMode = "raw", localPreviews = new Map();
let toastTimer, profileExplicit = false;

function toast(message) {
  $("#toast").textContent = message; $("#toast").hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $("#toast").hidden = true, 3500);
}
async function request(path, options = {}) {
  const response = await fetch(path, options);
  let body;
  try { body = await response.json(); } catch { throw new Error(`서버 응답 오류 (${response.status})`); }
  if (!response.ok) throw new Error(typeof body.detail === "string" ? body.detail : `요청을 처리할 수 없습니다 (${response.status}).`);
  return body;
}
function setBusy(value, message = "") {
  busy = value;
  $$(".sample, #url-panel button, #file-input, #trust-profile").forEach(el => el.disabled = value);
  $("#dropzone").setAttribute("aria-busy", String(value));
  if (value) { $("#status").hidden = false; $("#status").className = "status"; $("#status").innerHTML = `<span class="spinner" aria-hidden="true"></span>${escapeHTML(message)}`; }
  else $("#status").hidden = true;
}
function showError(message) {
  $("#status").hidden = false; $("#status").className = "status error"; $("#status").textContent = message;
}
function clearPreviews() { for (const url of localPreviews.values()) URL.revokeObjectURL(url); localPreviews.clear(); }
function resetBatch() { clearPreviews(); batch = []; $("#results").hidden = true; current = null; }
function updateLocation(result) {
  const url = new URL(location.href); url.search = ""; url.searchParams.set("report", result.id); history.replaceState(null, "", url);
}
function showResult(result, scroll = true) {
  current = result; updateLocation(result); $("#results").hidden = false;
  $("#copy-url-link").hidden = !result.source_url;
  const signature = result.signature || {};
  const name = result.software?.map(s => s.name).filter(Boolean).join(", ") || "정보 없음";
  const imageURL = result.thumbnail;
  let preview = imageURL ? `<img class="preview" src="${escapeHTML(imageURL)}" alt="검증한 파일의 미리보기">` : `<div class="preview preview-placeholder">${escapeHTML(result.mime || "FILE")}</div>`;
  const localURL = localPreviews.get(result.id);
  if (localURL && result.mime?.startsWith("video/")) preview = `<video class="preview" src="${escapeHTML(localURL)}" controls preload="metadata"></video>`;
  if (localURL && result.mime?.startsWith("audio/")) preview = `<audio src="${escapeHTML(localURL)}" controls preload="metadata"></audio>`;
  const stateNotice = result.state === "NoManifest" ? "C2PA 매니페스트를 찾지 못했습니다. 정보가 없다는 사실만으로 가짜·변조 여부를 판단할 수 없습니다." : result.state === "Invalid" ? "검증 오류가 발견되었습니다. 아래 개별 코드를 확인하세요. 인증서 신뢰 문제와 파일 변조는 서로 다른 원인입니다." : "검증 상태는 선택한 신뢰 정책에 따라 달라집니다. 콘텐츠 내용의 사실 여부를 보증하지 않습니다.";
  $("#result-summary").innerHTML = `<div class="result-summary">${preview}<div><div class="summary-title"><div><h3>${escapeHTML(result.filename)}</h3><p>${escapeHTML(result.mime)} · ${formatBytes(result.size)}${result.dimensions ? ` · ${result.dimensions.join(" × ")}` : ""} · ${result.elapsed_ms} ms</p></div>${badge(result.state)}</div><div class="summary-fields"><div><small>서명자</small><strong>${escapeHTML(signature.common_name || signature.issuer || "정보 없음")}</strong></div><div><small>제작 도구</small><strong>${escapeHTML(name)}</strong></div><div><small>서명 알고리즘</small><strong>${escapeHTML(signature.alg || "정보 없음")}</strong></div><div><small>AI 생성 선언</small><strong>${result.ai === "declared" ? "AI 생성·편집 선언 있음" : "확인 가능한 선언 없음"}</strong></div><div><small>신뢰 정책</small><strong>${result.trust_profile === "lab" ? "기본 목록 + 실험 CA" : "기본 SDK 신뢰 목록"}</strong></div><div><small>매니페스트</small><strong>${result.manifest_count || 0}개 ${result.embedded === true ? "· 파일에 포함" : ""}</strong></div><div><small>검증 시각</small><strong>${escapeHTML(new Date(result.created_at).toLocaleString("ko-KR"))}</strong></div></div><p class="notice">${stateNotice}</p>${result.asset_id ? '<button id="result-asset" class="secondary">등록된 원본 자료 보기 →</button>' : ''}<p class="digest">SHA-256 ${escapeHTML(result.sha256)}</p></div></div>`;
  if (result.asset_id) $("#result-asset").onclick = () => showPage("assets");
  if (result.error) { const error = document.createElement("p"); error.className = "error-banner"; error.textContent = result.error; $("#result-summary").prepend(error); }
  renderBatch(); renderDetail();
  if (scroll) $("#results").scrollIntoView({behavior:"smooth",block:"start"});
}
function renderBatch() {
  const list = $("#batch-list"); list.hidden = batch.length < 2; list.replaceChildren();
  batch.forEach(item => {
    const button = document.createElement("button"); button.textContent = item.filename + " · " + (item.error ? "요청 실패" : (states[item.state] || states.Unknown)[0]);
    button.className = item.id === current?.id ? "selected" : "";
    button.onclick = () => item.id ? showResult(item, false) : showError(item.error); list.append(button);
  });
}
async function updateHistory() {
  const params = new URLSearchParams({q:$("#history-search").value.trim(),state:$("#history-state").value,
    trust_profile:$("#history-trust").value,limit:"200"});
  try { const rows = await request("/api/history?"+params); if (!params.get("q") && !params.get("state") && !params.get("trust_profile")) $("#history-count").textContent = rows.length;
    $("#history-search-note").textContent = `${rows.length}건 표시 · 최대 200건`; renderHistory(rows); }
  catch (error) { $("#history-list").textContent = error.message; }
}
async function updateAssets() {
  const q = $("#asset-search").value.trim();
  try { const rows = await request("/api/assets?"+new URLSearchParams({q,limit:"200"}));
    if (!q) $("#asset-count").textContent = rows.length; $("#asset-search-note").textContent = `${rows.length}건 표시 · 최대 200건`;
    renderAssets(rows);
  } catch (error) { $("#asset-list").textContent = error.message; }
}
function renderAssets(rows) {
  const root = $("#asset-list"); root.replaceChildren();
  if (!rows.length) { root.innerHTML='<p class="empty">등록된 자료가 없습니다. 원본 파일을 등록하면 이곳에 표시됩니다.</p>'; return; }
  for (const asset of rows) {
    const article=document.createElement("article"); article.className="asset-item";
    article.innerHTML=`<div class="asset-item-head"><div><h3>${escapeHTML(asset.label)}</h3><p>${escapeHTML(asset.filename)} · ${formatBytes(asset.size)} · ${escapeHTML(new Date(asset.created_at).toLocaleString("ko-KR"))}</p></div>${asset.latest_state ? badge(asset.latest_state) : '<span class="badge none">검증 전</span>'}</div><div class="asset-meta"><span>출처 <b>${escapeHTML(asset.source || "미입력")}</b></span><span>검증 <b>${asset.verification_count||0}회</b></span><span>태그 <b>${escapeHTML(asset.tags.join(", ") || "없음")}</b></span></div>${asset.notes ? `<p class="asset-notes">${escapeHTML(asset.notes)}</p>` : ''}<div class="asset-actions"><label>신뢰 정책 <select class="asset-trust"><option value="standard">기본 SDK 목록</option><option value="lab">실험용 CA 포함</option></select></label><button class="asset-verify primary">저장된 원본 검증 →</button><a class="secondary" href="/api/assets/${encodeURIComponent(asset.id)}/download">원본 다운로드 ↓</a></div><details><summary>SHA-256 및 자료 ID</summary><p class="digest">${escapeHTML(asset.sha256)}<br>${escapeHTML(asset.id)}</p></details>`;
    article.querySelector(".asset-verify").onclick=async()=>{
      const button=article.querySelector(".asset-verify");button.disabled=true;button.textContent="검증 중…";
      try {const trust=article.querySelector(".asset-trust").value;
        const result=await request(`/api/assets/${encodeURIComponent(asset.id)}/verify?trust_profile=${trust}`,{method:"POST"});
        resetBatch();batch=[result];showPage("verify");showResult(result);await updateHistory();await updateAssets();}
      catch(error){toast(error.message);}finally{button.disabled=false;button.textContent="저장된 원본 검증 →";}
    };
    root.append(article);
  }
}
async function verifyFiles(files) {
  if (busy || !files.length) return;
  if (files.length > 10) { showError("한 번에 최대 10개 파일을 선택해주세요."); return; }
  const trust = $("#trust-profile").value;
  resetBatch();
  let firstSuccess;
  for (const [index, file] of [...files].entries()) {
    setBusy(true, `${index + 1}/${files.length} · ${file.name} 분석 중 — 매니페스트와 서명을 검증합니다.`);
    try {
      if (file.size > 500 * 1024 * 1024) throw new Error("파일당 최대 500 MB까지 허용합니다.");
      const form = new FormData(); form.append("file",file); form.append("trust_profile",trust);
      const result = await request("/api/verify",{method:"POST",body:form});
      localPreviews.set(result.id, URL.createObjectURL(file)); batch.push(result);
      firstSuccess ||= result; showResult(firstSuccess, false);
    } catch (error) { batch.push({filename:file.name,error:error.message}); renderBatch(); }
  }
  setBusy(false); $("#file-input").value = "";
  const errors = batch.filter(item => !item.id);
  if (errors.length) showError(errors.map(item => `${item.filename}: ${item.error}`).join(" / "));
  if (firstSuccess) showResult(firstSuccess);
  await updateHistory();
}
async function verifyURL(url) {
  if (busy) return;
  resetBatch(); setBusy(true,"URL에서 파일을 가져와 C2PA 서명과 매니페스트를 분석하고 있습니다.");
  try {
    const result = await request("/api/verify-url",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url,trust_profile:$("#trust-profile").value})});
    batch.push(result); showResult(result); setBusy(false); await updateHistory();
  } catch(error) { setBusy(false); showError(error.message); }
}
function renderDetail() {
  if (!current) return;
  $$("[data-detail]").forEach(button => button.setAttribute("aria-selected", String(button.dataset.detail === activeDetail)));
  const panel = $("#detail-panel"); panel.replaceChildren();
  if (activeDetail === "overview") {
    const checks = current.checks || [];
    const pass = checks.filter(check => check.kind === "success").length;
    const fail = checks.filter(check => check.kind === "failure").length;
    panel.innerHTML = `<h3>검증 항목 ${checks.length}개 · 통과 ${pass} · 오류 ${fail}</h3><p class="notice">외부 매니페스트와 OCSP(온라인 인증서 폐기 상태)는 조회하지 않았습니다. 서명 시간은 인증된 타임스탬프 결과와 함께 해석하세요.</p>`;
    if (!checks.length) panel.innerHTML += `<p class="empty">${current.state === "NoManifest" ? "매니페스트가 없어 서명 검증 항목이 없습니다." : "개별 검증 결과가 제공되지 않았습니다."}</p>`;
    for (const check of checks) panel.innerHTML += `<div class="check-row"><span class="check-dot ${escapeHTML(check.kind)}"></span><div><strong>${escapeHTML(check.code)}</strong><p>${escapeHTML(check.explanation || "설명 없음")}</p><small>${escapeHTML(check.scope)} · ${escapeHTML(check.kind)}</small></div></div>`;
  } else if (activeDetail === "actions") {
    panel.innerHTML = `<h3>제작·편집 작업 ${(current.actions || []).length}개</h3>`;
    const names = {"c2pa.created":"콘텐츠 생성","c2pa.edited":"콘텐츠 편집","c2pa.opened":"파일 열기","c2pa.placed":"재료 삽입","c2pa.resized":"크기 조정","c2pa.cropped":"자르기","c2pa.published":"발행","c2pa.converted":"형식 변환"};
    for (const [index, action] of (current.actions || []).entries()) panel.innerHTML += `<div class="timeline-item"><span class="timeline-number">${index+1}</span><div><strong>${escapeHTML(names[action.action] || action.action)}</strong><p>${escapeHTML(action.action)}<br>제작 도구: ${escapeHTML(typeof action.softwareAgent === "object" ? JSON.stringify(action.softwareAgent) : action.softwareAgent || "정보 없음")}<br>시각: ${escapeHTML(action.when || "정보 없음")}<br>디지털 출처 선언: ${escapeHTML(action.digitalSourceType || "정보 없음")}</p>${action.parameters ? `<details><summary>작업 파라미터</summary><pre>${escapeHTML(JSON.stringify(action.parameters,null,2))}</pre></details>` : ""}</div></div>`;
    if (!current.actions?.length) panel.innerHTML += '<p class="empty">기록된 편집 이력이 없습니다.</p>';
  } else if (activeDetail === "provenance") {
    panel.innerHTML = '<h3>출처와 연결된 매니페스트</h3><p class="notice">기록된 재료와 매니페스트를 연결합니다. 참조만 있는 재료의 원본은 이 파일 안에 없을 수 있습니다.</p>';
    const store = current.store || {}, manifests = store.manifests || {};
    const visited = new Set();
    function node(label, depth = 0) {
      if (visited.has(label) || depth > 20) return; visited.add(label);
      const manifest = manifests[label]; if (!manifest) return;
      const section = document.createElement("article"); section.className = "provenance-node" + (label === store.active_manifest ? " active" : "");
      section.style.marginLeft = `${Math.min(depth, 4) * 16}px`;
      section.innerHTML = `<small>${label === store.active_manifest ? "THIS FILE / 활성 매니페스트" : "INGREDIENT / 재료 매니페스트"}</small><h4>${escapeHTML(manifest.title || label)}</h4><p>서명자: ${escapeHTML(manifest.signature_info?.common_name || manifest.signature_info?.issuer || "정보 없음")}<br>${escapeHTML(manifest.format)}<br>${escapeHTML(label)}</p><button>이 매니페스트 JSON 보기</button>`;
      section.querySelector("button").onclick = () => { activeDetail = "manifest"; renderDetail(); $("#json-search").value = label; renderJSON(); };
      panel.append(section);
      for (const ingredient of manifest.ingredients || []) {
        const reference = ingredient.active_manifest || ingredient.c2pa_manifest;
        const matched = typeof reference === "string" ? Object.keys(manifests).find(key => key === reference || reference.includes(key)) : null;
        if (matched) node(matched, depth+1);
        else { const item = document.createElement("article"); item.className = "provenance-node"; item.style.marginLeft = `${Math.min(depth+1,4)*16}px`; item.innerHTML = `<small>REFERENCED INGREDIENT</small><h4>${escapeHTML(ingredient.title || "이름 없는 재료")}</h4><p>${escapeHTML(ingredient.relationship || "관계 정보 없음")} · ${escapeHTML(ingredient.format || "")}<br>원본 매니페스트: ${escapeHTML(reference || "파일 안에 포함되지 않음")}</p>`; panel.append(item); }
      }
    }
    node(store.active_manifest); Object.keys(manifests).forEach(label => node(label));
    if (!Object.keys(manifests).length) panel.innerHTML += '<p class="empty">표시할 출처 매니페스트가 없습니다.</p>';
    else if (!current.ingredients?.length) panel.innerHTML += '<p class="notice">활성 매니페스트에 기록된 이전 재료가 없습니다.</p>';
  } else {
    panel.innerHTML = '<div class="json-tools"><input id="json-search" type="search" placeholder="키 또는 값 검색…" aria-label="매니페스트 JSON 검색"><button id="json-raw">Raw JSON</button><button id="json-tree">Tree</button><button id="json-copy">전체 복사</button><button id="json-download">매니페스트 다운로드</button></div><div id="json-content"></div>';
    $("#json-search").oninput = renderJSON;
    $("#json-raw").onclick = () => {jsonMode="raw"; renderJSON();}; $("#json-tree").onclick = () => {jsonMode="tree"; renderJSON();};
    $("#json-copy").onclick = () => copyText(JSON.stringify(current.store,null,2));
    $("#json-download").onclick = () => downloadJSON(current.store,`manifest-${current.id}.json`);
    renderJSON();
  }
}
function renderJSON() {
  const root = $("#json-content"), query = $("#json-search").value.trim().toLowerCase(); root.replaceChildren();
  $("#json-raw").classList.toggle("selected",jsonMode==="raw"); $("#json-tree").classList.toggle("selected",jsonMode==="tree");
  const store = current.store || {};
  if (query) {
    const matches = [];
    function walk(value,path = "$", depth=0) {
      if (depth > 60 || matches.length >= 200) return;
      if (value && typeof value === "object") for (const [key, child] of Object.entries(value)) {
        const childPath = `${path}.${key}`;
        if (key.toLowerCase().includes(query)) matches.push([childPath, typeof child === "object" ? JSON.stringify(child) : child]);
        else if (child === null || typeof child !== "object") { if (String(child).toLowerCase().includes(query)) matches.push([childPath,child]); }
        if (child && typeof child === "object") walk(child,childPath,depth+1);
      }
    }
    walk(store); root.className = "search-results";
    if (!matches.length) root.textContent = "검색 결과가 없습니다.";
    for (const [path,value] of matches) {const row = document.createElement("div"); row.className="search-match"; const heading = document.createElement("b"); heading.textContent=path; row.append(heading,document.createTextNode(String(value))); root.append(row);}
    if (matches.length >= 200) {const note=document.createElement("p");note.textContent="검색 결과는 최대 200개까지 표시합니다.";root.append(note);}
  } else if (jsonMode === "raw") {
    root.className = ""; const pre = document.createElement("pre"); pre.className="raw-json"; pre.textContent=JSON.stringify(store,null,2); root.append(pre);
  } else {
    root.className="json-tree";
    function tree(value,key,parent,depth=0) {
      if (depth > 60) {const note=document.createElement("span");note.textContent="더 깊은 데이터는 Raw JSON으로 확인하세요.";parent.append(note);return;}
      if (value && typeof value === "object") {
        const details=document.createElement("details"),summary=document.createElement("summary"); summary.textContent=`${key} ${Array.isArray(value) ? "["+value.length+"]" : "{"+Object.keys(value).length+"}"}`;details.append(summary);details.open=depth<2; parent.append(details);
        let rendered=false;
        const expand=()=>{if(rendered)return;rendered=true;for(const [k,v] of Object.entries(value))tree(v,k,details,depth+1);};
        details.addEventListener("toggle",()=>{if(details.open)expand();}); if(details.open)expand();
      } else { const row=document.createElement("div");row.className="json-leaf";row.textContent=key+": ";const span=document.createElement("span");span.textContent=JSON.stringify(value);row.append(span);parent.append(row); }
    }
    tree(store,"manifest_store",root);
  }
}
function downloadJSON(data,filename) {const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));const a=document.createElement("a");a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
async function copyText(value) {try {await navigator.clipboard.writeText(value);toast("클립보드에 복사했습니다.");}catch{toast("클립보드 권한을 확인해주세요. 주소창 링크도 사용할 수 있습니다.");}}
function renderHistory(rows) {
  const root=$("#history-list"); root.replaceChildren();
  if(!rows.length){root.innerHTML='<p class="empty">검색 조건에 맞는 기록이 없습니다.</p>';return;}
  root.innerHTML='<div class="table-scroll"><table class="history-table"><thead><tr><th>파일 / 서명자</th><th>검증 상태</th><th>시간 / 정책</th><th>보고서</th></tr></thead><tbody></tbody></table></div>';
  for(const row of rows){const tr=document.createElement("tr");tr.innerHTML=`<td><strong>${escapeHTML(row.filename)}</strong><p class="notice">${escapeHTML(row.signer || "서명자 정보 없음")} · ${formatBytes(row.size)} · ${row.elapsed_ms} ms</p></td><td>${badge(row.state)}</td><td>${escapeHTML(new Date(row.created_at).toLocaleString("ko-KR"))}<p class="notice">${row.trust_profile==="lab"?"실험 CA 포함":"기본 SDK 목록"}${row.asset_id ? " · 원본 보관" : ""}</p></td><td><button class="history-open">열기 ↗</button><button class="history-delete">삭제</button></td>`;
    tr.querySelector(".history-open").onclick=async()=>{try{const result=await request(`/api/reports/${row.id}`);showPage("verify");batch=[result];showResult(result);}catch(error){toast(error.message);}};
    tr.querySelector(".history-delete").onclick=async()=>{try{await request(`/api/reports/${row.id}`,{method:"DELETE"});if(current?.id===row.id){current=null;$("#results").hidden=true;history.replaceState(null,"",location.pathname);}await updateHistory();toast("검증 기록을 삭제했습니다.");}catch(error){toast(error.message);}};root.querySelector("tbody").append(tr);
  }
}
function showPage(name) {$$(".page").forEach(page=>page.hidden=page.id!==name+"-page");$$("[data-page]").forEach(button=>button.classList.toggle("active",button.dataset.page===name));if(name==="history")updateHistory();if(name==="assets")updateAssets();}
function setSource(name) {$("#upload-panel").hidden=name!=="upload";$("#url-panel").hidden=name!=="url";$("#upload-tab").setAttribute("aria-selected",String(name==="upload"));$("#url-tab").setAttribute("aria-selected",String(name==="url"));}
$$("[data-page]").forEach(button=>button.onclick=()=>showPage(button.dataset.page));
$("[data-open-assets]").onclick=()=>showPage("assets");
$("#history-search-button").onclick=updateHistory;
$("#history-reset").onclick=()=>{$("#history-search").value="";$("#history-state").value="";$("#history-trust").value="";updateHistory();};
$("#history-search").onkeydown=event=>{if(event.key==="Enter"){event.preventDefault();updateHistory();}};
$("#history-state").onchange=updateHistory;$("#history-trust").onchange=updateHistory;
$("#asset-search-button").onclick=updateAssets;
$("#asset-search").onkeydown=event=>{if(event.key==="Enter"){event.preventDefault();updateAssets();}};
$("#asset-form").onsubmit=async event=>{
  event.preventDefault();const files=[...$("#asset-files").files];if(!files.length)return;
  const submit=$("#asset-form button[type=submit]"), status=$("#asset-status");submit.disabled=true;status.hidden=false;
  const saved=[],duplicates=[],errors=[];
  for (const [index,file] of files.entries()) {
    status.textContent=`${index+1}/${files.length} · ${file.name} 저장 중…`;
    try {
      if(file.size>500*1024*1024)throw new Error("파일당 최대 500 MB까지 허용합니다.");
      const form=new FormData();form.append("file",file);form.append("label",files.length===1?$("#asset-label").value:"");
      form.append("source",$("#asset-source").value);form.append("tags",$("#asset-tags").value);form.append("notes",$("#asset-notes").value);
      const data=await request("/api/assets",{method:"POST",body:form});(data.duplicate?duplicates:saved).push(file.name);
    }catch(error){errors.push(`${file.name}: ${error.message}`);}
  }
  submit.disabled=false;$("#asset-files").value="";
  status.textContent=`새 자료 ${saved.length}개 저장 · 중복 ${duplicates.length}개${errors.length?` · 실패 ${errors.length}개: ${errors.join(" / ")}`:""}`;
  await updateAssets();
};
$("#upload-tab").onclick=()=>setSource("upload");$("#url-tab").onclick=()=>setSource("url");
$$("[data-detail]").forEach(button=>button.onclick=()=>{activeDetail=button.dataset.detail;renderDetail();});
// Native keyboard behavior for custom tabs.
$$("[role=tablist]").forEach(list=>{const tabs=[...list.querySelectorAll("[role=tab]")];list.addEventListener("keydown",event=>{const index=tabs.indexOf(document.activeElement);if(index<0)return;let next;if(event.key==="ArrowRight")next=(index+1)%tabs.length;else if(event.key==="ArrowLeft")next=(index-1+tabs.length)%tabs.length;else if(event.key==="Home")next=0;else if(event.key==="End")next=tabs.length-1;else return;event.preventDefault();tabs[next].focus();tabs[next].click();});});
$("#file-input").onchange=event=>verifyFiles(event.target.files);
for(const eventName of ["dragenter","dragover"]){$("#dropzone").addEventListener(eventName,event=>{event.preventDefault();if(!busy)$("#dropzone").classList.add("drag");});}
for(const eventName of ["dragleave","drop"]){$("#dropzone").addEventListener(eventName,event=>{event.preventDefault();$("#dropzone").classList.remove("drag");if(eventName==="drop"&&!busy)verifyFiles(event.dataTransfer.files);});}
$("#url-panel").onsubmit=event=>{event.preventDefault();verifyURL($("#url-input").value.trim());};
$("#trust-profile").onchange=()=>{profileExplicit=true;};
$$("[data-sample]").forEach(button=>button.onclick=async()=>{if(busy)return;resetBatch();const id=button.dataset.sample;if(!profileExplicit)$("#trust-profile").value="lab";const trust=$("#trust-profile").value;setBusy(true,`${button.querySelector("strong").textContent.replace("↗","").trim()} 샘플의 C2PA 서명을 분석하고 있습니다.`);try{const result=await request(`/api/samples/${id}/verify?trust_profile=${trust}`,{method:"POST"});batch.push(result);showResult(result);setBusy(false);await updateHistory();}catch(error){setBusy(false);showError(error.message);}});
$("#copy-link").onclick=()=>{if(current)copyText(`${location.origin}/?report=${current.id}`);};
$("#copy-url-link").onclick=()=>{if(current?.source_url){const url=new URL("/",location.origin);url.searchParams.set("url",current.source_url);url.searchParams.set("trust",current.trust_profile);copyText(url.href);}};
$("#export-json").onclick=()=>{if(current)location.href=`/api/reports/${current.id}/download?format=json`;};
$("#export-html").onclick=()=>{if(current)location.href=`/api/reports/${current.id}/download?format=html`;};
window.addEventListener("beforeunload",clearPreviews);
// Optional WebMCP integration in browsers implementing the proposed API.
if (navigator.modelContext?.registerTool) {
  navigator.modelContext.registerTool({name:"inspect_c2pa_url",description:"Verify a public HTTPS media URL with the local C2PA backend and display its report.",inputSchema:{type:"object",properties:{url:{type:"string"}},required:["url"]},execute:async({url})=>{if(busy)return{content:[{type:"text",text:"Verification already in progress"}]};showPage("verify");setSource("url");$("#url-input").value=url;await verifyURL(url);return{content:[{type:"text",text:JSON.stringify(current?{id:current.id,state:current.state,sha256:current.sha256}:{error:$("#status").textContent})}]};}});
}
async function init() {
  await updateHistory();
  const query=new URLSearchParams(location.search);
  if(query.has("report")){try{setBusy(true,"저장된 검증 보고서를 불러오는 중입니다.");const result=await request(`/api/reports/${encodeURIComponent(query.get("report"))}`);batch=[result];showResult(result,false);setBusy(false);}catch(error){setBusy(false);showError(error.message);}}
  else if(query.has("url")){setSource("url");if(["standard","lab"].includes(query.get("trust"))){$("#trust-profile").value=query.get("trust");profileExplicit=true;}$("#url-input").value=query.get("url");await verifyURL(query.get("url"));}
}
init();
