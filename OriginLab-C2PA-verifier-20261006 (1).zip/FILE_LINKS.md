# C2PA Lab 파일 및 링크 안내

## 실행 링크

- [현재 이미지 검증 웹](http://127.0.0.1:8765/)
- [이미지 검사 엔진 상태](http://127.0.0.1:8765/engine/api/health)
- [이미지 실험 기록](http://127.0.0.1:8765/engine/api/history)
- [AI 생성 선언 샘플](http://127.0.0.1:8765/engine/api/samples/ai/file)

기존 다중 매체 연구 웹을 `bash run.sh`로 실행할 때는 아래 8000 포트 링크를 사용합니다.

- [실험용 웹사이트](http://127.0.0.1:8000/)
- [API 문서 및 직접 실행](http://127.0.0.1:8000/docs)
- [OpenAPI 명세](http://127.0.0.1:8000/openapi.json)
- [SDK 상태 확인](http://127.0.0.1:8000/api/health)
- [샘플 목록](http://127.0.0.1:8000/api/samples)
- [실험 기록 JSON](http://127.0.0.1:8000/api/history)
- [등록 자료 JSON](http://127.0.0.1:8000/api/assets)

로컬 링크는 서버가 실행 중인 컴퓨터에서 사용할 수 있습니다. 외부 배포 주소가 아닙니다.

## 샘플 파일 링크

- [정상 서명 이미지](http://127.0.0.1:8000/api/samples/signed/file)
- [변조 이미지](http://127.0.0.1:8000/api/samples/tampered/file)
- [미서명 이미지](http://127.0.0.1:8000/api/samples/unsigned/file)

## 시작 방법

ZIP을 압축 해제한 뒤 프로젝트 폴더에서 실행합니다.

```bash
bash run-viewer.sh
```

처음 실행하면 Python 가상환경과 필요한 패키지를 설치합니다. Python 3.10 이상 및 첫 설치 시 인터넷 연결이 필요합니다. 이미 같은 폴더의 서버가 실행 중이면 웹사이트 링크를 바로 열면 됩니다. Windows 실행 방법은 README를 참고하세요.

## 파일 목록

| 파일 | 용도 |
| --- | --- |
| [README.md](README.md) | 설치, 실행, 기능, API, 제한 사항 설명 |
| [run-viewer.sh](run-viewer.sh) | 현재 이미지 검증 웹 실행 |
| [viewer_server.py](viewer_server.py) | 이미지 화면과 검증 API 통합 제공 |
| [pqc-c2pa-web/index.html](pqc-c2pa-web/index.html) | 현재 이미지 전용 웹 화면 |
| [pqc-c2pa-web/app.js](pqc-c2pa-web/app.js) | 이미지 검사·결과·검색 기능 |
| [pqc-c2pa-web/styles.css](pqc-c2pa-web/styles.css) | 파란색 반응형 디자인 |
| [run.sh](run.sh) | 기존 다중 매체 연구 웹 실행 |
| [requirements.txt](requirements.txt) | 실행에 필요한 Python 패키지 |
| [requirements-dev.txt](requirements-dev.txt) | 테스트용 패키지 |
| [.gitignore](.gitignore) | 가상환경과 실험 데이터의 Git 제외 규칙 |
| [backend/app.py](backend/app.py) | 업로드·URL 검증·원본 자료·검색·보고서 API와 웹서버 |
| [backend/engine.py](backend/engine.py) | 공식 C2PA SDK 검증 및 결과 정리 |
| [backend/image_info.py](backend/image_info.py) | 이미지 내용·형식·촬영 메타데이터 검사 |
| [backend/worker.py](backend/worker.py) | 검증 작업을 별도 프로세스에서 실행 |
| [backend/network.py](backend/network.py) | 공개 HTTPS 다운로드와 내부 주소 차단 |
| [backend/storage.py](backend/storage.py) | SQLite 실험 기록·자료 메타데이터 저장 및 원본 보관 |
| [backend/__init__.py](backend/__init__.py) | 백엔드 Python 패키지 |
| [static/index.html](static/index.html) | 한국어 검증 웹페이지 |
| [static/style.css](static/style.css) | 디자인과 반응형 레이아웃 |
| [static/app.js](static/app.js) | 자료 등록·원본 재검증·실험 기록 검색·상세 결과 화면 기능 |
| [static/docs.html](static/docs.html) | 로컬 API 문서 및 실행 화면 |
| [static/api.js](static/api.js) | API 문서 조회와 테스트 요청 |
| [static/favicon.svg](static/favicon.svg) | 사이트 아이콘 |
| [samples/signed.jpg](samples/signed.jpg) | 실제 C2PA 정상 서명 샘플 |
| [samples/tampered.jpg](samples/tampered.jpg) | 서명 후 픽셀이 변경된 변조 샘플 |
| [samples/unsigned.jpg](samples/unsigned.jpg) | C2PA 정보가 없는 샘플 |
| [samples/ai-han-river-sunrise.png](samples/ai-han-river-sunrise.png) | 실제 AI 생성 선언이 있는 C2PA 샘플 |
| [samples/lab-root.pem](samples/lab-root.pem) | 샘플 검증용 공개 루트 인증서 |
| [scripts/create_samples.py](scripts/create_samples.py) | 실험용 인증서와 세 가지 샘플 생성 |
| [tests/test_api.py](tests/test_api.py) | C2PA SDK 통합·API·경계조건 자동 테스트 |

## 참고 및 기술 문서

- [참고 웹사이트: C2PA Viewer](https://c2paviewer.com/)
- [C2PA 공식 사이트](https://c2pa.org/)
- [공식 C2PA Python SDK](https://github.com/contentauth/c2pa-python)
- [SDK 신뢰 정책 및 Context 설정](https://github.com/contentauth/c2pa-python/blob/main/docs/context-settings.md)
- [C2PA 기술 규격](https://spec.c2pa.org/)

## 검증 및 전달 범위

자동 테스트 37개가 통과했고 브라우저에서 실제 이미지 업로드, C2PA 없음 사진의 파일 정보·체크섬, AI 선언 샘플의 서명·작업 이력을 확인했습니다. 기존 다중 매체 화면의 등록·재검증·검색 기능도 유지합니다.

외부 매니페스트와 OCSP 조회는 수행하지 않습니다. 인증서 신뢰 결과는 선택한 정책과 SDK 설정에 따라 다를 수 있습니다.

ZIP에는 모든 프로젝트 소스, 실행 안내, 테스트, 샘플 파일과 공개 실험용 루트 인증서를 포함했습니다. 가상환경, Git 내부 파일, 캐시와 로컬 실험 결과 데이터베이스 및 등록된 원본은 제외했습니다. 개인 인증 키는 포함하지 않습니다.

보고서 링크는 `http://127.0.0.1:8000/?report=보고서ID` 형식이며 같은 로컬 서버의 저장된 데이터가 있어야 열립니다. 다른 컴퓨터로 보고서를 전달하려면 사이트에서 JSON 또는 HTML 보고서를 다운로드하세요.
