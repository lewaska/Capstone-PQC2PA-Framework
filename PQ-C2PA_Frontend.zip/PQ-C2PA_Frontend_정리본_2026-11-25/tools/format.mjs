/** 개발용 서식 도구다. 외부 라이브러리를 제외하고 직접 작성한 파일만 정리한다. */
import { readFile, writeFile, readdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import * as prettier from "prettier";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const config = JSON.parse(await readFile(path.join(root, ".prettierrc.json"), "utf8"));
const checkOnly = process.argv.includes("--check");
const files = [
  "frontend/index.html",
  "frontend/viewer/index.html",
  "frontend/viewer/viewer.css",
  "frontend/viewer/viewer.js",
  "frontend/viewer/conversion-v4.js",
  "frontend/viewer/unified-processing.js",
  "frontend/viewer/connection-status.js",
  "frontend/viewer/sample-client.js",
  "frontend/viewer/recovery-sample.js",
  "frontend/viewer/pdf-report.js",
  "tools/format.mjs",
  "package.json",
  ".prettierrc.json",
];

// 회귀 검사도 같은 들여쓰기 규칙으로 유지한다.
for (const name of await readdir(path.join(root, "frontend/tests"))) {
  if (name.endsWith(".test.cjs")) files.push(`frontend/tests/${name}`);
}

let changed = 0;
for (const relative of files) {
  const filename = path.join(root, relative);
  const current = await readFile(filename, "utf8");
  const formatted = await prettier.format(current, { ...config, filepath: filename });
  if (current === formatted) continue;
  changed += 1;
  if (checkOnly) console.error(`서식 확인 필요: ${relative}`);
  else await writeFile(filename, formatted);
}

console.log(`${files.length}개 파일 확인 · ${changed}개 ${checkOnly ? "서식 차이" : "정리"}`);
if (checkOnly && changed) process.exitCode = 1;
