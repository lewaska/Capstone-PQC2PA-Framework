# 현재 프론트엔드의 API 연결 안내

## 같은 출처 경로 유지

브라우저는 현재 웹사이트 주소를 기준으로 `/api/v1/...`, `/engine/api/...`를 호출한다. 예를 들어 화면이 `http://서버주소/viewer/#verify`이면 검사 요청은 `http://서버주소/api/v1/assets/inspect`로 나간다. 프론트에 서버 비밀키나 OpenAI 키를 넣지 않는다.

기존 통합 FastAPI 프로젝트에서는 `frontend/`를 교체하면 기존 API에 그대로 연결된다. 별도 정적 서버에 배포할 때는 정적 파일의 루트를 `frontend/`로 두고 두 API 접두 경로를 실제 백엔드로 전달한다. `viewer/`를 서버 루트로 잡으면 `/assets/`와 `/favicon.svg` 경로가 맞지 않는다.

예시 Nginx 설정은 다음과 같다. 경로와 백엔드 주소는 실제 값으로 바꾼다. 별도 인증·TLS 설정은 기존 운영 설정을 따른다.

```nginx
server {
    listen 80;
    server_name YOUR_HOST;
    root /var/www/pq-c2pa/frontend;
    index index.html;
    client_max_body_size 500m;

    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_read_timeout 300s;
    }
    location /engine/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_read_timeout 300s;
    }
    location / {
        try_files $uri $uri/ =404;
    }
}
```

## 화면에서 호출하는 경로

| 방식 | 경로 | 용도 |
|---|---|---|
| POST | `/api/v1/assets/inspect` | 파일의 Classic C2PA 검사 |
| POST | `/api/v1/conversions` | 일반 이미지의 보호·재사용·복구 작업 접수 |
| GET | `/api/v1/conversions/{conversion_id}` | 기존 작업 상태 조회 |
| GET | `/api/v1/conversions/{conversion_id}/asset` | 검증된 결과 이미지 다운로드 |
| GET | `/api/v1/validations/{validation_id}` | 응답에 ID가 있는 경우 기존 등록 검증 기록 조회 |
| POST | `/api/v1/samples/{sample_id}/conversions` | DB에 영구 저장하지 않는 샘플 작업 접수 |
| POST | `/api/v1/ai/summaries` | 검사 근거를 바탕으로 한 AI 요약·설명 |
| POST | `/api/v1/web-images/discover` | 게시물 본문의 이미지 주소 후보 수집 |
| POST | `/engine/api/verify-url` | 이미지 파일 URL의 Classic 검사 |
| GET | `/api/v1/connection-status` | 서비스별 설정·상태 확인 |
| GET | `/engine/api/health` | SDK와 검사 환경 정보 |
| GET | `/engine/api/samples/{sample_id}/file` | 공개 샘플 원본 파일 |
| POST | `/engine/api/report-issuances` | PDF 발급 번호·해시 등록 요청 |
| POST | `/engine/api/report-issuances/{doc_no}/finalize` | 완성된 PDF 해시와 크기 등록 |
| GET / DELETE | `/engine/api/reports/{id}` | 저장 보고서가 있는 경우 조회·삭제 |
| GET | `/engine/api/reports/{id}/download?format=html` | 서버에 저장된 HTML 보고서 |

일반 이미지 검사는 FormData의 `file`, `trust_profile=lab`, `save_report=false`를 사용한다. 샘플 검사에는 `sample_mode=true`를 추가한다. 일반 변환 접수는 `file`을 넣은 FormData이며 샘플 전용 변환 접수는 파일을 다시 전송하지 않는다.

## 검사와 PQC 응답

검사 상태는 `Trusted`, `Valid`, `Invalid`, `NoManifest`, `RemoteUnavailable`, `Error`, `Unknown`을 구분한다. 정규화 코드는 bare JSON과 `data` 래핑을 읽는다. 기존 상세 기능을 위해 `store`, `checks`, `signature`, `actions`, `ingredients`, `image_info`, `sha256`, `verification_timing` 등 실제 수집한 필드를 보존한다. 없는 값을 성공 정보로 채우지 않는다.

`checks`의 원래 `code`, `kind`, `scope`, 관련 `url`·설명을 유지한다. 화면에서 동일한 결과를 묶어도 원본 배열과 JSON은 바꾸지 않는다. 각 사진의 `verification_timing.started_at`, `completed_at`, `elapsed_ms`에는 해당 사진을 실제 검사한 서버 값이 들어가야 한다.

PQC 작업 계약의 기준은 `conversion-v4.js`의 `readJob()`과 `canDownload()`다. 응답은 `data.conversion_id`, `data.status`, `data.result`를 제공하며 완료 P1은 `profile=pq-c2pa-jumbf-haetae3-1`, `container=JUMBF`로 구분한다.

다운로드는 P1 서명·어설션·원본 근거·하드/소프트 바인딩과 Classic의 필수 검사가 실제로 통과한 결과에만 제공한다. 일반 작업은 DB 기록 쌍 ID를, 샘플은 `storage_mode=EPHEMERAL`과 임시 세션 ID를 사용한다. 이 조건은 어댑터의 원본 코드대로 유지한다.

`resolution_mode` 또는 `classic_action`으로 M1 생성·기존 매니페스트 재사용·기존 보호 재사용·Classic 복구를 구분한다. P1은 일반적으로 DB의 분리 기록이며 이미지 안에 들어 있다고 가정하지 않는다.

## AI 연결

AI 제공자 키와 모델 설정은 기존 AI 백엔드에서 관리한다. 프론트는 `POST /api/v1/ai/summaries`에 `{audience, report}`를 보내며 `report.explanation_context`의 사실과 근거 ID는 `summaryContext()`가 구성한다. 이미지·파일명·신청인 원문을 이 요청에 추가하지 않는다.

응답은 `data.summary`와 선택적인 `data.explanation`을 제공한다. 구조화 설명의 `summary`, `meaning`, `findings`, `next_step`, `limit`를 읽고 근거 ID를 확인한다. 잘못된 응답은 기본 해설로 처리하며 실제 SDK 판정을 덮어쓰지 않는다. `supportedNextStep()`은 실제 사이트의 다운로드·검사 상세 확인만 후속 행동으로 안내한다.

AI가 미설정이면 기본 해설임을 표시한다. 게시물 사진 추출은 서버 HTML 분석이고 그 검사 결과를 설명하는 단계에 AI가 사용된다.

## PDF 발급

PDF 문서 자체는 `pdf-report.js`가 브라우저에서 작성한다. 발급 API에는 검사 요약과 해시를 전송하고 신청인 이름·전화번호·제출처·확인 요청 원문은 넣지 않는다. 서버 등록에 실패하면 미등록 상태를 명시한 PDF를 작성할 수 있다. 샘플은 발급 등록을 요청하지 않는다.
