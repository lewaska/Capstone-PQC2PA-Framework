# 실제 배포할 프론트엔드

최신 웹 화면은 `viewer/index.html`이다. 기존 통합 프로젝트의 `frontend/` 폴더를 이 폴더로 교체하면 기존 `/viewer/#verify` 경로를 유지할 수 있다. 폴더 안의 `viewer/`와 `assets/`를 함께 옮겨야 한다.

- `viewer/`: 화면, 입력 처리, PQC API 어댑터, AI 해설, PDF 작성 코드
- `assets/`: 로고와 공개 샘플 이미지
- `tests/`: 기능 유지 여부를 확인하는 Node.js 회귀 검사
- `index.html`: 루트 주소에서 최신 뷰어로 이동하는 진입 파일
- `favicon.svg`: 브라우저 탭 아이콘

실행 방법은 전달본 최상위 `README.md`, 기능별 수정 위치는 `docs/03_기능별_수정위치.md`를 확인한다. 서버 주소·키·DB 연결 정보는 프론트 코드에 넣지 않는다.
