/**
 * 시험용 PNG 청크 제거 도우미. 현재 라이브 샘플의 복구·서명 검증은 서버가 수행한다.
 */
// Offline PNG fixture helper. Live samples use the non-persistent server endpoint.
// A demo fixture, not a verifier: remove one complete PNG caBX chunk only.
// The resulting bytes still go through the ordinary inspection/recovery API.

/** [시험 도우미] PNG 구조를 읽어 완전한 caBX 청크 하나만 제거한다. 복구나 서명 검증은 수행하지 않는다. */
export function removePngC2pa(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const signature = [137, 80, 78, 71, 13, 10, 26, 10];
  if (bytes.length < 33 || signature.some((value, index) => bytes[index] !== value))
    throw Error("복구 샘플을 준비할 PNG 결과 이미지가 아닙니다.");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength),
    parts = [bytes.subarray(0, 8)];
  let offset = 8,
    removed = 0,
    hasImage = false,
    ended = false;
  while (offset < bytes.length) {
    if (bytes.length - offset < 12) throw Error("PNG 샘플의 청크가 잘려 있습니다.");
    const length = view.getUint32(offset),
      end = offset + length + 12;
    if (end > bytes.length) throw Error("PNG 샘플의 청크 길이가 올바르지 않습니다.");
    const type = String.fromCharCode(...bytes.subarray(offset + 4, offset + 8));
    if (offset === 8 && (type !== "IHDR" || length !== 13))
      throw Error("PNG 샘플의 헤더가 올바르지 않습니다.");
    if (type === "caBX") removed++;
    else parts.push(bytes.subarray(offset, end));
    if (type === "IDAT") hasImage = true;
    offset = end;
    if (type === "IEND") {
      if (length !== 0 || offset !== bytes.length)
        throw Error("PNG 샘플의 끝 영역이 올바르지 않습니다.");
      ended = true;
      break;
    }
  }
  if (!ended || !hasImage || removed !== 1)
    throw Error("검증된 이미지에서 단일 C2PA 영역을 확인하지 못했습니다.");
  const result = new Uint8Array(parts.reduce((total, part) => total + part.length, 0));
  let position = 0;
  for (const part of parts) {
    result.set(part, position);
    position += part.length;
  }
  return result;
}
