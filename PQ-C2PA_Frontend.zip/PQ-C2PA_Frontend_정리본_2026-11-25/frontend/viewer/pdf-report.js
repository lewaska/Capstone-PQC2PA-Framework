/**
 * 경찰서 제출용·상세 분석용 PDF 생성. 현재 선택한 사진의 검사 기록과 PQC 결과를 사용한다.
 * 최대 4쪽 A4에 핵심을 배치하고 전체 데이터는 JSON으로 첨부한다.
 * 서버 검사 시각·브라우저 관측 시각·문서 발급 시각을 서로 바꾸어 쓰지 않는다.
 */
// PQ-C2PA PDF reports.
// Compact reports: selected image evidence, Classic C2PA, detached PQC and timing.
// At most four explicitly budgeted A4 pages; complete records are attached as JSON.
// Historical form research is not part of the exported report.
import { PDFDocument } from "./pdf-lib.esm.min.js";

const W = 1240,
  H = 1754,
  SCALE = 1.5,
  MM = W / 210;
const L = Math.round(20 * MM),
  R = W - Math.round(20 * MM),
  CW = R - L;
const TOP = Math.round(27 * MM),
  BOTTOM = H - Math.round(25 * MM);
const SERIF =
  '"Noto Serif KR","Noto Serif CJK KR","Batang","바탕","AppleMyungjo","Nanum Myeongjo",serif';
const SANS =
  '"Malgun Gothic","맑은 고딕","Apple SD Gothic Neo","Noto Sans KR","Noto Sans CJK KR",sans-serif';
const MONO = '"Consolas","D2Coding","SFMono-Regular","Menlo","Noto Sans Mono CJK KR",monospace';
const C = {
  ink: "#000000",
  text: "#1a1a1a",
  muted: "#4a4a4a",
  faint: "#777777",
  thin: "#a0a0a0",
  fill: "#eeeeee",
};

// ============================================================================
// 01. 보고서 종류와 코드 해석
// ============================================================================
const TYPES = {
  submission: {
    code: "SUB",
    title: "이미지 출처 검증 참고자료",
    kind: "경찰서 제출용",
    page: "gov",
  },
  technical: { code: "TEC", title: "PQ-C2PA 출처·무결성 분석서", kind: "상세분석", page: "kolas" },
};

const STATES = {
  Trusted: {
    label: "신뢰 확인",
    line: "서명과 파일 결합이 유효하고, 선택한 신뢰 기준에서 서명자가 확인됨.",
  },
  Valid: {
    label: "유효(서명자 미확인)",
    line: "서명과 파일 결합은 유효하나, 선택한 신뢰 기준에서 서명자는 확인되지 않음.",
  },
  Invalid: { label: "검증 실패", line: "C2PA 검증에서 실패 항목이 보고됨." },
  NoManifest: {
    label: "C2PA 기록 없음",
    line: "검증 가능한 C2PA 기록이 없음. 기록이 없다는 사실만으로 변조 여부를 판단할 수 없음.",
  },
  RemoteUnavailable: {
    label: "검증 미완료",
    line: "출처 기록이 외부에 있으나 원격 조회를 하지 않아 검증을 완료하지 못함.",
  },
  Error: { label: "분석 오류", line: "파일 분석 중 오류가 발생하여 검증을 완료하지 못함." },
  Unknown: { label: "상태 미확인", line: "검증 상태를 확인할 수 없음." },
};

// C2PA Technical Specification §15 status codes, read in Korean.
const CODE_KO = {
  "claimSignature.validated": "클레임 서명이 유효함",
  "claimSignature.insideValidity": "서명 시점이 인증서 유효기간 안에 있음",
  "claimSignature.outsideValidity": "서명 시점이 인증서 유효기간을 벗어남",
  "claimSignature.missing": "클레임 서명이 없음",
  "claimSignature.mismatch": "클레임 서명이 클레임 내용과 일치하지 않음",
  "signingCredential.trusted": "서명 인증서가 신뢰 기준에 연결됨",
  "signingCredential.untrusted": "서명 인증서가 신뢰 기준에 연결되지 않음",
  "signingCredential.invalid": "서명 인증서의 형식 또는 용도가 유효하지 않음",
  "signingCredential.revoked": "서명 인증서가 폐지됨",
  "signingCredential.expired": "서명 인증서가 만료됨",
  "signingCredential.ocsp.skipped": "인증서 폐지 여부(OCSP)를 조회하지 않음",
  "signingCredential.ocsp.notRevoked": "OCSP 조회 결과 폐지되지 않음",
  "signingCredential.ocsp.revoked": "OCSP 조회 결과 폐지됨",
  "signingCredential.ocsp.inaccessible": "OCSP 응답을 받지 못함",
  "timeStamp.validated": "타임스탬프 서명과 해시가 일치함",
  "timeStamp.trusted": "타임스탬프 기관이 신뢰 기준에 연결됨",
  "timeStamp.untrusted": "타임스탬프 기관이 신뢰 기준에서 확인되지 않음",
  "timeStamp.mismatch": "타임스탬프가 서명과 일치하지 않음",
  "timeStamp.outsideValidity": "타임스탬프가 인증서 유효기간 밖에 있음",
  "timeStamp.malformed": "타임스탬프 형식 오류",
  "assertion.hashedURI.match": "참조 Assertion 해시 일치",
  "assertion.hashedURI.mismatch": "참조 Assertion 해시 불일치",
  "assertion.dataHash.match": "파일 데이터 해시가 서명 당시와 일치함",
  "assertion.dataHash.mismatch": "파일 데이터 해시가 서명 당시와 다름",
  "assertion.bmffHash.match": "BMFF 데이터 해시가 서명 당시와 일치함",
  "assertion.bmffHash.mismatch": "BMFF 데이터 해시가 서명 당시와 다름",
  "assertion.boxesHash.match": "박스 단위 해시가 서명 당시와 일치함",
  "assertion.boxesHash.mismatch": "박스 단위 해시가 서명 당시와 다름",
  "assertion.collectionHash.match": "묶음 해시 일치",
  "assertion.collectionHash.mismatch": "묶음 해시 불일치",
  "assertion.missing": "참조 Assertion이 없음",
  "assertion.accessible": "Assertion 접근 가능",
  "assertion.inaccessible": "Assertion에 접근할 수 없음",
  "assertion.action.ingredientMismatch": "작업 기록과 재료 정보가 맞지 않음",
  "ingredient.claimSignature.validated": "재료 Manifest 서명이 유효함",
  "ingredient.claimSignature.mismatch": "재료 Manifest 서명 불일치",
  "ingredient.manifest.validated": "재료 Manifest 검증 통과",
  "ingredient.manifest.mismatch": "재료 Manifest가 기록과 다름",
  "ingredient.hashedURI.match": "재료 참조 해시 일치",
  "ingredient.hashedURI.mismatch": "재료 참조 해시 불일치",
  "claim.missing": "클레임이 없음",
  "claim.multiple": "클레임이 여러 개임",
  "manifest.inaccessible": "Manifest에 접근할 수 없음",
  "manifest.missing": "Manifest가 없음",
  "manifest.multipleParents": "부모 재료가 둘 이상임",
  "algorithm.unsupported": "지원하지 않는 서명 알고리즘",
  "algorithm.deprecated": "사용 중단 예정 알고리즘",
  "general.error": "검증 중 일반 오류",
};
const ACTION_KO = {
  "c2pa.created": "생성",
  "c2pa.edited": "편집",
  "c2pa.opened": "열기",
  "c2pa.placed": "재료 삽입",
  "c2pa.resized": "크기 변경",
  "c2pa.cropped": "자르기",
  "c2pa.published": "발행",
  "c2pa.transcoded": "인코딩 변경",
  "c2pa.converted": "형식 변환",
  "c2pa.color_adjustments": "색 보정",
  "c2pa.filtered": "필터 적용",
  "c2pa.drawing": "그리기",
  "c2pa.removed": "일부 제거",
  "c2pa.repackaged": "재포장",
  "c2pa.watermarked": "워터마크 삽입",
  "c2pa.watermarked.bound": "워터마크 삽입(결합)",
  "c2pa.watermarked.unbound": "워터마크 삽입(비결합)",
  "c2pa.redacted": "가림 처리",
  "c2pa.orientation": "방향 변경",
  "c2pa.translated": "번역",
  "c2pa.deleted": "삭제",
  "c2pa.produced": "제작",
  "c2pa.unknown": "알 수 없는 작업",
};
const SOURCE_KO = {
  digitalCapture: "디지털 촬영",
  negativeFilm: "네거티브 필름 스캔",
  positiveFilm: "포지티브 필름 스캔",
  print: "인쇄물 스캔",
  minorHumanEdits: "사람의 경미한 편집",
  humanEdits: "사람의 편집",
  compositeCapture: "촬영물 합성",
  algorithmicallyEnhanced: "알고리즘 보정",
  dataDrivenMedia: "데이터 기반 생성",
  digitalArt: "사람이 만든 디지털 아트",
  virtualRecording: "가상 녹화",
  composite: "합성",
  trainedAlgorithmicMedia: "생성형 AI 생성",
  compositeWithTrainedAlgorithmicMedia: "생성형 AI 요소를 포함한 합성",
  compositeSynthetic: "합성 생성물",
  algorithmicMedia: "알고리즘 생성",
  screenCapture: "화면 캡처",
};
const ALGS = {
  es256: { name: "ECDSA P-256 / SHA-256", family: "타원곡선", pq: false },
  es384: { name: "ECDSA P-384 / SHA-384", family: "타원곡선", pq: false },
  es512: { name: "ECDSA P-521 / SHA-512", family: "타원곡선", pq: false },
  ps256: { name: "RSA-PSS / SHA-256", family: "RSA", pq: false },
  ps384: { name: "RSA-PSS / SHA-384", family: "RSA", pq: false },
  ps512: { name: "RSA-PSS / SHA-512", family: "RSA", pq: false },
  ed25519: { name: "EdDSA Ed25519", family: "타원곡선", pq: false },
  "ml-dsa-44": { name: "ML-DSA-44 (FIPS 204)", family: "격자 기반", pq: true },
  "ml-dsa-65": { name: "ML-DSA-65 (FIPS 204)", family: "격자 기반", pq: true },
  "ml-dsa-87": { name: "ML-DSA-87 (FIPS 204)", family: "격자 기반", pq: true },
};
// ---------- data helpers ----------

// ============================================================================
// 02. 표시값·시각·파일 정보 정리
// ============================================================================

// safe: 제어문자를 정리하고 출력 길이를 제한한다.
const safe = (value, max = 600) =>
  String(value ?? "")
    .replace(/[\r\t]+/g, " ")
    .replace(/\u0000/g, "")
    .slice(0, max);

// filled: 값이 비었을 때만 미제공 안내로 대체한다.
const filled = (value, fallback = "정보 없음") => {
  const text = typeof value === "object" && value !== null ? JSON.stringify(value) : safe(value);
  return text.trim() ? text : fallback;
};

// pad: 날짜·시각 숫자를 두 자리로 맞춘다.
const pad = (n) => String(n).padStart(2, "0");

// toDate: 유효한 날짜는 Date로, 없거나 잘못된 값은 null로 구분한다.
const toDate = (value) => {
  const d = value instanceof Date ? value : new Date(value);
  return !value || Number.isNaN(d.getTime()) ? null : d;
};

/** [보고서 시각] 실제 받은 시각을 타임존과 함께 보고서 표기 형식으로 바꾼다. */
function stamp(value) {
  const d = toDate(value);
  if (!d) return "정보 없음";
  const offset = -d.getTimezoneOffset(),
    sign = offset >= 0 ? "+" : "-",
    abs = Math.abs(offset);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${String(d.getMilliseconds()).padStart(3, "0")} (UTC${sign}${pad(Math.floor(abs / 60))}:${pad(abs % 60)})`;
}

// dotDate: 보고서용 날짜를 점으로 구분해 표시한다.
const dotDate = (value) => {
  const d = toDate(value);
  return d ? `${d.getFullYear()}. ${d.getMonth() + 1}. ${d.getDate()}.` : "";
};

// longDate: 보고서용 날짜를 년·월·일로 표시한다.
const longDate = (value) => {
  const d = toDate(value);
  return d ? `${d.getFullYear()}년 ${d.getMonth() + 1}월 ${d.getDate()}일` : "";
};

// bytes: 파일 크기를 바이트와 읽기 쉬운 단위로 함께 표시한다.
const bytes = (n) =>
  Number.isFinite(n)
    ? `${n.toLocaleString("ko-KR")} B${n >= 1024 ? ` (${n >= 1048576 ? (n / 1048576).toFixed(2) + " MB" : (n / 1024).toFixed(1) + " KB"})` : ""}`
    : "정보 없음";

// agent: 기록된 제작 도구의 이름과 버전을 문자열로 정리한다.
const agent = (value) =>
  !value
    ? ""
    : typeof value === "object"
      ? [value.name, value.version].filter(Boolean).join(" ") || JSON.stringify(value)
      : String(value);

// sourceKey: 출처 유형 URI의 마지막 유형 이름을 읽는다.
const sourceKey = (uri) =>
  String(uri || "")
    .split("/")
    .pop();

// sourceType: 출처 유형을 한글 해석과 원래 코드로 표시한다.
const sourceType = (uri) => {
  const key = sourceKey(uri);
  return key ? `${SOURCE_KO[key] || key}(${key})` : "";
};

// algInfo: 알고리즘 식별자로 설명 사전의 정보를 찾는다.
const algInfo = (alg) => ALGS[String(alg || "").toLowerCase()] || null;

// algLabel: 실제 알고리즘 이름에 알려진 설명을 덧붙인다.
const algLabel = (alg) =>
  alg
    ? `${String(alg).toUpperCase()}${algInfo(alg) ? ` (${algInfo(alg).name})` : ""}`
    : "확인되지 않음";

// stateOf: 검사 상태에 해당하는 보고서 문구를 고른다.
const stateOf = (item) => STATES[item.state] || STATES.Unknown;

// activeManifest: 현재 사진의 활성 C2PA 기록을 읽는다.
const activeManifest = (item) => {
  const store = item.store || {};
  return (store.manifests || {})[store.active_manifest] || {};
};

// manifestCount: 현재 사진에서 읽은 Manifest 개수를 계산한다.
const manifestCount = (item) =>
  Number(item.manifest_count || Object.keys(item.store?.manifests || {}).length || 0);

// softwareName: 기록된 제작 도구 정보를 모아 표시한다.
const softwareName = (item) =>
  (item.software || activeManifest(item).claim_generator_info || [])
    .map(agent)
    .filter(Boolean)
    .join(", ") ||
  activeManifest(item).claim_generator ||
  "";

// checksOf: 보고서가 처리하는 SDK 판정 유형의 원본 검사만 선택한다.
const checksOf = (item) =>
  (item.checks || []).filter((c) => ["success", "informational", "failure"].includes(c.kind));
const SCOPE_KO = {
  activeManifest: "활성 Manifest",
  ingredientDeltas: "재료 Manifest",
  validationDeltas: "재료 Manifest",
  legacy: "기존 형식",
};

// kindKo: SDK 판정 유형을 한글로 표시한다.
const kindKo = (kind) =>
  ({ success: "통과", informational: "참고", failure: "실패" })[kind] || kind;

// trustKo: 현재 사진에 적용한 신뢰 기준을 설명한다.
const trustKo = (item) =>
  item.trust_profile === "lab"
    ? "자체 CA를 Trust Anchor로 등록한 신뢰 기준"
    : "공식 C2PA SDK 기본 신뢰 설정";

// modeKo: 서버 검사와 선택적인 브라우저 검사를 구분한다.
const modeKo = (item) =>
  item.processing_mode === "browser"
    ? "브라우저 내부 검증(공식 C2PA 웹 SDK, 파일 서버 미전송)"
    : "사이트 서버 검증(공식 C2PA SDK)";

// engineKo: 검사 방식에 맞는 실제 SDK 정보를 표시한다.
const engineKo = (item, env) =>
  item.processing_mode === "browser"
    ? "@contentauth/c2pa-web (WASM)"
    : env?.sdk
      ? `${env.sdk} ${env.sdk_version || ""}`.trim()
      : "c2pa-python";

// specVersion: 검사 기록에 포함된 규격 버전을 읽는다.
const specVersion = (item) => item.store?.validation_results?.specVersion || "";

// dimsOf: 확인 가능한 이미지 가로·세로 크기를 읽는다.
const dimsOf = (item) =>
  item.dimensions ||
  (item.image_info?.width && item.image_info?.height
    ? [item.image_info.width, item.image_info.height]
    : null);

// fileLine: 파일 형식·용량·해상도를 한 줄로 정리한다.
const fileLine = (item) =>
  [
    filled(item.mime),
    bytes(item.size),
    dimsOf(item) ? `${dimsOf(item)[0]} × ${dimsOf(item)[1]} px` : "",
  ]
    .filter(Boolean)
    .join(", ");

// uniq: 같은 표시값의 반복을 제거한다.
const uniq = (list) => [...new Set(list)];

/** [사진별 시각] 현재 사진의 서버 검사 시작·종료와 브라우저 관측 시각을 구분해 읽는다. */
function inspectionPeriod(item) {
  const timing = item.verification_timing;
  if (timing?.started_at && timing?.completed_at)
    return `${stamp(timing.started_at)} 시작\n${stamp(timing.completed_at)} 종료 (서버 C2PA 검사)`;
  return `${stamp(item.created_at)} (기록된 검사 시각 · 시작/종료 상세 없음)`;
}

// codeList: 검사 코드 목록의 중복을 정리해 연결한다.
const codeList = (list) => uniq(list.map((c) => c.code)).join(", ");

// spaced: 짧은 한글 이름의 보고서 표기 간격을 맞춘다.
const spaced = (name) =>
  /^[가-힣]{2,4}$/.test(name || "") ? name.split("").join(" ") : name || "";
const LETTERS = "가나다라마바사아자차카타파하";

// ga: 항목 순서를 가·나·다 형식으로 표시한다.
const ga = (i) => `${LETTERS[i] || i + 1}.`;
// Backend messages are written politely; the report uses 개조식 endings.

// terse: 검사 메시지의 종결 표현을 보고서 개조식 문장으로 정리한다.
const terse = (text) =>
  safe(text, 400)
    .replace(/했습니다/g, "함")
    .replace(/되었습니다/g, "됨")
    .replace(/못했습니다/g, "못함")
    .replace(/없습니다/g, "없음")
    .replace(/다릅니다/g, "다름")
    .replace(/입니다/g, "임")
    .replace(/합니다/g, "함")
    .replace(/습니다/g, "음");

// ============================================================================
// 03. 증거 스냅샷과 검사 결론
// ============================================================================

/** [발급 해시] 객체 키 순서를 고정해 같은 내용은 같은 해시 입력 문자열이 되게 한다. */
function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object")
    return `{${Object.keys(value)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${stableStringify(value[k])}`)
      .join(",")}}`;
  return JSON.stringify(value ?? null);
}

/** [발급 해시] 텍스트의 SHA-256을 계산한다. 개인정보 원문 대신 발급 기록에 사용할 수 있다. */
async function sha256Hex(text) {
  try {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    return "";
  }
}
// The record the report is drawn from; thumbnails are excluded to keep it small.

/** [증거 보관] 보고서의 근거가 되는 검사 기록을 복사하며 큰 미리보기 데이터는 제외한다. */
function recordSnapshot(item) {
  const { thumbnail, manifest_thumbnails, ...rest } = item;
  return rest;
}

/** [AI 기록] C2PA에 명시적으로 남은 AI 생성·합성 선언의 존재를 확인한다. */
function hasAiRecord(item) {
  return item.ai_origin
    ? ["created", "inherited", "edited", "media"].includes(item.ai_origin.kind)
    : item.ai === "declared";
}

/** [AI 기록] 선언 존재·미확인을 보고서의 짧은 상태 문구로 바꾼다. */
function aiReportLabel(item) {
  return (
    item.ai_origin?.label ||
    (item.ai === "declared" ? "AI 사용 선언 있음" : "확인 가능한 선언 없음")
  );
}

/** [AI 기록] 확인된 생성 선언만 설명하며 선언 부재를 AI 미사용으로 단정하지 않는다. */
function aiReportDescription(item) {
  if (!hasAiRecord(item)) return "확인 가능한 선언 없음";
  const tool = item.ai_origin?.tool ? ` · 기록된 도구: ${item.ai_origin.tool}` : "";
  return `${aiReportLabel(item)}${tool} (출처 기록의 선언이며 AI 탐지 결과 아님)`;
}

/** [PQC 보고서] 분리 P1 작업과 기존 증거 형식을 구분해 실제 서명·결합 검증 상태를 모은다. */
function pqEvidence(item) {
  if (item.conversion_v4) {
    const result = item.conversion_v4.result || {},
      p = result.p1_validation || {};
    const checks = [
      "assertion_hashes",
      "ingredient_references",
      "source_evidence",
      "claim_signature",
      "hard_binding",
      "soft_binding",
    ];
    const valid =
      item.conversion_v4.status === "COMPLETED" &&
      result.trust_status === "TRUSTED" &&
      p.profile === "pq-c2pa-jumbf-haetae3-1" &&
      p.container === "JUMBF" &&
      checks.every((key) => p[key] === "VALID") &&
      p.classic_validation === "SDK_VALIDATED" &&
      p.signer === "FRAMEWORK_PINNED_SIGNER" &&
      p.conformance === "EXPERIMENTAL_PQ_PROFILE" &&
      typeof p.manifest_id === "string" &&
      !!p.manifest_id &&
      (result.storage_mode === "EPHEMERAL"
        ? ["present", "removed", "absent"].includes(item.conversion_v4.sample_id) &&
          /^sample_[0-9a-f]{32}$/.test(result.sample_session_id || "")
        : /^pair_[0-9a-f]{32}$/.test(result.manifest_pair_id || "")) &&
      typeof result.fingerprint_base64 === "string" &&
      !!result.fingerprint_base64;
    return {
      present: true,
      detached: true,
      sample: result.storage_mode === "EPHEMERAL",
      status: valid
        ? "VALID"
        : checks.some((key) => p[key] === "INVALID")
          ? "INVALID"
          : "UNVERIFIED",
      schema: p.profile,
      signature_algorithm: p.signature_algorithm,
      reason: "V4 변환 응답의 분리 저장 P1 검증 결과",
    };
  }
  if (item.pqc_process)
    return {
      present: false,
      status: "UNVERIFIED",
      reason: item.pqc_process.message || "PQC 처리를 완료하지 못함",
    };
  if (
    item.pq_evidence &&
    item.pq_evidence.status &&
    !(
      item.pq_evidence.status === "NOT_PRESENT" &&
      ["Error", "RemoteUnavailable", "Unknown"].includes(item.state)
    )
  )
    return item.pq_evidence;
  for (const assertion of activeManifest(item).assertions || []) {
    if (String(assertion.label || "").startsWith("org.pq-c2pa.p1")) {
      const data = assertion.data || {},
        payload = data.payload || {};
      return {
        present: true,
        status: "UNVERIFIED",
        schema: data.schema,
        signature_algorithm: data.signature_algorithm,
        payload_sha3_256: data.payload_sha3_256,
        m0_active_manifest: payload.m0_active_manifest,
        m0_validation_state: payload.m0_validation_state,
        source_file_sha3_256: payload.source_file_sha3_256,
        created_at: payload.created_at,
        public_key_pem: data.public_key_pem,
        reason:
          item.processing_mode === "browser"
            ? "브라우저 검증에서는 P1 ML-DSA-65 서명을 검사하지 않음. 서버 검증으로 다시 확인 필요."
            : "P1 서명 검사 결과가 기록에 없음.",
      };
    }
  }
  return ["Error", "RemoteUnavailable", "Unknown"].includes(item.state) ||
    item.processing_mode === "browser"
    ? { present: false, status: "UNVERIFIED", reason: "증거 유무를 확인하지 못함" }
    : { present: false, status: "NOT_PRESENT" };
}
const PQ_STATUS = {
  VALID: "유효",
  INVALID: "검증 실패",
  UNVERIFIED: "검사하지 못함",
  NOT_PRESENT: "DB 미조회",
};

// Status codes grouped by what they say about the active manifest.

/** [검사 근거] 활성 Manifest에 대한 서명·파일 결합·신뢰·시간 관련 검사 사실을 분류한다. */
function facts(item) {
  const all = checksOf(item);

  // isActive: 현재 사진의 활성 기록에 속한 검사인지 구분한다.
  const isActive = (c) => !c.scope || c.scope === "activeManifest" || c.scope === "legacy";
  const active = all.filter(isActive);

  // by: 활성 기록 중 지정한 코드 패턴에 맞는 검사만 모은다.
  const by = (re) => active.filter((c) => re.test(String(c.code || "")));
  return {
    sigOk: by(/^claimSignature\.validated$/).length > 0,
    sigBad: by(/^claimSignature\.(mismatch|missing)$/),
    inside: by(/^claimSignature\.insideValidity$/).length > 0,
    outside: by(/^claimSignature\.outsideValidity$/),
    hashMatch: by(/^assertion\.hashedURI\.match$/).length,
    hashBad: by(/^assertion\.(hashedURI\.mismatch|missing|inaccessible)$/),
    bindOk: by(/^assertion\.(dataHash|bmffHash|boxesHash|collectionHash)\.match$/),
    bindBad: by(/^assertion\.(dataHash|bmffHash|boxesHash|collectionHash)\.mismatch$/),
    trusted: by(/^signingCredential\.trusted$/).length > 0,
    untrusted: by(/^signingCredential\.untrusted$/).length > 0,
    credBad: by(/^signingCredential\.(invalid|revoked|expired)$/),
    ocsp: by(/^signingCredential\.ocsp\./),
    ts: by(/^timeStamp\./),
    ingredient: all.filter((c) => !isActive(c) || /^ingredient\./.test(String(c.code || ""))),
    failures: active.filter((c) => c.kind === "failure"),
    counts: {
      success: all.filter((c) => c.kind === "success").length,
      informational: all.filter((c) => c.kind === "informational").length,
      failure: all.filter((c) => c.kind === "failure").length,
    },
  };
}

// Opinion on two competing propositions (SWGDE 18-I-001; no numerical probability).

/** [검사 결론] 실제 검사 사실에서 기록·파일 결합에 관한 결론을 만든다. 사진 내용의 사실 여부는 판정하지 않는다. */
function opinion(item, f = facts(item)) {
  const failures = [...f.bindBad, ...f.sigBad, ...f.hashBad];
  if (failures.length)
    return {
      level: "검사 항목 확인 필요",
      statement: "검사에서 실패 또는 접근할 수 없는 항목이 보고됨. 원본 상태 코드를 확인해야 함.",
      basis: [codeList(failures)],
    };
  if (f.sigOk && f.bindOk.length)
    return {
      level: "서명·파일 결합 검사 통과",
      statement: "보고된 서명 및 파일 결합 검사가 통과함. 서명자 신뢰는 별도 항목임.",
      basis: ["서명 및 파일 결합 검사 결과"],
    };
  return {
    level: "판단 불가",
    statement: "검사 결과가 충분하지 않아 서명과 파일 결합을 판단할 수 없음.",
    basis: [stateOf(item).line],
  };
}

/** [검사 결론] 서명 이후 변경에 관한 결론 문장을 가져온다. */
function changeConclusion(item, f, op) {
  return op.statement;
}

/** [서명자 신뢰] 선택한 신뢰 기준에서 확인한 범위를 보고서 문장으로 정리한다. */
function trustConclusion(item, f) {
  const who = filled(item.signature?.common_name, "서명자");
  if (item.state === "NoManifest") return "C2PA 기록이 없어 해당 없음.";
  if (f.credBad.length)
    return `서명 인증서에 문제가 보고되어 서명자를 신뢰할 수 없음(${codeList(f.credBad)}).`;
  if (f.trusted)
    return `서명자 '${who}'은(는) 선택한 신뢰 기준에서 확인됨${item.trust_profile === "lab" ? "(자체 CA Trust Anchor 기준)" : ""}.`;
  if (f.untrusted)
    return `서명자 '${who}'은(는) 선택한 신뢰 기준에서 확인되지 않음. 서명 자체의 유효성과 별개로 서명자를 신뢰할 근거는 확인되지 않음.`;
  return "서명자 신뢰 여부를 판단할 수 없음.";
}

/** [PQC 결론] P1 서명 검증 결과와 처리 범위를 보고서 문장으로 정리한다. */
function pqConclusion(pq) {
  if (pq.sample)
    return `샘플 임시 P1 검증 상태는 ‘${PQ_STATUS[pq.status] || pq.status}’임. 실제 서명·파일 결합 검사를 수행하였으며 영구 DB에는 저장하지 않음.`;
  if (pq.detached)
    return `V4 서버가 반환한 DB 분리 저장 P1의 검사 상태는 ‘${PQ_STATUS[pq.status] || pq.status}’임. 이미지 내 P1의 검사 결과가 아니며 서버에 고정된 HAETAE 공개키 기준의 실험 프로파일임.`;
  if (pq.status === "VALID")
    return `이미지 내 기존 형식 P1의 ML-DSA-65 서명은 유효함${pq.m0_active_manifest ? `. 기록된 원본 Manifest는 ${pq.m0_active_manifest}임` : ""}. 외부 DB의 P1은 조회하지 않음.`;
  if (pq.status === "INVALID")
    return `P1 증거의 서명 검사에 실패함. ${terse(pq.reason || "")}`.trim();
  if (pq.status === "UNVERIFIED")
    return `P1 증거의 서명을 검사하지 못함. ${terse(pq.reason || "")}`.trim();
  return "이미지 내 P1은 확인되지 않음. 외부 DB의 P1은 조회하지 않아 존재 여부와 서명 상태를 판단할 수 없음.";
}

/** [보고서 주의점] 현재 사진의 검사 결과를 해석할 때 필요한 추가 설명을 모은다. */
function notes(item, f) {
  const out = [];
  if (item.trust_profile === "lab")
    out.push("자체 CA를 포함한 신뢰 기준을 선택함. 실제 신뢰 판정은 검사 결과를 참조함.");
  if (
    manifestCount(item) &&
    (f.ocsp.some((c) => c.code === "signingCredential.ocsp.skipped") ||
      item.network_policy?.ocsp === false)
  )
    out.push("인증서 폐지 여부(OCSP)를 조회하지 않았으며, 이를 ‘폐지되지 않음’으로 해석하지 않음.");
  if (hasAiRecord(item))
    out.push(
      "현재 또는 연결된 이전 출처 기록의 AI 사용 선언은 기록자의 진술이며, 독립적인 딥페이크·AI 탐지 결과가 아님.",
    );
  if (item.state === "NoManifest")
    out.push(
      "유통 과정에서 메타데이터가 제거되는 경우가 많으므로, C2PA 기록이 없다는 사실은 조작의 근거가 되지 않음.",
    );
  if (item.error) out.push(`분석 오류 메시지: ${safe(item.error, 300)}`);
  out.push(
    "본 검증은 C2PA 출처 기록의 서명·결합 상태를 확인한 것으로, 검증물에 담긴 내용의 사실 여부, 제작자의 실제 신원, 권리관계를 판단하지 않음.",
  );
  out.push(`신뢰 판정은 검증 시점(${stamp(item.created_at)})의 신뢰 기준과 인증서 상태에 따름.`);
  return out;
}

/** [보고서 한계] 출처 검증으로 판단할 수 없는 사진 내용·권리·AI 여부의 범위를 명시한다. */
function limitations() {
  return [
    "C2PA 검증은 기록이 파일에 결합되어 있고 서명 이후 바뀌지 않았는지를 확인함. 기록된 내용(촬영 장소, 제작자, AI 사용 여부 등)의 사실 여부는 보증하지 않음.",
    "신뢰 판정은 사용한 신뢰 기준과 검증 시각에 따라 달라질 수 있음. 인증서 만료·폐지 또는 신뢰 목록 갱신 이후에는 같은 파일도 결과가 달라질 수 있음.",
    "C2PA 기록이 없는 파일은 이 방법으로 평가할 수 없으며, 기록 부재는 변조의 근거가 아님.",
    "AI 생성 선언이 없다는 사실이 AI를 사용하지 않았다는 뜻은 아님.",
    "ECDSA·RSA 서명은 충분한 성능의 양자컴퓨터가 등장하면 취약해질 수 있음. 전환 일정은 적용 환경과 기준에 따라 확인해야 함.",
    "본 문서는 연구용 도구가 자동 생성한 것으로, 수사기관 공식 서식, 공인 감정서 또는 KOLAS 인정 시험성적서가 아님.",
  ];
}

// ---------- who vouches for what: system-checked, server-issued, or typed in ----------
// KS Q ISO/IEC 17025 7.8.2.2: information supplied by the customer is identified as such.
const DECLARED_NOTE =
  "‘*’ 표시 항목은 신청인이 기재한 사항으로, 발급 시스템이 사실 여부를 확인하지 않음(KS Q ISO/IEC 17025 7.8.2.2). 이 정보는 검증 결과에 영향을 주지 않음.";
// Only what the applicant (the person submitting the image) can state. Case number, receipt
// date and the receiving officer are left blank on the submission form for the police to fill in.
const DECLARED_KEYS = { applicant: "applicant", submitTo: "submit_to", purpose: "purpose" };

// typed: 사용자 기입값의 길이와 앞뒤 공백을 정리한다.
const typed = (value) => safe(value, 400).trim();

// declared: 사용자가 기입한 값에 별표를 붙여 시스템 확인값과 구분한다.
const declared = (value, fallback = "기재하지 않음") =>
  typed(value) ? `${typed(value)} *` : fallback;

// ============================================================================
// 04. 신청인 기입과 문서 발급 상태
// ============================================================================

/** [신청인 입력] 보고서 옵션에서 사용자가 직접 기입한 신청인 정보만 읽는다. */
function identityOf(options) {
  const identity = options.issuance?.offline ? {} : options.issuance?.record?.identity || {};
  return {
    phone: identity.applicant_phone?.status === "VERIFIED" ? identity.applicant_phone : null,
  };
}

/** [신청인 입력] 신청인 이름과 제출처를 구분해 보고서 표시 문구를 만든다. */
function requesterText(options) {
  const phone = identityOf(options).phone;
  const name = `${declared(options.applicant)}${phone ? `, 휴대폰 인증 ${phone.phone_masked}` : ""}`;
  const contact = typed(options.contactPhone) ? `\n연락처 ${declared(options.contactPhone)}` : "";
  return `${name}${contact}`;
}

// caseText: 수사기관이 기입할 사건번호를 임의로 만들지 않고 비워 둔다.
const caseText = () => "";

// orgName: 접수·의뢰 기관 정보를 임의로 만들지 않고 비워 둔다.
const orgName = () => "";
const POLICE_BLANK = "(접수 기관 기재)";

// signedName: 사용자가 입력한 이름만 기입 표시와 함께 반환한다.
const signedName = (value) => (typed(value) ? `${typed(value)} *` : "");
// Server times keep the offset they were issued with.

/** [발급 시각] 서버가 발급한 ISO 시각의 날짜·시간·오프셋을 원래 값대로 분리한다. */
function isoParts(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|[+-]\d{2}:\d{2})$/.exec(
    String(iso || ""),
  );
  if (!m) return null;
  const [, Y, M, D, h, mi, sec, off] = m,
    zone = off === "Z" ? "+00:00" : off;
  return {
    text: `${Y}-${M}-${D} ${h}:${mi}:${sec} (UTC${zone})`,
    short: `${Y}-${M}-${D} ${h}:${mi}`,
    dot: `${Y}. ${+M}. ${+D}.`,
    long: `${Y}년 ${+M}월 ${+D}일`,
  };
}

/** [입력 범위] 사용자가 기입한 정보와 시스템이 검증한 정보를 구분하는 설명을 만든다. */
function identityRemarks(options) {
  const { phone } = identityOf(options),
    signed = options.issuance?.signature?.status === "SIGNED";
  if (phone)
    return [
      `신청인의 휴대폰 번호(${phone.phone_masked})는 ${isoParts(phone.verified_at)?.short || phone.verified_at}에 문자 인증번호로 확인되었으며, 번호 수신 확인 기록이 서버 발급 기록${signed ? "(ML-DSA-65 서명)" : ""}에 남음. 신청인 이름은 기재 사항임.`,
    ];
  return ["신청인의 신원과 자필 서명은 시스템이 확인하지 않음."];
}

/** [발급 서명] 발급 서버가 제공한 문서 서명 알고리즘 이름을 읽는다. */
function issuanceAlgorithm(issuance) {
  return issuance?.signature?.algorithm === "HAETAE-3"
    ? "HAETAE-3"
    : issuance?.signature?.algorithm === "ML-DSA-65"
      ? "ML-DSA-65"
      : "서버 전자서명";
}

/** [발급 상태] 서버 등록 성공·미등록을 구분하고 실제 발급 시각의 출처를 설명한다. */
function issuanceRemark(meta) {
  if (!meta.issuance)
    return `이 문서는 발급 서버에 등록되지 않았음${meta.offlineReason ? `(${meta.offlineReason})` : ""}. 문서번호와 발급 시각은 작성자 PC에서 생성됨.`;
  const signed = meta.issuance.signature?.status === "SIGNED";
  return `이 문서는 발급 서버에 등록되었으며(확인번호 ${meta.issuance.verification_code}), 발급 기록은 ${signed ? `${issuanceAlgorithm(meta.issuance)}로 서명됨` : "서명되지 않았음"}. 완성된 PDF의 등록 성공 여부는 별도로 확인해야 함.`;
}

/** [발급 표시] 문서번호·발급 상태·시각을 보고서 표의 행으로 만든다. */
function issuanceRows(meta, options) {
  const s = meta.issuance,
    { phone } = identityOf(options);
  return [
    ["문서번호", `${s.doc_no}    확인번호  ${s.verification_code}`],
    ["발급 시각", `${meta.issuedText}, 발급 서버 시각`],
    [
      "발급 기록 서명",
      s.signature?.status === "SIGNED"
        ? `${issuanceAlgorithm(s)}, 서버 공개키 SHA-256 ${String(s.signature.public_key_sha256).slice(0, 16)}…`
        : "서명하지 않음",
    ],
  ];
}

/** [발급 표시] 보고서의 발급 확인 영역을 현재 페이지에 그린다. */
function drawIssuance(r, meta, options, { compact = false } = {}) {
  if (meta.issuance) r.issueBox(null, "발급 확인", issuanceRows(meta, options), { compact });
  else
    r.issueBox(null, "발급 확인 · 미등록", [
      [
        "상태",
        meta.offlineReason === "작성자가 등록하지 않음"
          ? "발급 서버 등록을 선택하지 않음"
          : `발급 서버에 등록하지 못함${meta.offlineReason ? `(${meta.offlineReason})` : ""}`,
      ],
      ["발급 시각", meta.issuedText],
      ["비고", "서버에 연결된 상태에서 다시 발급하면 문서번호·발급 시각을 서버가 부여함"],
    ]);
}

// Bounded A4 layouts. No automatic page creation or silent page slicing: every
// section has a row/line budget; complete evidence remains in the attached JSON.

// ============================================================================
// 05. A4 캔버스와 표·문단 배치
// ============================================================================

/** [PDF 배치] A4 캔버스와 표·문단 그리기 도구를 만든다. 최대 4쪽과 페이지별 공간 제한을 지킨다. */
function createRenderer(meta) {
  const pages = [],
    top = 126,
    bottom = 1606;
  let ctx,
    y = top;

  // font: 크기·굵기·고정폭 여부에 맞는 캔버스 폰트 문자열을 만든다.
  const font = (size = 18, bold = false, mono = false) =>
    `${bold ? 700 : 400} ${size}px ${mono ? MONO : SANS}`;

  /** [PDF 배치] 흰 A4 캔버스를 새로 만들고 그리기 위치를 초기화한다. 다섯 번째 페이지는 허용하지 않는다. */
  function newPage() {
    if (pages.length === 4) throw Error("보고서의 4쪽 제한을 넘었습니다.");
    const canvas = document.createElement("canvas");
    canvas.width = W * SCALE;
    canvas.height = H * SCALE;
    ctx = canvas.getContext("2d");
    ctx.scale(SCALE, SCALE);
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, W, H);
    pages.push(canvas);
    y = top;
  }

  /** [PDF 줄바꿈] 실제 폰트 폭으로 문장을 나누고 정해진 줄 수를 넘으면 말줄임 표시를 붙인다. */
  function lines(text, width, size = 18, bold = false, mono = false, max = 2) {
    ctx.font = font(size, bold, mono);
    const all = [];
    for (const part of String(text ?? "정보 없음")
      .replace(/\u0000/g, "")
      .split("\n")) {
      let line = "";
      for (const char of part) {
        if (line && ctx.measureText(line + char).width > width) {
          all.push(line);
          line = char;
        } else line += char;
      }
      all.push(line);
    }
    const shown = all.slice(0, max);
    if (all.length > max) {
      let last = shown[max - 1];
      while (last && ctx.measureText(last + "…").width > width) last = last.slice(0, -1);
      shown[max - 1] = last + "…";
    }
    return shown;
  }

  /** [PDF 공간] 추가할 내용이 페이지 하단을 넘는지 먼저 확인해 잘린 보고서 생성을 막는다. */
  function reserve(height) {
    if (y + height > bottom)
      throw Error(
        `보고서 ${pages.length}쪽의 배치 공간을 초과했습니다 (${Math.round(y + height)}).`,
      );
  }

  /** [PDF 그리기] 글꼴·크기·굵기·색상을 적용해 지정 좌표에 문자열을 그린다. */
  function text(value, x, baseline, size = 18, bold = false, mono = false, color = C.text) {
    ctx.font = font(size, bold, mono);
    ctx.fillStyle = color;
    ctx.textAlign = "left";
    ctx.fillText(String(value), x, baseline);
  }

  /** [PDF 그리기] 표와 문단을 나누는 가로선을 그린다. */
  function rule(yy, width = CW, color = "#c8cdd4") {
    ctx.fillStyle = color;
    ctx.fillRect(L, yy, width, 1);
  }

  /** [PDF 배치] 페이지 제목과 부제·구분선을 그리고 다음 내용의 시작 위치를 옮긴다. */
  function title(main, sub = "") {
    reserve(94);
    text(main, L, y + 35, 32, true);
    if (sub) text(sub, L, y + 64, 17, false, false, C.muted);
    rule(y + 80, CW, C.ink);
    y += 96;
  }

  /** [PDF 배치] 절 제목을 그리고 필요한 세로 공간을 확보한다. */
  function section(label) {
    reserve(48);
    y += 14;
    text(label, L, y + 23, 21, true);
    y += 43;
  }

  /** [PDF 배치] 문단을 줄바꿈하고 지정 줄 수 안에서 배치한다. */
  function para(value, { maxLines = 3, size = 17 } = {}) {
    const list = lines(value, CW, size, false, false, maxLines),
      height = list.length * (size + 8) + 14;
    reserve(height);
    list.forEach((line, i) =>
      text(line, L, y + size + i * (size + 8), size, false, false, C.muted),
    );
    y += height;
  }

  /** [PDF 표] 열 너비와 셀의 줄 수에 맞춰 표를 그린다. 현재 페이지에 담기지 않으면 오류를 낸다. */
  function table(columns, rows, { size = 18, maxLines = 2, header = true } = {}) {
    const widths = columns.map((c) => CW * c.w),
      step = size + 7;

    // drawRow: 각 열의 줄 수를 계산해 표의 한 행을 그린다.
    const drawRow = (cells, isHead = false) => {
      const content = cells.map((cell, i) =>
        lines(cell, widths[i] - 24, size, isHead, !!columns[i].mono, maxLines),
      );
      const height = Math.max(36, Math.max(...content.map((c) => c.length)) * step + 15);
      reserve(height);
      if (isHead) {
        ctx.fillStyle = "#eef0f3";
        ctx.fillRect(L, y, CW, height);
      }
      let x = L;
      content.forEach((list, i) => {
        list.forEach((line, n) =>
          text(line, x + 12, y + size + 7 + n * step, size, isHead, !!columns[i].mono),
        );
        x += widths[i];
      });
      rule(y + height);
      y += height;
    };
    if (header)
      drawRow(
        columns.map((c) => c.title),
        true,
      );
    rows.forEach((row) => drawRow(row));
    y += 7;
  }

  /** [PDF 표] 표의 예상 높이를 계산해 현재 페이지에 추가 가능한지 확인한다. */
  function canFitTable(columns, rows, { size = 18, maxLines = 2 } = {}, extra = 0) {
    const height = [columns.map((c) => c.title), ...rows].reduce(
      (sum, cells) =>
        sum +
        Math.max(
          36,
          Math.max(
            ...cells.map(
              (cell, i) =>
                lines(cell, CW * columns[i].w - 24, size, false, !!columns[i].mono, maxLines)
                  .length,
            ),
          ) *
            (size + 7) +
            15,
        ),
      7,
    );
    return y + height + extra <= bottom;
  }

  /** [PDF 표] 항목·내용 두 열의 요약 표를 그린다. */
  function kv(rows, options = {}) {
    table(
      [
        { title: "항목", w: 0.23 },
        { title: "내용", w: 0.77 },
      ],
      rows,
      { header: false, ...options },
    );
  }

  /** [PDF 요약] 현재 사진의 C2PA 판정과 비율을 유지한 미리보기를 그린다. */
  function hero(item, preview) {
    const state = stateOf(item),
      height = 148;
    reserve(height);
    ctx.fillStyle = "#f2f4f7";
    ctx.fillRect(L, y, CW, height);
    const imageW = preview ? 220 : 0,
      area = CW - imageW - 44;
    text("Classic C2PA · " + state.label, L + 18, y + 31, 23, true);
    lines(state.line, area, 18, false, false, 2).forEach((line, i) =>
      text(line, L + 18, y + 61 + i * 26, 18),
    );
    if (preview) {
      const scale = Math.min(198 / preview.naturalWidth, 120 / preview.naturalHeight);
      const w = preview.naturalWidth * scale,
        h = preview.naturalHeight * scale;
      ctx.drawImage(preview, R - 18 - 198 + (198 - w) / 2, y + (height - h) / 2, w, h);
    }
    y += height + 8;
  }

  /** [PDF 마감] 각 페이지에 문서번호·보고서 종류·페이지 번호를 더해 완성된 캔버스 목록을 반환한다. */
  function finish() {
    pages.forEach((canvas, index) => {
      const c = canvas.getContext("2d");
      c.save();
      c.setTransform(SCALE, 0, 0, SCALE, 0, 0);
      c.fillStyle = C.muted;
      c.font = font(14);
      c.textAlign = "left";
      c.fillText(`문서번호 ${meta.docNo}`, L, 75);
      c.textAlign = "right";
      c.fillText(meta.kind, R, 75);
      c.fillStyle = "#aeb5c0";
      c.fillRect(L, 1640, CW, 1);
      c.textAlign = "left";
      c.fillStyle = C.muted;
      c.font = font(13);
      c.fillText("PQ-C2PA Viewer · 자동 생성 검사 자료", L, 1671);
      c.textAlign = "right";
      c.fillText(`${index + 1} / ${pages.length}`, R, 1671);
      c.restore();
    });
    return pages;
  }
  newPage();
  return { title, section, para, table, kv, hero, canFitTable, pageBreak: newPage, finish };
}

/** [PDF 이미지] 미리보기 이미지를 읽고 실패하면 빈 값으로 처리한다. 이미지 유무와 검사 판정은 별개다. */
function loadImage(src) {
  return new Promise((resolve) => {
    if (!src) return resolve(null);
    const image = new Image();
    image.onload = () => resolve(image.naturalWidth && image.naturalHeight ? image : null);
    image.onerror = () => resolve(null);
    image.src = src;
  });
}

// hasP1: 현재 사진에 실제 P1 근거가 있는지 확인한다.
const hasP1 = (item) => pqEvidence(item).present === true;
const RESOLUTION_KO = {
  ADD_SOFT_BINDING: "M1 신규 생성 및 P1 발급",
  REUSE_EXISTING: "기존 매니페스트 재사용 및 P1 발급",
  EXISTING_OUTPUT: "등록 결과 확인 · 기존 P1 재사용",
  EXISTING_SOURCE: "등록 원본 확인 · 기존 결과·P1 재사용",
  RESTORED_CLASSIC: "Classic 기록 복구 · 기존 P1 재사용",
};
const CHECK_LABELS = {
  assertion_hashes: "어설션 해시",
  ingredient_references: "재료 참조",
  source_evidence: "원본 근거",
  classic_validation: "서버 Classic 검사",
  claim_signature: "P1 클레임 서명",
  hard_binding: "하드 바인딩",
  soft_binding: "소프트 바인딩",
};
const VALIDATION_COLUMNS = [
  { title: "판정", w: 0.09 },
  { title: "상태 코드", w: 0.35, mono: true },
  { title: "검사 내용", w: 0.4 },
  { title: "범위", w: 0.16 },
];

// ============================================================================
// 06. 요약·Classic·PQC 페이지 구성
// ============================================================================

/** [검사 표] 같은 코드·결과의 반복을 정리해 한정된 보고서 공간에 넣을 검사 목록을 만든다. */
function compactChecks(item) {
  const groups = new Map(),
    order = { failure: 0, informational: 1, success: 2 };
  for (const c of checksOf(item)) {
    const key = JSON.stringify([c.kind, c.code, c.scope, CODE_KO[c.code] || c.explanation]);
    const group = groups.get(key);
    if (group) group.count++;
    else groups.set(key, { ...c, count: 1 });
  }
  return [...groups.values()]
    .sort((a, b) => (order[a.kind] ?? 3) - (order[b.kind] ?? 3))
    .map((c) => [
      kindKo(c.kind),
      `${c.code}${c.count > 1 ? ` (×${c.count})` : ""}`,
      CODE_KO[c.code] || c.explanation || "상세 메시지 없음",
      SCOPE_KO[c.scope] || c.scope || "범위 미기록",
    ]);
}

/** [시간 표] 현재 사진의 검사·PQC·발급 시각을 출처와 함께 표에 넣을 형태로 만든다. */
function compactTimes(item, meta) {
  // row: 한정된 표에 표시할 검사 코드·결과 행을 구성한다.
  const row = (label, value) => [
    label,
    value?.started_at && value?.completed_at
      ? `${stamp(value.started_at)} 시작\n${stamp(value.completed_at)} 종료`
      : "시작·종료 시각 미기록",
  ];
  const rows = [];
  if (item.input_inspection)
    rows.push(row("입력 C2PA · 서버", item.input_inspection.verification_timing));
  rows.push(
    row(
      item.input_inspection
        ? "결과 C2PA · 서버"
        : item.processing_mode === "browser"
          ? "C2PA · 브라우저"
          : "C2PA · 서버",
      item.verification_timing,
    ),
  );
  if (!item.verification_timing?.started_at && item.created_at)
    rows.at(-1)[1] = `${stamp(item.created_at)} (기록된 검사 시각)`;
  if (item.verification_run) rows.push(row("통합 처리 · 브라우저", item.verification_run));
  rows.push(["보고서 발급", meta.issuedText]);
  return rows;
}

/** [PQC 상태] 임시 샘플 P1·DB P1·미조회·미수행을 구분해 짧게 표시한다. */
function compactPQCLabel(item) {
  const p = pqEvidence(item);
  return p.detached
    ? `${item.conversion_v4?.result?.storage_mode === "EPHEMERAL" ? "샘플 임시 P1" : "DB의 P1"} · ${PQ_STATUS[p.status] || p.status}${p.signature_algorithm ? ` · ${p.signature_algorithm}` : ""}`
    : item.pqc_process?.status === "SKIPPED"
      ? "미수행 · 이번 요청은 Classic C2PA만 검사"
      : p.present
        ? `기존 형식 P1 · ${PQ_STATUS[p.status] || p.status}`
        : "보호 미확인 · DB 조회·검증 완료 결과 없음";
}

/** [첫 페이지] 검사 대상·해시·판정·신청인 입력 등 보고서 종류에 맞는 요약을 그린다. */
function compactOverview(r, item, ctx, type) {
  const { meta, options, preview } = ctx,
    f = facts(item),
    sig = activeManifest(item).signature_info || item.signature || {},
    p = pqEvidence(item);
  r.title(
    TYPES[type].title,
    type === "submission"
      ? "경찰서 제출 시 참고하는 이미지 검사 결과"
      : "Classic C2PA 및 양자내성 보호 검사 결과",
  );
  r.hero(item, preview);
  r.section("1. 분석 대상");
  r.kv(
    [
      ["파일명", filled(item.filename)],
      ["파일 형식·크기", fileLine(item)],
      ["전체 파일 SHA-256", filled(item.sha256, "계산 결과 없음")],
      ...(item.sha3_256 ? [["전체 파일 SHA3-256", item.sha3_256]] : []),
    ],
    { size: 17, maxLines: 2 },
  );
  r.section("2. 검사 요약");
  r.kv(
    [
      [
        "C2PA 기록",
        manifestCount(item)
          ? `Manifest ${manifestCount(item)}개 · 활성 ${filled(item.store?.active_manifest)}`
          : stateOf(item).label,
      ],
      ["서명·파일 결합", opinion(item, f).statement],
      [
        "서명자·신뢰",
        `${filled(sig.common_name, "서명자 미확인")} · ${f.trusted ? "선택한 신뢰 기준에서 확인" : f.untrusted ? "신뢰 미확인" : item.state === "NoManifest" ? "해당 없음" : "검사 결과 확인 필요"}`,
      ],
      ["양자내성 보호", compactPQCLabel(item)],
      ["AI 사용 기록", aiReportDescription(item)],
    ],
    { size: 17, maxLines: 2 },
  );
  r.section("3. 검사·발급 시각");
  r.kv(compactTimes(item, meta), { size: 16, maxLines: 2 });
  if (type === "submission") {
    const rows = [
      ["신청인", typed(options.applicant)],
      ["연락처", typed(options.contactPhone)],
      ["제출처", typed(options.submitTo)],
      ["작성 목적", typed(options.purpose)],
    ]
      .filter(([, value]) => value)
      .map(([key, value]) => [key, `${value} *`]);
    if (rows.length) {
      r.section("4. 신청인 기재 사항");
      r.kv(rows, { size: 16, maxLines: 1 });
      r.para("* 신청인이 입력한 정보이며 검사 판정에 영향을 주지 않음.", { maxLines: 1, size: 15 });
    }
  }
  r.para(
    "서명·기록의 유효성은 사진 내용의 사실 여부를 보증하지 않음. AI 사용 기록은 작성자의 선언이며, 기록 부재가 비AI 이미지를 뜻하지 않음.",
    { size: 15, maxLines: 2 },
  );
}

/** [결합 근거] Manifest에 기록된 콘텐츠 바인딩 해시 정보를 모은다. */
function contentHashes(manifest) {
  return (manifest.assertions || [])
    .filter((a) => /^c2pa\.hash\./.test(a.label || ""))
    .slice(0, 2)
    .map((a) => {
      const d = a.data || {};
      let value = d.hash;
      if (Array.isArray(value) && value.every((v) => Number.isInteger(v) && v >= 0 && v < 256))
        value = value.map((v) => v.toString(16).padStart(2, "0")).join("");
      else if (typeof value !== "string") value = value ? JSON.stringify(value) : "해시 값 미제공";
      return [`서명 대상 해시 · ${d.alg || a.label}`, String(value)];
    });
}

/** [Classic 페이지] 서명·인증서·어설션·파일 결합과 필요한 검사 근거를 제한된 페이지에 배치한다. */
function compactClassic(r, item, ctx, type) {
  const m = activeManifest(item),
    sig = m.signature_info || item.signature || {},
    f = facts(item),
    checks = compactChecks(item);
  r.pageBreak();
  r.title("Classic C2PA 검사 상세", "서명 유효성과 서명자 신뢰를 구분해 표시함");
  r.section("서명·인증서");
  r.kv(
    [
      ["서명자", filled(sig.common_name)],
      ["인증서 발급자", filled(sig.issuer)],
      ["서명 알고리즘", algLabel(sig.alg)],
      ["인증서 일련번호", filled(sig.cert_serial_number)],
      ["기록된 서명 시각", sig.time ? stamp(sig.time) : "기록 없음"],
      ["신뢰 기준", trustKo(item)],
      [
        "인증서 폐지 조회",
        f.ocsp.length ? f.ocsp.map((c) => CODE_KO[c.code] || c.code).join(" / ") : "조회 결과 없음",
      ],
      [
        "타임스탬프 검사",
        f.ts.length ? f.ts.map((c) => CODE_KO[c.code] || c.code).join(" / ") : "검사 결과 없음",
      ],
    ],
    { size: 17, maxLines: 1 },
  );
  r.section("파일 결합·기록 정보");
  r.kv(
    [
      ...contentHashes(m),
      ["기록 작성 도구", filled(softwareName(item), "기록 없음")],
      [
        "검사 도구",
        `${engineKo(item, ctx.env)}${specVersion(item) ? " · C2PA " + specVersion(item) : ""}`,
      ],
      [
        "검사 결과 건수",
        `통과 ${f.counts.success} · 참고 ${f.counts.informational} · 실패 ${f.counts.failure}`,
      ],
    ],
    { size: 17, maxLines: 2 },
  );
  r.para(
    "서명 대상 해시는 C2PA가 정한 영역의 값이며, 1쪽의 전체 파일 SHA-256과 계산 범위가 다름.",
    { size: 15, maxLines: 2 },
  );
  if (type === "submission") {
    r.section("주요 검사 결과 · 실패 항목 우선");
    r.table(
      [
        { title: "판정", w: 0.1 },
        { title: "상태 코드", w: 0.34, mono: true },
        { title: "검사 내용", w: 0.4 },
        { title: "범위", w: 0.16 },
      ],
      checks.slice(0, 6),
      { size: 16, maxLines: 2 },
    );
    if (checks.length > 6)
      r.para(
        `표시한 ${6}개 그룹 외 ${checks.length - 6}개 그룹은 PDF 첨부 JSON에서 확인할 수 있음.`,
        { size: 15, maxLines: 1 },
      );
  } else {
    const actions =
      item.actions ||
      m.assertions
        ?.filter((a) => /^c2pa.actions/.test(a.label || ""))
        .flatMap((a) => a.data?.actions || []) ||
      [];
    r.section("기록된 작업·재료");
    const rows = actions
      .slice(0, 3)
      .map((a) => [
        ACTION_KO[a.action] || a.action || "작업",
        `${a.when ? stamp(a.when) + " · " : ""}${agent(a.softwareAgent) || "도구 미기록"}${a.digitalSourceType ? " · " + sourceType(a.digitalSourceType) : ""}`,
      ]);
    const ingredients = item.ingredients || m.ingredients || [];
    rows.push([
      "연결된 재료",
      ingredients.length
        ? ingredients
            .slice(0, 2)
            .map(
              (i) =>
                `${i.title || i.active_manifest || "제목 없음"} (${i.relationship || "관계 미기록"})`,
            )
            .join(" / ")
        : "기록 없음",
    ]);
    r.kv(rows, { size: 17, maxLines: 2 });
    if (actions.length > 3 || ingredients.length > 2)
      r.para("본문은 작업 3건·재료 2건까지 표시하며 전체 기록은 첨부 JSON에 포함됨.", {
        size: 15,
        maxLines: 2,
      });
    if (
      checks.length &&
      checks.length <= 18 &&
      r.canFitTable(VALIDATION_COLUMNS, checks, { size: 17, maxLines: 2 }, 175)
    ) {
      r.section("검증 상태 코드 · 실패 항목 우선");
      compactValidationTable(r, item, checks);
      return true;
    }
  }
  return false;
}

/** [시간 근거] 현재 사진의 실행 기록을 보고서 타임라인용으로 정리한다. */
function compactTimeline(item) {
  const events = item.verification_run?.events || [];
  if (!events.length)
    return [
      {
        at: item.created_at,
        message: "검사 기록 · 단계별 실행 시각 미기록",
        clock_source: item.processing_mode === "browser" ? "browser" : "server",
      },
    ];

  // priority: 실행 시작·종료와 오류 이벤트가 시간 표에서 먼저 남도록 우선순위를 정한다.
  const priority = (e) =>
    /^RUN_(STARTED|FINISHED|PAUSED)$/.test(e.code)
      ? 0
      : /ERROR|FAILED|NOTICE/.test(e.code)
        ? 1
        : e.code === "CLASSIC_RESPONSE"
          ? 2
          : e.code === "REGISTRATION_RECEIVED"
            ? 3
            : 4;
  return events
    .map((e, index) => ({ ...e, index }))
    .sort((a, b) => priority(a) - priority(b) || a.index - b.index)
    .slice(0, 4)
    .sort((a, b) => a.index - b.index);
}

/** [PQC 페이지] 처리 모드·Classic/P1 연결·서명과 시각·복구 근거를 배치한다. */
function compactProtection(r, item, ctx) {
  const { meta } = ctx,
    job = item.conversion_v4 || item.pqc_process?.job,
    res = job?.result || {},
    p = res.p1_validation || {},
    record = item.v4_registration_record;
  r.pageBreak();
  r.title("PQC 보호 및 검사 실행 기록", "이번 요청의 결과와 기존 등록 당시 기록을 구분함");
  r.section("양자내성 보호 결과");
  if (item.conversion_v4) {
    const mode = res.resolution_mode || res.classic_action;
    r.kv(
      [
        ["처리 방식", RESOLUTION_KO[mode] || filled(mode)],
        [
          "P1 서명·저장 위치",
          `${filled(p.signature_algorithm, "알고리즘 미제공")} · ${PQ_STATUS[pqEvidence(item).status] || "미확인"} · ${res.storage_mode === "EPHEMERAL" ? "샘플 임시 보관 · DB 저장 안 함" : "이미지와 분리해 DB 저장"}`,
        ],
        ["P1 매니페스트 ID", filled(p.manifest_id)],
        [
          res.storage_mode === "EPHEMERAL" ? "샘플 임시 기록 ID" : "DB 기록 쌍 ID",
          filled(res.storage_mode === "EPHEMERAL" ? res.sample_session_id : res.manifest_pair_id),
        ],
        ["프로파일·컨테이너", `${filled(p.profile)} · ${filled(p.container)}`],
        ["연결 핑거프린트", filled(res.fingerprint_base64)],
        [
          "타임스탬프 상태",
          {
            M0_TOKEN_EXISTING: "기존 M0 토큰 사용",
            M1_SIGTST2_ISSUED: "M1 sigTst2 발급",
            NOT_AVAILABLE: "정보 없음",
          }[p.timestamp] || filled(p.timestamp),
        ],
        [
          "등록 검증 기록",
          record
            ? `${record.validation_id || res.validation_id} · ${filled(record.overall_status)} (기존 등록 당시)`
            : "등록 검증 ID가 없거나 기록을 조회하지 못함",
        ],
      ],
      { size: 16, maxLines: 1 },
    );
    const rows = Object.entries(CHECK_LABELS).map(([key, label]) => [
      label,
      ["VALID", "SDK_VALIDATED"].includes(p[key])
        ? "통과"
        : p[key] === "INVALID"
          ? "실패"
          : p[key] || "미확인",
    ]);
    const pairs = [];
    for (let i = 0; i < rows.length; i += 2) pairs.push([...rows[i], ...(rows[i + 1] || ["", ""])]);
    r.table(
      [
        { title: "P1 검사 항목", w: 0.34 },
        { title: "결과", w: 0.16 },
        { title: "P1 검사 항목", w: 0.34 },
        { title: "결과", w: 0.16 },
      ],
      pairs,
      { size: 15, maxLines: 1 },
    );
    const token = record?.timestamp_evidence?.[0];
    if (token)
      r.para(
        `기존 등록 토큰: ${token.purpose || "용도 미기록"} · ${token.generation_time || "발급 시각 미제공"}`,
        { size: 15, maxLines: 2 },
      );
    r.para(
      "Classic은 자체 CA, P1은 서버 고정 HAETAE 공개키 기준의 실험용 프로파일임. 위 결과는 서버 응답이며 브라우저의 독립 서명 검증 결과가 아님. 기존 M0 토큰은 신규 P1 발급 시각을 증명하지 않음.",
      { size: 15, maxLines: 2 },
    );
  } else {
    r.kv(
      [
        ["PQC 통합 처리 상태", filled(item.pqc_process?.status, "완료 결과 없음")],
        ["결과", compactPQCLabel(item)],
        [
          "처리 안내",
          item.pqc_process?.message || job?.error?.message || pqConclusion(pqEvidence(item)),
        ],
        ["Classic 검사 대상", "입력 이미지"],
      ],
      { size: 17, maxLines: 3 },
    );
  }
  r.section("선택한 이미지의 실행 기록");
  const timeline = compactTimeline(item),
    total = item.verification_run?.events?.length || timeline.length;
  r.table(
    [
      { title: "실행 시각 · 시계 기준", w: 0.37 },
      { title: "실행 내용", w: 0.63 },
    ],
    timeline.map((e) => [
      `${stamp(e.at)}\n${e.clock_source === "server" ? "서버" : "브라우저"} 기록`,
      e.message || e.code,
    ]),
    { size: 15, maxLines: 2 },
  );
  if (total > timeline.length)
    r.para(
      `전체 ${total}건 중 주요 ${timeline.length}건 표시. 전체 실행 기록과 원문은 PDF 첨부 verification-record.json에 포함됨.`,
      { size: 14, maxLines: 1 },
    );
  r.section("문서 발급");
  r.kv(
    meta.issuance
      ? [
          ["발급 확인", `${meta.issuance.doc_no} · 확인번호 ${meta.issuance.verification_code}`],
          [
            "발급 기록 서명",
            meta.issuance.signature?.status === "SIGNED"
              ? issuanceAlgorithm(meta.issuance)
              : "서명 기록 없음",
          ],
        ]
      : [["발급 상태", `서버 미등록${meta.offlineReason ? " · " + meta.offlineReason : ""}`]],
    { size: 15, maxLines: 2 },
  );
  r.para(
    "본 문서는 자동 생성 검사 참고자료이며 수사기관의 공식 감정서가 아님. 전체 JSON은 문서 첨부 파일에 보관됨. ‘…’ 표시는 긴 내용의 축약임.",
    { size: 14, maxLines: 2 },
  );
}

/** [검사 표] 검사 코드와 실제 결과를 보고서 표에 그린다. */
function compactValidationTable(r, item, rows) {
  r.table(VALIDATION_COLUMNS, rows.slice(0, 18), { size: 17, maxLines: 2 });
  r.para(
    rows.length > 18
      ? `전체 ${rows.length}개 그룹 중 주요 18개 그룹 표시. 나머지 ${rows.length - 18}개 그룹을 포함한 원문은 첨부 JSON에서 확인할 수 있음.`
      : "같은 판정·상태 코드·범위·검사 내용을 ×건수로 묶어 표시함. 개별 참조 대상은 첨부 JSON에 포함됨.",
    { size: 16, maxLines: 2 },
  );
  const failing = checksOf(item).filter((c) => c.kind === "failure").length;
  r.para(
    `검사 실패 ${failing}건. 참고·미수행·정보 없음은 통과 판정이 아님. 서명자 신뢰는 서명 및 파일 결합 검사와 별도로 해석함.`,
    { size: 16, maxLines: 2 },
  );
}

/** [검사 페이지] 추가 검사 근거를 한 페이지에 정리한다. */
function compactValidation(r, item) {
  const rows = compactChecks(item);
  if (!rows.length) return;
  r.pageBreak();
  r.title("검증 상태 코드", "실패 → 참고 → 통과 순서 · 같은 코드도 검사 범위가 다르면 구분함");
  compactValidationTable(r, item, rows);
}

/** [경찰서 제출용] 신청인 기재·대상 파일·검사 결론·Classic/PQC 근거를 제출 참고자료로 구성한다. */
function submissionReport(r, item, ctx) {
  compactOverview(r, item, ctx, "submission");
  if (manifestCount(item) || checksOf(item).length) compactClassic(r, item, ctx, "submission");
  compactProtection(r, item, ctx);
}

/** [상세 분석용] 신청인 정보 없이 Classic·PQC·상세 검사 데이터를 구성한다. */
function technicalReport(r, item, ctx) {
  compactOverview(r, item, ctx, "technical");
  const embedded =
    manifestCount(item) || checksOf(item).length
      ? compactClassic(r, item, ctx, "technical")
      : false;
  compactProtection(r, item, ctx);
  if (!embedded) compactValidation(r, item);
}

// ---------- entry ----------
// Values sent to the issuance server: hashes and the result summary only. Names, case
// numbers and the request text stay in the browser; only their SHA-256 is registered.

// ============================================================================
// 07. 외부 호출용 발급 자료와 PDF 생성 진입점
// ============================================================================

/** [개인정보 분리] 신청인 기입값을 브라우저에서 정리한다. 발급 요청에는 원문 대신 해시만 사용한다. */
function declaredValues(options) {
  return Object.fromEntries(
    Object.entries(DECLARED_KEYS)
      .map(([key, field]) => [field, typed(options[key])])
      .filter(([, value]) => value),
  );
}

/** [발급 요청] 보고서 종류·증거 스냅샷 해시·검사 요약을 만든다. 상세 분석용에는 신청인 필드를 넣지 않는다. */
export async function prepareIssuance(item, reportType, options = {}) {
  if (reportType !== "submission") options = analysisOptions(options);
  const record = recordSnapshot(item),
    values = declaredValues(options),
    pq = pqEvidence(item);

  // hex64: 64자리 소문자 16진 해시 형식인지 확인하고 잘못된 값은 null로 둔다.
  const hex64 = (value) => (/^[0-9a-f]{64}$/.test(String(value || "")) ? value : null);
  return {
    report_type: TYPES[reportType] ? reportType : "technical",
    snapshot_sha256: await sha256Hex(stableStringify(record)),
    declared_sha256: await sha256Hex(stableStringify(values)),
    declared_fields: Object.keys(values),
    verification_id: /^[0-9a-f]{32}$/.test(String(item.inspection_id || ""))
      ? item.inspection_id
      : /^[0-9a-f]{32}$/.test(String(item.id || "")) && item.report_saved !== false
        ? item.id
        : null,
    file: {
      sha256: hex64(item.sha256) || "0".repeat(64),
      sha3_256: hex64(item.sha3_256),
      size: Number.isFinite(item.size) ? item.size : 0,
      mime: safe(item.mime, 120),
    },
    result: {
      state: STATES[item.state] ? item.state : "Unknown",
      manifest_count: manifestCount(item),
      pq_status: PQ_STATUS[pq.status] ? pq.status : "NOT_PRESENT",
      trust_profile: item.trust_profile === "lab" ? "lab" : "standard",
      processing_mode: item.processing_mode === "browser" ? "browser" : "server",
    },
    phone_token: options.phoneToken || null,
  };
}

/** [보고서 옵션] 상세 분석에 사용할 출력 설정을 정리한다. */
function analysisOptions(options) {
  const clean = { ...options };
  for (const key of [...Object.keys(DECLARED_KEYS), "contactPhone", "phoneToken"])
    delete clean[key];
  return clean;
}

/** [PDF 생성] 현재 사진의 검사 스냅샷으로 최대 4쪽 PDF를 만들고 전체 근거 JSON을 첨부한다. */
export async function buildPdfReport(source, reportType = "technical", options = {}) {
  if (reportType !== "submission") options = analysisOptions(options);
  const type = TYPES[reportType] ? reportType : "technical",
    spec = TYPES[type];
  const issuance =
    options.issuance && !options.issuance.offline && options.issuance.doc_no
      ? options.issuance
      : null;
  const record = recordSnapshot(source),
    recordJson = JSON.stringify(record, null, 2);
  const snapshotHash = await sha256Hex(stableStringify(record));
  // Browser verification does not fingerprint the P1 public key; compute it the same way as the server.
  let item = source;
  const p1 = pqEvidence(source);
  if (p1.present && !p1.public_key_sha256 && p1.public_key_pem)
    item = {
      ...source,
      pq_evidence: { ...p1, public_key_sha256: await sha256Hex(p1.public_key_pem) },
    };
  // Issue time and number come from the server; without it the PC clock is used and marked.
  const server = issuance ? isoParts(issuance.issued_at) : null;
  const issued = server ? new Date(issuance.issued_at) : new Date();
  const day = `${issued.getFullYear()}${pad(issued.getMonth() + 1)}${pad(issued.getDate())}`;
  const docNo = issuance
    ? issuance.doc_no
    : `PQC-${spec.code}-${day}-L${(snapshotHash || "00000000").slice(0, 7).toUpperCase()}`;
  const meta = {
    docNo,
    kind: spec.kind,
    issued,
    snapshotHash,
    page: spec.page,
    serif: type === "submission",
    issuance,
    offlineReason: options.issuance?.offline
      ? safe(options.issuance.reason || "", 120)
      : options.register === false
        ? "작성자가 등록하지 않음"
        : "",
    issuedText: server ? server.text : `${stamp(issued)}, 작성자 PC 시각`,
    issuedDot: server ? server.dot : dotDate(issued),
    issuedLong: server ? server.long : longDate(issued),
    headerLeft: `문서번호 : ${docNo}`,
    headerRight: orgName(options) || "PQ-C2PA Viewer",
    footerLeft: issuance
      ? `확인번호 ${issuance.verification_code}`
      : `미등록 발급 · 기록 스냅샷 SHA-256 ${snapshotHash ? `${snapshotHash.slice(0, 24)}…` : "—"}`,
    footerRight: `PQC-F-${spec.code} · A4(210×297)`,
  };
  const includePreview = options.includePreview !== false;
  const isImage = String(item.mime || "").startsWith("image/");
  const currentImage = includePreview && isImage ? await loadImage(options.currentImageUrl) : null;
  const preview = includePreview ? currentImage || (await loadImage(item.thumbnail)) : null;
  const r = createRenderer(meta);
  const context = { meta, options, env: options.environment || null, preview };
  if (type === "submission") submissionReport(r, item, context);
  else technicalReport(r, item, context);
  const pages = r.finish();

  const doc = await PDFDocument.create();
  doc.setTitle(`${spec.title} · ${safe(item.filename, 120)}`);
  doc.setSubject(`C2PA ${spec.kind} · 문서번호 ${docNo}`);
  doc.setAuthor(typed(options.applicant) || "PQ-C2PA Viewer");
  doc.setKeywords([
    "C2PA",
    "Content Credentials",
    "PQ-C2PA",
    docNo,
    `sha256:${item.sha256 || ""}`,
    `snapshot:${snapshotHash}`,
  ]);
  doc.setCreator("PQ-C2PA Viewer");
  doc.setProducer("PQ-C2PA report engine (pdf-lib)");
  doc.setLanguage("ko-KR");
  doc.setCreationDate(issued);
  doc.setModificationDate(issued);
  for (const canvas of pages) {
    const png = await doc.embedPng(canvas.toDataURL("image/png"));
    const page = doc.addPage([595.28, 841.89]);
    page.drawImage(png, { x: 0, y: 0, width: 595.28, height: 841.89 });
  }

  // attach: 완전한 검사 JSON을 현재 문서번호와 연결해 PDF에 첨부한다.
  const attach = (data, name, description) =>
    doc.attach(new TextEncoder().encode(data), name, {
      mimeType: "application/json",
      description: `${description} · 문서번호 ${docNo}`,
      creationDate: issued,
      modificationDate: issued,
    });
  await attach(recordJson, "verification-record.json", "C2PA 검증 기록 원본");
  await attach(
    JSON.stringify(
      issuance
        ? {
            doc_no: issuance.doc_no,
            verification_code: issuance.verification_code,
            verify_url: issuance.verify_url,
            issued_at: issuance.issued_at,
            record: issuance.record,
            record_sha256: issuance.record_sha256,
            signature: issuance.signature,
          }
        : {
            registered: false,
            reason: meta.offlineReason || null,
            local_doc_no: docNo,
            issued_at_pc: issued.toISOString(),
            snapshot_sha256: snapshotHash,
          },
      null,
      2,
    ),
    "issuance-record.json",
    issuance ? `발급 기록(서버 등록·${issuanceAlgorithm(issuance)} 서명)` : "발급 기록(미등록)",
  );
  if (options.conversion)
    await attach(
      JSON.stringify(options.conversion, null, 2),
      "conversion-record.json",
      "PQ 변환 작업 기록",
    );
  return await doc.save();
}

export { hasP1 };
export const REPORT_TYPES = Object.fromEntries(
  Object.entries(TYPES).map(([key, value]) => [key, { title: value.title, kind: value.kind }]),
);
