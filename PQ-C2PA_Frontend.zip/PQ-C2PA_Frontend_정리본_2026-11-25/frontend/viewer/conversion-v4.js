/**
 * PQC API 어댑터와 결과 카드. 현재 실행 프로필은 분리 JUMBF P1 / HAETAE-3이다.
 * readJob: 계약 확인 / canDownload: 필수 검사 확인 / createController: 접수·조회·중지·재개.
 * 알고리즘 이름·식별자·DB 등록 여부는 응답을 그대로 읽으며, 미제공 상태를 완료로 표시하지 않는다.
 */
// V4 contract adapter: detached JUMBF P1. Never infer fields that the API omits.

// ============================================================================
// 01. 응답 계약과 다운로드 허용 조건
// ============================================================================

// escapeHTML: API 문자열을 안전한 HTML 표시값으로 바꾼다.
const escapeHTML = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
const cid = /^conv_[0-9a-f]{32}$/;
const vid = /^val_[0-9a-f]{32}$/;
const outcomes = new Set(["QUEUED", "PROCESSING", "COMPLETED", "FAILED"]);
const validChecks = [
  "assertion_hashes",
  "ingredient_references",
  "source_evidence",
  "claim_signature",
  "hard_binding",
  "soft_binding",
];

/** [응답 계약] 변환 ID·상태·P1 프로필이 현재 서버 계약에 맞는지 확인한다. 없는 필드를 만들어 채우지 않는다. */
export function readJob(response) {
  const job = response?.data;
  if (!job || !cid.test(job.conversion_id || "") || !outcomes.has(job.status))
    throw Error("V4 작업 응답을 읽을 수 없습니다. 연결된 서버의 API 버전을 확인하세요.");
  if (
    job.status === "COMPLETED" &&
    (job.result?.p1_validation?.profile !== "pq-c2pa-jumbf-haetae3-1" ||
      job.result?.p1_validation?.container !== "JUMBF")
  )
    throw Error("지원하지 않는 P1 결과입니다. HAETAE-3 서버인지 확인하세요.");
  return job;
}

/** [샘플 구분] 임시 보관 방식·세션 ID·처리 모드를 확인해 영구 DB 등록 작업과 구분한다. */
export function isSample(job) {
  const r = job?.result;
  return (
    ["present", "removed", "absent"].includes(job?.sample_id) &&
    r?.storage_mode === "EPHEMERAL" &&
    !r.manifest_pair_id &&
    ["ADD_SOFT_BINDING", "REUSE_EXISTING", "RESTORED_CLASSIC"].includes(
      r.resolution_mode || r.classic_action,
    ) &&
    /^sample_[0-9a-f]{32}$/.test(r.sample_session_id || "")
  );
}

/** [다운로드 조건] 작업 완료뿐 아니라 P1 서명·어설션·하드/소프트 바인딩과 신뢰 범위가 필수 조건을 만족하는지 확인한다. */
export function canDownload(job) {
  const r = job?.result,
    p = r?.p1_validation;
  return (
    job?.status === "COMPLETED" &&
    r?.trust_status === "TRUSTED" &&
    p?.profile === "pq-c2pa-jumbf-haetae3-1" &&
    p?.container === "JUMBF" &&
    validChecks.every((k) => p[k] === "VALID") &&
    p.classic_validation === "SDK_VALIDATED" &&
    p.signer === "FRAMEWORK_PINNED_SIGNER" &&
    p.conformance === "EXPERIMENTAL_PQ_PROFILE" &&
    typeof p.manifest_id === "string" &&
    !!p.manifest_id &&
    (isSample(job) ||
      (r.storage_mode !== "EPHEMERAL" && /^pair_[0-9a-f]{32}$/.test(r.manifest_pair_id || ""))) &&
    typeof r.fingerprint_base64 === "string" &&
    !!r.fingerprint_base64
  );
}

/** [다운로드 주소] 검증한 변환 ID로 결과 이미지 API 경로를 만든다. */
export function assetPath(job) {
  if (!cid.test(job?.conversion_id || "")) throw Error("변환 ID가 올바르지 않습니다.");
  return `/api/v1/conversions/${job.conversion_id}/asset`;
}

/** [처리 설명] M1 생성·기존 기록 재사용·복구·실패를 서로 다른 문장으로 표시한다. */
export function describeResolution(job) {
  if (job?.status === "SKIPPED")
    return [
      "PQC 처리를 실행하지 않았습니다",
      job.error?.message ||
        "이번 검사에서는 C2PA만 확인했습니다. PQC 보호를 받으려면 원본 파일을 업로드하세요.",
    ];
  // Only a completed and verified response can establish existing PQC protection.
  if (!canDownload(job))
    return [
      "PQC 보호를 확인하지 못했습니다",
      "검사가 완료되지 않았거나 필수 검사를 통과하지 못했습니다. 오류 내용을 확인해 주세요.",
    ];
  const r = job?.result || {},
    mode = r.resolution_mode || r.classic_action;
  if (isSample(job))
    return mode === "RESTORED_CLASSIC"
      ? [
          "C2PA 출처 기록을 복구했습니다",
          "이번 시연에서 생성한 임시 P1의 서명과 파일 결합을 확인하고 C2PA를 복구했습니다. 샘플과 보호 기록은 영구 DB에 저장하지 않습니다.",
        ]
      : [
          "PQC 보호가 자동으로 생성되었습니다",
          "이번 샘플 검사에서 새 PQC 서명을 실제로 생성하고 검증했습니다. 재검사할 때도 새로 처리하며 영구 DB에는 저장하지 않습니다.",
        ];
  const known = {
    EXISTING_OUTPUT: [
      "이미 PQC로 보호된 이미지입니다",
      "DB에 등록된 기존 PQC 보호 기록(P1)의 서명과 이미지 연결을 다시 확인했습니다. 새 P1을 발급하지 않았습니다.",
    ],
    EXISTING_SOURCE: [
      "이 이미지의 PQC 보호 기록이 이미 있습니다",
      "등록된 원본과 일치해 기존 결과 이미지와 PQC 보호 기록(P1)을 재검증했습니다. 새 P1을 발급하지 않았습니다. 상단에서 보호된 결과 이미지를 받을 수 있습니다.",
    ],
    RESTORED_CLASSIC: [
      "C2PA 출처 기록을 복구했습니다",
      "이미 등록된 PQC 보호 기록(P1)을 확인하고, 이미지에서 사라진 Classic 출처 기록을 복구해 검증했습니다. 새 P1을 발급하지 않았습니다.",
    ],
    ADD_SOFT_BINDING: [
      "PQC 보호 기록을 자동으로 생성했습니다",
      "기존 C2PA 검증을 통과해 핑거프린트를 담은 M1과 PQC 보호 기록(P1)을 생성했습니다. P1은 이미지와 분리해 DB에 저장했습니다.",
    ],
    REUSE_EXISTING: [
      "PQC 보호 기록을 자동으로 생성했습니다",
      "기존 매니페스트와 핑거프린트를 재사용하고 PQC 보호 기록(P1)을 새로 생성했습니다. P1은 이미지와 분리해 DB에 저장했습니다.",
    ],
  };
  return (
    known[mode] || [
      "처리 결과 확인 필요",
      "서버에서 반환한 처리 방식을 확인할 수 없습니다. 상세 응답을 확인하세요.",
    ]
  );
}

/** [보호 상태] 실제 완료 응답을 기준으로 신규 보호·기존 보호·샘플 상태를 구분한다. */
export function protectionStatus(job) {
  if (!canDownload(job)) return { kind: "unknown", label: "보호 미확인" };
  const r = job.result,
    mode = r.resolution_mode || r.classic_action;
  if (["EXISTING_OUTPUT", "EXISTING_SOURCE"].includes(mode))
    return { kind: "existing", label: "기존 PQC 확인" };
  if (mode === "RESTORED_CLASSIC")
    return { kind: "restored", label: "기존 PQC 확인 · 출처 기록 복구" };
  if (["ADD_SOFT_BINDING", "REUSE_EXISTING"].includes(mode))
    return { kind: "created", label: "PQC 자동 생성 완료" };
  return { kind: "unknown", label: "처리 방식 미확인" };
}

/** [다운로드 문구] 처리 결과에 맞는 버튼 이름과 파일 설명을 고른다. */
export function imageDownloadInfo(job) {
  const mode = job?.result?.resolution_mode || job?.result?.classic_action,
    kind =
      mode === "RESTORED_CLASSIC"
        ? "restored"
        : ["ADD_SOFT_BINDING", "REUSE_EXISTING"].includes(mode)
          ? "converted"
          : "protected";
  return {
    enabled: canDownload(job),
    kind,
    label:
      kind === "restored"
        ? "복구된 이미지 다운로드"
        : kind === "converted"
          ? "PQC 변환 이미지 다운로드"
          : "PQC 보호 이미지 다운로드",
    filename: job?.result?.filename,
  };
}

/** [시간 정보] 서버 타임스탬프 상태 코드를 안내 문구로 바꾼다. */
export function timestampLabel(value) {
  return (
    {
      NOT_AVAILABLE: "타임스탬프 정보 없음",
      M0_TOKEN_EXISTING: "기존 M0 토큰 사용",
      M1_SIGTST2_ISSUED: "M1 sigTst2 발급",
    }[value] || "상태 미확인"
  );
}

/** [AI 근거] 변환 작업과 등록 기록에서 AI 해설에 필요한 검사 근거를 모은다. */
export function aiEvidence(job, record) {
  const r = job.result || {};
  const report = {
    conversion_id: job.conversion_id,
    status: job.status,
    source_classic_c2pa: job.source?.classic_c2pa || null,
    result: {
      trust_status: r.trust_status,
      classic_action: r.classic_action,
      manifest_pair_id: r.manifest_pair_id,
      p1_validation: r.p1_validation,
    },
  };
  if (r.resolution_mode) report.result.resolution_mode = r.resolution_mode;
  report.result.storage_mode = r.storage_mode || "PERSISTENT";
  if (record)
    report.registration_record = {
      validation_id: record.validation_id,
      overall_status: record.overall_status,
      checks: record.checks,
      timestamp_evidence: record.timestamp_evidence,
    };
  return report;
}

// ============================================================================
// 02. HTTP 요청과 표시용 도구
// ============================================================================

/** [API 공통] 같은 출처의 API에 요청하고 오류 형식·빈 응답·HTTP 상태를 처리한다. */
export async function apiJSON(path, options = {}) {
  const response = await fetch(path, options);
  let body;
  try {
    body = await response.json();
  } catch {
    throw Error(`서버 응답을 읽을 수 없습니다 (${response.status}).`);
  }
  if (!response.ok) {
    const d = body.detail;
    let msg =
      body.error?.message ||
      (typeof d === "string"
        ? d
        : Array.isArray(d)
          ? "입력 형식을 확인하세요."
          : `요청 실패 (${response.status})`);
    if (response.status === 503 && typeof d === "string" && d.includes("PQ_C2PA_V4_BASE_URL"))
      msg =
        "PQC 처리 서버가 연결되지 않아 자동 생성과 기존 보호 여부를 확인할 수 없습니다. 서버 연결 후 다시 시도해 주세요.";
    const e = Error(msg);
    e.status = response.status;
    throw e;
  }
  return body;
}

// row: 항목 이름과 값 한 줄을 만든다.
const row = (label, value) =>
  `<div class="pq-record-row"><span>${escapeHTML(label)}</span><strong>${escapeHTML(value ?? "정보 없음")}</strong></div>`;

// code: 긴 식별자나 해시를 코드 영역으로 표시한다.
const code = (label, value) =>
  `<div class="pq-full-value"><span>${escapeHTML(label)}</span><code>${escapeHTML(value ?? "정보 없음")}</code></div>`;

// short: 카드 요약의 긴 식별자를 줄여 표시한다.
const short = (value) => {
  const s = String(value || "");
  return s.length > 30 ? `${s.slice(0, 18)}…${s.slice(-8)}` : s || "확인되지 않음";
};

// full: 식별자의 전체 값과 복사 버튼을 만든다.
const full = (label, value) =>
  `<div class="pq-full-value"><div><span>${escapeHTML(label)}</span>${value ? `<button type="button" data-pq-copy="${escapeHTML(value)}" aria-label="${escapeHTML(label)} 복사">복사</button>` : ""}</div><code>${escapeHTML(value || "정보 없음")}</code></div>`;

/** [지문 읽기] Classic 어설션에서 소프트 바인딩 지문을 읽는다. */
function softBinding(manifest) {
  const assertion = (manifest?.assertions || []).find((a) =>
    a.label?.startsWith("c2pa.soft-binding"),
  );
  const data = assertion?.data || {},
    block = Array.isArray(data.blocks) ? data.blocks[0] || {} : {};
  return {
    label: assertion?.label,
    algorithm: data.alg || data.algorithm || block.alg,
    encoded:
      data.value_base64 ||
      block.value_base64 ||
      (typeof block.value === "string" ? block.value : null),
    display: data.display || (String(data.value || "").startsWith("ISCC:") ? data.value : ""),
  };
}

/** [결과 카드] 기본 정보 아래에 펼쳐 볼 수 있는 상세 기록 영역을 만든다. */
function recordDetails(content) {
  return `<details class="pq-record-detail"><summary><span class="pq-closed">기록 상세 보기</span><span class="pq-open">기록 상세 접기</span><i aria-hidden="true">⌄</i></summary><div class="pq-record-body">${content}</div></details>`;
}

/** [서명 주체] 서버가 반환한 인증서 또는 고정 공개키 참조를 구분해 표시한다. */
function certificate(info) {
  return info?.key_reference
    ? `<section class="pq-card-section"><h4>서명 공개키</h4>${row("서명자", info.common_name)}${row("신뢰 기준", info.issuer)}${code("고정 공개키 참조", info.key_reference)}</section>`
    : `<section class="pq-card-section"><h4>서명 인증서</h4>${row("서명자", info?.common_name)}${row("발급자", info?.issuer)}</section>`;
}

/** [시간 정보] 실제 반환된 타임스탬프와 그 검증 범위를 표시한다. */
function timestamp(info, fallback) {
  return `<section class="pq-card-section"><h4>${info?.scope === "REFERENCE_TO_CLASSIC_SIGNATURE" ? "참조한 Classic 타임스탬프" : "타임스탬프"}</h4>${row("기록된 시각", info?.generation_time)}${row("발급기관", info?.issuer)}<p class="pq-record-note">${escapeHTML(fallback)}</p></section>`;
}

// ============================================================================
// 03. JSON 근거와 PQC 결과 카드
// ============================================================================

/** [원본 데이터] 입력 Classic·결과 Classic·분리 P1·등록 기록을 원문 선택 목록으로 정리한다. */
export function jsonSources(job, { classic = null, input = null, record = null } = {}) {
  return [
    {
      id: "classic",
      label: "Manifest Store · 현재 이미지",
      value: classic?.store || {},
      manifestStore: true,
      inspectionState: classic?.state,
      description:
        "현재 이미지에서 읽은 C2PA 출처 기록 묶음입니다. active_manifest는 현재 기록, manifests는 포함된 매니페스트 목록입니다.",
    },
    ...(job
      ? [
          {
            id: "pqc",
            label: "PQC 처리 응답",
            value: job,
            description: "이번 요청의 서버 응답입니다. P1 원문이 아닌 처리·검증 결과입니다.",
          },
        ]
      : []),
    ...(record
      ? [
          {
            id: "registration",
            label: "등록 검증 기록",
            value: record,
            description: "기존 발급 때 저장된 검증 기록입니다. 이번 검사 시각과 구분합니다.",
          },
        ]
      : []),
    ...(input
      ? [
          {
            id: "input-store",
            label: "Manifest Store · 입력 이미지",
            value: input.store || {},
            manifestStore: true,
            inspectionState: input.state,
            description:
              "처리 전 업로드한 이미지의 C2PA 기록입니다. 복구 결과의 기록과 구분해 확인하세요.",
          },
          {
            id: "input",
            label: "입력 이미지 전체 검사",
            value: input,
            description: "처리 전 입력 이미지의 파일 정보와 C2PA 검사 결과 전체입니다.",
          },
        ]
      : []),
  ];
}

/** [원본 데이터] Manifest Store의 기록 수와 활성 기록 ID를 읽는다. */
export function manifestStoreInfo(source) {
  if (!source?.manifestStore) return null;
  const store = source.value || {},
    state = source.inspectionState || store.validation_state || "Unknown";
  const manifests = store.manifests,
    readable = !!manifests && typeof manifests === "object" && !Array.isArray(manifests);
  const count = readable ? Object.keys(manifests).length : state === "NoManifest" ? 0 : null;
  const active = typeof store.active_manifest === "string" ? store.active_manifest : "";
  return {
    count,
    active,
    state,
    activePresent: !!active && readable && Object.hasOwn(manifests, active),
  };
}

/** [원본 데이터] Manifest Store의 개수와 현재 기록을 요약해 보여준다. */
export function renderManifestReadout(source) {
  const info = manifestStoreInfo(source);
  if (!info) return "";
  const status =
    {
      Trusted: "서명·파일 결합 유효 · 신뢰 확인",
      Valid: "서명·파일 결합 유효 · 신뢰 미확인",
      NoManifest: "출처 기록 없음",
      Invalid: "검증 실패",
      Error: "검사 미완료",
      RemoteUnavailable: "외부 기록 확인 필요",
    }[info.state] || "상태 미확인";
  return `<div class="json-manifest-readout"><div><span>매니페스트 수</span><strong>${info.count === null ? "미확인" : info.count + "개"}</strong></div><div><span>C2PA 검사 결과</span><strong>${escapeHTML(status)}</strong></div><div class="json-active-manifest"><span>active_manifest · 현재 기록 ID</span><code>${escapeHTML(info.active || (info.state === "NoManifest" ? "없음" : "확인되지 않음"))}</code>${info.active && !info.activePresent ? "<small>현재 기록 ID에 대응하는 매니페스트를 읽지 못했습니다.</small>" : ""}</div></div>`;
}

/** [원본 데이터] 검사 상세에서 사용할 JSON 원문 선택기와 복사·다운로드 버튼을 만든다. */
export function renderJsonInspector(job, context = {}) {
  const sources = jsonSources(job, context),
    first = sources[0],
    raw = JSON.stringify(first.value, null, 2),
    preview =
      raw.length > 500000
        ? raw.slice(0, 500000) +
          "\n… 화면 표시 범위를 넘었습니다. 전체 내용은 복사·JSON 저장으로 확인하세요."
        : raw;
  return `<section class="result-json" aria-label="검사 데이터 JSON"><header><div><h3>검사 데이터 · JSON</h3><p>이미지에서 읽은 기록과 서버의 처리 응답을 구분해 확인하세요.</p></div><div class="result-json-actions"><button type="button" data-json-action="copy">전체 복사</button><button type="button" data-json-action="download">JSON 저장 ↓</button></div></header><div class="result-json-toolbar"><label>데이터 <select data-json-source aria-label="JSON 데이터 선택">${sources.map((s) => `<option value="${s.id}">${escapeHTML(s.label)}</option>`).join("")}</select></label><label class="result-json-search">JSON 검색 <input type="search" data-json-search aria-label="JSON 검색" placeholder="키 또는 값 검색" autocomplete="off"></label><span data-json-count role="status" aria-live="polite"></span></div><p class="result-json-description">${escapeHTML(first.description)}</p><div data-manifest-readout>${renderManifestReadout(first)}</div><pre class="result-json-code" tabindex="0" aria-label="JSON 원문" data-scroll-region><code>${escapeHTML(preview)}</code></pre><p class="result-json-note">복사·저장은 선택한 데이터 전체를 포함합니다. 검색은 화면 표시만 바꿉니다.</p></section>`;
}

/** [PQC 결과] 요약 카드·두 기록의 연결·서명 근거를 표시한다. 필드 미제공과 검증 실패를 구분한다. */
export function renderResult(
  job,
  {
    classic = null,
    input = null,
    record = null,
    recordError = "",
    notice = "",
    paused = false,
    isOutput = true,
    ai = "",
    aiError = "",
    actions = true,
  } = {},
) {
  if (job.status === "SKIPPED") {
    const [title, description] = describeResolution(job);
    const classicStatus =
      {
        NoManifest: "C2PA 기록 없음",
        Trusted: "서명·파일 결합 유효 · 서명자 신뢰 확인",
        Valid: "서명·파일 결합 유효 · 서명자 신뢰 미확인",
        Invalid: "C2PA 검증 실패",
        Error: "C2PA 검사 오류",
      }[classic?.state] || "결과 확인 필요";
    return `<section class="v4-result pq-result-surface" data-protection="not-requested" aria-label="PQC 처리 범위"><div class="v4-result-heading"><span class="v4-result-icon unknown" aria-hidden="true">i</span><div><span class="v4-result-kicker">INSPECTION SCOPE</span><h2>${escapeHTML(title)}</h2><p>${escapeHTML(notice || description)}</p></div></div><div class="pq-verification-content">${row("검사한 이미지", classic?.filename || job.source?.filename)}${row("C2PA 검사 결과", classicStatus)}${row("P1 DB 조회", "실행하지 않음")}${row("PQC 보호 기록 생성", "실행하지 않음")}</div><p class="pq-record-note">PQC 처리를 실행하지 않았다는 뜻이며 서명 검증 실패나 보호 기록이 없다는 판정이 아닙니다.</p></section>`;
  }
  const ephemeral = isSample(job),
    r = job.result || {},
    p = r.p1_validation || {},
    [title, description] = describeResolution(job),
    ready = canDownload(job),
    protection = protectionStatus(job);
  const store = classic?.store || {},
    manifest = store.manifests?.[store.active_manifest] || {},
    signature = manifest.signature_info || classic?.signature || {};
  const soft = softBinding(manifest),
    parent = (manifest.ingredients || []).find((i) => i.relationship === "parentOf");
  const inputName = input?.filename || job.source?.filename || classic?.filename;
  const classicId = store.active_manifest,
    sourceId = input?.store?.active_manifest || parent?.active_manifest;
  const classicAlg = signature.alg ? String(signature.alg).toUpperCase() : null;
  // Optional algorithm/certificate fields are supplied by the backend; do not invent signer names.
  const pqAlg = p.signature_algorithm || r.p1_signature_info?.alg;

  // normalize: Base64 지문을 비교할 때 공백과 끝의 패딩 차이를 정리한다.
  const normalize = (value) =>
    String(value || "")
      .replace(/\s/g, "")
      .replace(/=+$/, "");
  const hasBoth = !!soft.encoded && !!r.fingerprint_base64;
  const same = hasBoth && normalize(soft.encoded) === normalize(r.fingerprint_base64);
  const linkLabel = same
    ? /iscc/i.test(soft.algorithm || "")
      ? "같은 ISCC 지문"
      : "같은 핑거프린트"
    : hasBoth
      ? "지문 불일치"
      : ready
        ? "서버에서 연결 검증"
        : "연결 여부 미확인";
  const mode = r.resolution_mode || r.classic_action;
  const action =
    {
      ADD_SOFT_BINDING: "M1 생성",
      REUSE_EXISTING: "기존 매니페스트 재사용",
      EXISTING_OUTPUT: "등록 결과 재사용",
      EXISTING_SOURCE: "등록 원본의 결과 사용",
      RESTORED_CLASSIC: "Classic 기록 복구",
    }[mode] || "처리 미완료";
  const sourceState =
    input?.state === "NoManifest"
      ? mode === "RESTORED_CLASSIC"
        ? "입력 C2PA 없음 · DB 기록으로 복구"
        : "입력 C2PA 없음"
      : ["Trusted", "Valid"].includes(input?.state) ||
          job.source?.classic_c2pa?.validation_status === "VALID"
        ? "처리 전 서명 확인"
        : input?.state === "Invalid"
          ? "입력 C2PA 검증 실패"
          : "입력 C2PA 상태 미확인";
  const classicState = ["Trusted", "Valid"].includes(classic?.state)
    ? "Classic C2PA 서명 유효"
    : classic?.state === "Invalid"
      ? "Classic C2PA 검증 실패"
      : p.classic_validation === "SDK_VALIDATED"
        ? "서버의 Classic 검사 통과"
        : "Classic 검사 미확인";
  const pairId = r.manifest_pair_id;
  const classicBody = `${full("전체 매니페스트 ID", classicId)}${full("내장 파일", classic?.filename || r.filename)}${full("이전 출처 기록 (M0)", sourceId)}${row("이전 파일", inputName)}<section class="pq-card-section"><h4>소프트 바인딩</h4>${row("어설션", soft.label)}${row("지문 알고리즘", soft.algorithm)}${full(soft.display ? "기록된 ISCC 지문" : "기록된 지문 (Base64)", soft.display || soft.encoded)}</section>${certificate(signature)}${timestamp(r.classic_timestamp, "토큰 발급 시각이 응답에 없으면 표시하지 않습니다.")}`;
  const p1Body = `${full("전체 매니페스트 ID", p.manifest_id)}${full(ephemeral ? "샘플 임시 기록 ID" : "전체 DB 기록 쌍 ID", ephemeral ? r.sample_session_id : pairId)}${row("등록 상태", ready ? (ephemeral ? "샘플 서명·결합 검증 완료" : "DB 기록 서명·결합 검증 완료") : "외부 DB 기록 미확인")}${row(ephemeral ? "생성 시각" : "등록 시각", ephemeral ? r.created_at : r.registered_at || record?.registered_at)}${full("참조한 원본 출처 (M0)", p.source_manifest_id || r.source_manifest_id || null)}<section class="pq-card-section"><h4>소프트 바인딩</h4>${row("어설션", p.soft_binding_assertion?.label)}${row("지문 알고리즘", p.soft_binding_assertion?.algorithm)}${full("연결 지문 (Base64)", r.fingerprint_base64)}</section>${certificate(r.p1_signature_info || p.signature_info)}${timestamp(r.p1_timestamp, timestampLabel(p.timestamp) + " · 상태 값은 토큰 발급 시각이 아닙니다.")}<p class="pq-record-note">${ephemeral ? "샘플 P1은 1시간 동안 임시 보관하며 영구 DB에는 저장하지 않습니다. 지속적인 보호·복구가 필요하면 일반 파일 업로드로 등록하세요." : "P1은 결과 이미지 안에 삽입되지 않습니다. DB 기록 쌍 ID는 API의 manifest_pair_id입니다."}</p>`;
  const checkRows = [
    ["어설션 해시", p.assertion_hashes],
    ["재료 참조", p.ingredient_references],
    ["원본 근거", p.source_evidence],
    ["Classic 검사", p.classic_validation],
    ["P1 클레임 서명", p.claim_signature],
    ["하드 바인딩", p.hard_binding],
    ["소프트 바인딩", p.soft_binding],
  ]
    .map(([label, value]) =>
      row(label, value === "VALID" || value === "SDK_VALIDATED" ? "통과" : value || "미확인"),
    )
    .join("");
  // C2PA 기록이 없어 PQC 처리를 못한 경우: 제목과 안내 문장의 자리만 서로 바꿔 표시합니다.
  const manifestMissing =
    !ready &&
    (job.error?.code === "ClassicC2PANotFoundError" ||
      /C2PA Manifest를 찾지 못했습니다/.test(notice || job.error?.message || ""));
  const errorMessage = manifestMissing
    ? "PQC 보호를 확인하지 못했습니다."
    : notice || job.error?.message;
  const beforeStore = manifestStoreInfo({
    manifestStore: true,
    value: input?.store || {},
    inspectionState:
      input?.state ||
      (job.source?.classic_c2pa?.validation_status === "NOT_PRESENT" ? "NoManifest" : "Unknown"),
  });
  const currentStore = manifestStoreInfo({
    manifestStore: true,
    value: store,
    inspectionState: classic?.state,
  });
  const readableOutput =
    isOutput &&
    currentStore.count > 0 &&
    currentStore.activePresent &&
    ["Trusted", "Valid"].includes(classic?.state) &&
    (!hasBoth || same);
  const recoveryNotice =
    ready && mode === "RESTORED_CLASSIC"
      ? readableOutput
        ? `<div class="pq-recovery-notice" role="status"><strong>출처 기록 복구·재검증 완료</strong><p>${ephemeral ? "이번 시연의 임시 보호 기록에서 서명과 파일 결합을 검증한 뒤 C2PA 기록을 복구했습니다." : "소프트 바인딩으로 찾은 DB 기록의 서명과 파일 결합을 검증한 뒤, C2PA 기록을 이미지에 다시 연결했습니다."}</p><ol class="recovery-evidence" aria-label="복구 전후 검사 근거"><li><span>입력 이미지</span><strong>${beforeStore.count === null ? "기록 수 미확인" : "매니페스트 " + beforeStore.count + "개"}</strong></li><li><span>${ephemeral ? "샘플 임시 보호 기록" : "DB의 보호 기록"}</span><strong>P1 서명·파일 결합 통과</strong></li><li><span>복구된 이미지</span><strong>매니페스트 ${currentStore.count}개 확인</strong></li></ol><button type="button" class="pq-json-shortcut" data-json-jump="classic">복구된 Manifest Store JSON 보기 →</button><p>상단에서 복구본을 내려받아 다시 검사할 수 있습니다.</p></div>`
        : '<div class="pq-recovery-notice pq-recovery-pending" role="status"><strong>복구 결과 확인이 필요합니다</strong><p>서버에서 복구 응답을 받았지만 현재 이미지의 C2PA 기록을 확인하지 못했습니다. 검사 상세와 JSON을 확인하세요.</p></div>'
      : job.status === "FAILED" && ["MATCH_UNVERIFIED", "AMBIGUOUS_MATCH"].includes(job.error?.code)
        ? '<div class="pq-recovery-notice pq-recovery-failed" role="alert"><strong>보호 기록 후보를 확정하지 못했습니다</strong><p>이미지 지문으로 찾은 후보만으로는 원본이나 복구 가능성을 증명할 수 없습니다. 복구된 이미지는 제공하지 않습니다.</p></div>'
        : "";
  const recoveryPending = ready && mode === "RESTORED_CLASSIC" && !readableOutput;
  const resultTitle = recoveryPending
    ? "복구 결과 확인이 필요합니다"
    : manifestMissing
      ? "이미지에서 C2PA Manifest를 찾지 못했습니다"
      : title;
  const resultDescription = recoveryPending
    ? "서버의 복구 응답과 결과 이미지의 C2PA 검사 내용을 함께 확인하세요."
    : description;
  const buttons =
    actions === "unified"
      ? `${paused ? '<div class="v4-result-actions"><button type="button" data-unified-resume>상태 조회 재개</button></div>' : ""}`
      : actions
        ? `<div class="v4-result-actions"><button type="button" data-v4-action="download" ${ready ? "" : "disabled"}>결과 이미지 다운로드 ↓</button><button type="button" data-v4-action="inspect" ${ready ? "" : "disabled"}>결과 이미지 상세 검사</button><button type="button" data-v4-action="ai">AI 설명 생성</button></div><div class="v4-ai-text">${ai ? `<strong>AI가 작성한 설명</strong><p>${escapeHTML(ai)}</p>` : ""}${aiError ? `<p class="v4-warning">${escapeHTML(aiError)}</p>` : ""}</div>`
        : "";
  return `<section class="v4-result pq-result-surface" data-protection="${protection.kind}" aria-label="PQC 처리 결과"><div class="v4-result-heading"><span class="v4-result-icon ${ready && !recoveryPending ? "good" : "unknown"}" aria-hidden="true">${ready && !recoveryPending ? "✓" : "!"}</span><div><span class="v4-result-kicker">CONVERSION RESULT</span><h2>${escapeHTML(resultTitle)}</h2><p>${escapeHTML(resultDescription)}</p></div></div>${errorMessage ? `<p class="v4-result-notice" role="status">${escapeHTML(errorMessage)}</p>` : ""}${recoveryNotice}
  <div class="pq-summary-cards"><article><span>기존 이미지 M0</span><strong>${escapeHTML(inputName || "확인되지 않음")}</strong><small>${escapeHTML(sourceState)}</small></article><article><span>P1 양자내성 기록</span><strong>${escapeHTML(pqAlg || "양자내성 서명")}</strong><small>${ready ? "PQ 서명 유효" : "PQ 서명 미확인"}</small></article><article><span>결과 이미지</span><strong>${escapeHTML(r.filename || classic?.filename || "확인되지 않음")}</strong><small>${escapeHTML(isOutput ? classicState : p.classic_validation === "SDK_VALIDATED" ? "서버의 결과 Classic 검사 통과" : "결과 Classic 미확인")} · ${escapeHTML(action)}</small></article></div>
  <div class="pq-records-heading"><h3>출처 기록 연결</h3><span>소프트 바인딩</span></div><div class="pq-records v4-connected-records"><article class="pq-record" data-record="classic"><header><strong>${classicId ? "이미지에 내장된 Classic 기록" : "현재 이미지의 Classic 기록"}${isOutput && mode === "ADD_SOFT_BINDING" ? " (M1)" : ""}</strong>${classicId && mode !== "RESTORED_CLASSIC" ? '<button type="button" class="pq-json-shortcut" data-json-jump="classic" aria-label="현재 이미지의 Manifest Store JSON 보기">JSON 보기 →</button>' : ""}</header>${row("매니페스트 ID", short(classicId))}${row("서명 알고리즘", classicAlg)}${row("이전 출처 기록", sourceId ? short(sourceId) : inputName)}${recordDetails(classicBody)}</article>
  <div class="pq-link ${same ? "matched" : hasBoth ? "mismatch" : "unknown"}"><details><summary>${escapeHTML(linkLabel)} <span aria-hidden="true">⌄</span></summary><p>${same ? "Classic에서 읽은 지문과 서버가 반환한 P1 연결 지문이 같습니다." : hasBoth ? "두 기록의 지문이 일치하지 않습니다. 검사 상세를 확인하세요." : ready ? "서버는 소프트 바인딩 통과를 반환했습니다. 이 화면에서 양쪽 지문을 직접 대조할 정보는 부족합니다." : "기록 연결을 확인하지 못했습니다."}</p>${full("Classic 지문", soft.encoded)}${full("P1 연결 지문", r.fingerprint_base64)}</details><small>${escapeHTML(short(soft.display || r.fingerprint_base64))}</small></div>
  <article class="pq-record" data-record="p1"><header><strong>${ephemeral ? "샘플 임시 양자내성 기록 (P1)" : "DB에 저장된 양자내성 기록 (P1)"}</strong><small>${ready ? "검증 완료" : "미확인"}</small></header>${row("매니페스트 ID", short(p.manifest_id))}${row("서명 알고리즘", pqAlg)}${row(ephemeral ? "샘플 기록 ID" : "DB 기록 쌍 ID", short(ephemeral ? r.sample_session_id : pairId))}${recordDetails(p1Body)}</article></div>
  <details class="pq-verification-detail" data-section="pq-verification"><summary>서명 검증 상세 <span aria-hidden="true">⌄</span></summary><div class="pq-verification-content">${checkRows}${row("서명자 신뢰", p.signer === "FRAMEWORK_PINNED_SIGNER" ? "서버에 고정된 HAETAE 공개키" : p.signer)}${row("타임스탬프 상태", timestampLabel(p.timestamp))}${row("인증서 폐기 조회", p.revocation === "NOT_CHECKED" ? "조회하지 않음" : p.revocation)}${row("상호운용성", p.conformance === "EXPERIMENTAL_PQ_PROFILE" ? "실험용 PQ 프로파일" : p.conformance)}${code("P1 프로파일", p.profile)}${code("P1 컨테이너", p.container)}<p class="pq-record-note">Classic은 자체 CA, P1은 서버에 고정된 HAETAE 공개키로 확인합니다. 외부 공인 신뢰나 독립 구현체의 상호운용 검증을 뜻하지 않습니다.</p>${row("등록 검증 ID", r.validation_id)}${record ? '<p class="pq-record-note">기존 발급 때 저장된 기록이며 현재 요청과 구분합니다.</p>' : ""}${recordError ? `<p class="pq-record-note">${escapeHTML(recordError)}</p>` : ""}</div></details>${buttons}<p class="pq-record-note">${ready ? "Classic은 자체 CA, P1은 고정된 HAETAE 공개키로 확인한 결과입니다." : "서버에서 확인된 결과만 표시합니다."} 확인되지 않은 인증서·등록 시각은 표시하지 않습니다.</p></section>`;
}

// ============================================================================
// 04. 변환 작업 생명주기 제어
// ============================================================================

/** [작업 제어] 변환 접수·상태 조회·중지·재개를 관리한다. POST를 자동으로 반복하지 않는다. */
export function createController({
  onChange,
  onNotice,
  onInspect,
  request = apiJSON,
  delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
}) {
  let state = {
      job: null,
      record: null,
      recordError: "",
      ai: "",
      aiError: "",
      busy: false,
      paused: false,
    },
    run = 0;

  // emit: 현재 상태의 얕은 복사본을 화면 갱신 콜백에 전달한다.
  const emit = () => onChange({ ...state });

  /** [작업 조회] 현재 실행 번호가 유효한 동안 기존 변환 ID를 조회한다. 오래된 응답은 현재 작업에 덮어쓰지 않는다. */
  async function monitor(id, token) {
    while (token === run) {
      const job = readJob(await request(`/api/v1/conversions/${id}`, { cache: "no-store" }));
      if (job.conversion_id !== id) throw Error("조회한 변환 ID가 요청과 일치하지 않습니다.");
      if (token !== run) return;
      state.job = job;
      emit();
      if (job.status === "FAILED") {
        onNotice(
          `${job.error?.message || "변환에 실패했습니다."}${job.error?.code ? ` (${job.error.code})` : ""}`,
          true,
        );
        return;
      }
      if (job.status === "COMPLETED") {
        if (!canDownload(job)) {
          onNotice(
            "서버의 완료 응답에서 필수 검사 통과를 확인하지 못해 다운로드를 제공하지 않습니다.",
            true,
          );
          return;
        }
        const recordId = job.result.validation_id;
        if (recordId && vid.test(recordId)) {
          try {
            const body = await request(`/api/v1/validations/${recordId}`, { cache: "no-store" });
            if (token !== run) return;
            if (body.data?.validation_id !== recordId)
              throw Error("등록 검증 ID가 일치하지 않습니다.");
            state.record = body.data;
          } catch (e) {
            if (token !== run) return;
            state.recordError = `등록 기록을 가져오지 못했습니다: ${e.message}`;
          }
          emit();
        } else if (recordId) {
          state.recordError = "등록 검증 ID 형식이 올바르지 않습니다.";
          emit();
        }
        return;
      }
      await delay(1200);
    }
  }
  return {
    getState: () => ({ ...state }),
    /** 파일을 한 번 접수하고 받은 변환 ID의 상태를 조회한다. 자동 POST 재전송은 하지 않는다. */
    async start(file) {
      if (state.busy) return;
      const token = ++run;
      state = {
        job: null,
        record: null,
        recordError: "",
        ai: "",
        aiError: "",
        busy: true,
        paused: false,
      };
      emit();
      try {
        const form = new FormData();
        form.append("file", file, file.name);
        const body = await request("/api/v1/conversions", { method: "POST", body: form });
        const job = readJob(body);
        if (token !== run) return;
        state.job = job;
        emit();
        await monitor(job.conversion_id, token);
      } catch (e) {
        if (token === run) {
          state.paused = !!state.job && !["COMPLETED", "FAILED"].includes(state.job.status);
          onNotice(e.message, true);
        }
      } finally {
        if (token === run) {
          state.busy = false;
          emit();
        }
      }
    },
    /** 이미 접수한 작업의 GET 조회만 재개한다. 파일 업로드나 새 서명 생성을 다시 요청하지 않는다. */
    async resume() {
      if (state.busy || !state.job) return;
      const token = ++run;
      state.busy = true;
      state.paused = false;
      emit();
      try {
        await monitor(state.job.conversion_id, token);
      } catch (e) {
        if (token === run) {
          state.paused = true;
          onNotice(e.message, true);
        }
      } finally {
        if (token === run) {
          state.busy = false;
          emit();
        }
      }
    },
    /** 브라우저의 조회만 멈춘다. 서버 작업의 취소·삭제를 의미하지 않는다. */
    pause() {
      ++run;
      state.busy = false;
      state.paused = !!state.job;
      emit();
      onNotice(
        "상태 조회를 멈췄습니다. 서버의 변환 작업은 계속될 수 있습니다. 상태 조회 재개로 확인하세요.",
      );
    },
    /** 현재 작업의 검사 근거로 AI 설명을 요청하고 해당 실행 번호의 응답만 반영한다. */
    async summarize() {
      if (!state.job || state.busy) return;
      const token = run;
      state.busy = true;
      state.aiError = "";
      emit();
      try {
        const body = await request("/api/v1/ai/summaries", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            audience: "general",
            report: aiEvidence(state.job, state.record),
          }),
        });
        if (token !== run) return;
        if (typeof body.data?.summary !== "string" || !body.data.summary.trim())
          throw Error("AI가 비어 있는 설명을 반환했습니다.");
        state.ai = body.data.summary;
      } catch (e) {
        if (token === run) state.aiError = e.message;
      } finally {
        if (token === run) {
          state.busy = false;
          emit();
        }
      }
    },
    /** 다운로드 조건을 만족한 결과만 결과 이미지 검사 콜백으로 전달한다. */
    async inspect() {
      if (canDownload(state.job)) await onInspect(state.job, state.record);
    },
  };
}
