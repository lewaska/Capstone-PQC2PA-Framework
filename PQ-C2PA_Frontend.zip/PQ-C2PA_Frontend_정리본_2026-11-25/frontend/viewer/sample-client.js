/**
 * 샘플 전용 요청 어댑터. 공개 샘플도 실제 API로 처리하며 결과는 임시 보관 방식으로 요청한다.
 */
// Only bundled server samples use the non-persistent signing path.

/** [샘플 API] 기본 변환 요청 중 샘플 접수만 임시 샘플 전용 API로 바꾼다. 샘플 결과를 영구 저장하지 않는다. */
export function sampleRequest(sampleId, request) {
  if (!["absent", "present", "removed"].includes(sampleId))
    throw Error("지원하지 않는 샘플입니다.");
  return async (url, options = {}) => {
    if (url === "/api/v1/conversions" && options.method === "POST") {
      const body = await request(`/api/v1/samples/${sampleId}/conversions`, { method: "POST" });
      if (body?.data?.sample_id !== sampleId)
        throw Error("샘플 전용 API 응답을 확인하지 못했습니다. 서버 버전을 확인하세요.");
      return body;
    }
    return request(url, options);
  };
}
