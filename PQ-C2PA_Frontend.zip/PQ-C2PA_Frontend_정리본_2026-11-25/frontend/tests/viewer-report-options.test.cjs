// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
test("only submission reports receive applicant values, and switching type hides the fields", () => {
  let type = "submission";
  const nodes = new Map([["#report-meta", { hidden: false, open: true }]]);
  const $ = (s) =>
    s === "input[name=report-type]:checked"
      ? { value: type }
      : nodes.get(s) || { value: "시연 개인정보" };
  const c = vm.createContext({ $ });
  vm.runInContext(
    source.slice(
      source.indexOf("function reportOptions("),
      source.indexOf('$$("input[name=report-type]")'),
    ),
    c,
  );
  assert.equal(c.reportOptions().applicant, "시연 개인정보");
  c.syncReportMeta();
  assert.equal(nodes.get("#report-meta").hidden, false);
  type = "technical";
  c.syncReportMeta();
  assert.equal(nodes.get("#report-meta").hidden, true);
  assert.equal(nodes.get("#report-meta").open, false);
  assert.deepEqual(JSON.parse(JSON.stringify(c.reportOptions())), {
    includePreview: true,
    register: true,
  });
});
