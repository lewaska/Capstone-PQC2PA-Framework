// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
const ctx = vm.createContext({});
vm.runInContext(source.slice(0, source.indexOf("const glossary =")), ctx);
vm.runInContext(
  source.slice(source.indexOf("function pqDetails("), source.indexOf("function explanationKey(")),
  ctx,
);
vm.runInContext(
  "function activeManifest(item){return item?.store?.manifests?.[item.store.active_manifest] || {}};function conversionFor(){return null}",
  ctx,
);
vm.runInContext(
  source.slice(
    source.indexOf("function pqDisplayValue("),
    source.indexOf("function renderOverview("),
  ),
  ctx,
);
function base() {
  return {
    filename: "photo.png",
    state: "Trusted",
    pq_evidence: { present: false, status: "NOT_PRESENT" },
    store: {
      active_manifest: "urn:c2pa:classic",
      manifests: { "urn:c2pa:classic": { signature_info: { alg: "ES256" }, assertions: [] } },
    },
  };
}
test("default screen has independent collapsed classic, P1 and verification details", () => {
  const html = ctx.renderPqResult(base());
  assert.match(html, /분석 이미지/);
  assert.match(html, /현재 이미지의 C2PA 기록/);
  assert.match(html, /양자내성 기록 \(P1\)/);
  for (const id of ["pq-classic", "pq-p1", "pq-verification"])
    assert.match(html, new RegExp(`<details[^>]*data-section="${id}"`));
  assert.match(html, /외부 DB 미조회/);
  assert.match(html, /연결 여부 미확인/);
  assert.doesNotMatch(html, /같은 ISCC 지문|DB에 저장된 양자내성 기록|서명 검사 통과/);
});
test("known P1 status, real hashes and recorded fingerprint display without claiming a match", () => {
  const item = base();
  item.store.manifests["urn:c2pa:classic"].assertions = [
    { label: "c2pa.soft-binding", data: { alg: "io.iscc.v0", value_base64: "AAQ=" } },
    {
      label: "org.pq-c2pa.p1",
      data: {
        schema: "PQ-C2PA-P1-JSON-v1",
        signature_algorithm: "ML-DSA-65",
        payload: { m0_active_manifest: "urn:c2pa:source" },
      },
    },
  ];
  item.pq_evidence = {
    present: true,
    status: "VALID",
    signature_valid: true,
    payload_hash_valid: true,
    signature_algorithm: "ML-DSA-65",
    payload_sha3_256: "ab12",
    public_key_sha256: "cd34",
  };
  const html = ctx.renderPqResult(item);
  assert.match(html, /서명 검사 통과/);
  assert.match(html, /이미지 내 기록/);
  assert.match(html, /io\.iscc\.v0/);
  assert.match(html, /AAQ=/);
  assert.match(html, /urn:c2pa:source/);
  assert.match(html, /ab12/);
  assert.match(html, /cd34/);
  assert.match(html, /연결 여부 미확인/);
  assert.doesNotMatch(html, /같은 ISCC 지문/);
});
test("untrusted or missing information and unsafe metadata are not invented or injected", () => {
  const item = base();
  item.filename = "<img src=x>";
  item.state = "Error";
  item.pq_evidence = { present: false, status: "NOT_PRESENT" };
  item.store = {};
  const html = ctx.renderPqResult(item);
  assert.match(html, /&lt;img src=x&gt;/);
  assert.doesNotMatch(html, /<img src=x>/);
  assert.match(html, /검사하지 못함/);
  assert.match(html, /소프트 바인딩을 찾지 못했습니다/);
  assert.match(html, /외부 DB의 P1은 조회하지 않았습니다/);
});
