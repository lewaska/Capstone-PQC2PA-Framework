// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm");
const src = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
const c = vm.createContext({});
vm.runInContext(src.slice(0, src.indexOf("const glossary =")), c);
vm.runInContext(
  "function activeManifest(i){return i.store?.manifests?.[i.store.active_manifest]||{}}",
  c,
);
vm.runInContext(
  src.slice(src.indexOf("function pqDetails("), src.indexOf("function explanationKey(")),
  c,
);
vm.runInContext(
  src.slice(src.indexOf("function shortSvg("), src.indexOf("function publicReferences(")),
  c,
);
test("diagram separates embedded Classic from DB PQC and displays actual signature and hash evidence", () => {
  const item = {
    filename: "photo.jpg",
    state: "Invalid",
    checks: [
      { code: "assertion.dataHash.mismatch", kind: "failure", scope: "activeManifest" },
      { code: "claimSignature.validated", kind: "success", scope: "activeManifest" },
    ],
    store: {
      active_manifest: "m1",
      manifests: { m1: { signature_info: { common_name: "Known signer" } } },
    },
  };
  const m = c.structureModel(item);
  assert.equal(m.integrity.value, "확인 실패");
  assert.equal(m.signer.value, "확인됨");
  assert.equal(m.pqc.value, "PQC 상태 미확인");
  const svg = c.buildStructureSvg(item);
  assert.match(svg, /이미지에 포함된 C2PA/);
  assert.match(svg, /외부 DB의 PQC 보호 기록/);
  assert.match(svg, /점선/);
  assert.match(svg, /marker-end/);
});
test("unavailable records are not drawn as verified protection and labels are escaped", () => {
  const item = {
    filename: "<script>bad</script>.png",
    state: "NoManifest",
    store: {},
    pqc_process: { status: "UNAVAILABLE", message: "서버 미연결" },
  };
  const svg = c.buildStructureSvg(item);
  assert.match(svg, /&lt;script&gt;/);
  assert.doesNotMatch(svg, /<script>/);
  assert.match(svg, /edge dashed/);
  assert.match(svg, /PQC 확인 미완료/);
  const html = c.renderStructure(item);
  assert.match(html, /그림 크게 보기/);
  assert.match(html, /node-inspector/);
});
test("stage labels sit outside connector paths and long Korean names stay inside their nodes", () => {
  const item = {
    filename: "한강 일출 사진 원본 파일 이름이 아주 긴 경우 테스트용 이미지 2026년 11월 23일.png",
    state: "Valid",
    store: { active_manifest: "m1", manifests: { m1: {} } },
  };
  const svg = c.buildStructureSvg(item);
  const label = Number(svg.match(/<text x="32" y="(\d+)" class="stage">2\./)[1]);
  const branches = [...svg.matchAll(/<path d="M480 158 L480 (\d+) L(\d+) \1 L\2 244"/g)];
  assert.equal(branches.length, 2);
  for (const [, y] of branches)
    assert.ok(Number(y) - label >= 15, `branch ${y} too close to label ${label}`);
  const subtitle = svg.match(/data-node="file"[\s\S]*?class="node-subtitle">([^<]*)</)[1];
  assert.match(subtitle, /…$/);
  assert.ok(c.svgTextWidth(subtitle, 15) <= 440 - 36);
  assert.equal(c.fitSvgText("확인됨", 234, 15), "확인됨");
});
test("the summary tab no longer renders the recorded actions and materials section", () => {
  const detail = src.slice(
    src.indexOf("function renderDetail("),
    src.indexOf("function selectDetail("),
  );
  assert.doesNotMatch(detail, /overview-history|기록된 작업·재료 자세히 보기|renderHistory/);
  assert.match(detail, /\$\{renderOverview\(item\)\}\$\{renderStructure\(item\)\}/);
});
