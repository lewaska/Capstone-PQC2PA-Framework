// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
function harness(fetch) {
  const element = () => ({
    innerHTML: "",
    textContent: "",
    dataset: {},
    hidden: false,
    attributes: {},
    animations: [],
    setAttribute(name, value) {
      this.attributes[name] = value;
    },
    getAnimations() {
      return [];
    },
    getBoundingClientRect() {
      return { height: this.innerHTML.length / 10 };
    },
    animate(frames, options) {
      this.animations.push({ frames, options });
    },
  });
  const nodes = Object.fromEntries(
    ["output", "error", "wait"].map((name) => [`.ai-explanation-${name}`, element()]),
  );
  const buttons = ["simple", "detail"].map((mode) =>
    Object.assign(element(), { dataset: { explain: mode } }),
  );
  let shell = "";
  const panel = {
    set innerHTML(value) {
      shell = value;
    },
    get innerHTML() {
      return (
        shell +
        Object.values(nodes)
          .filter((node) => !node.hidden)
          .map((node) => node.innerHTML + node.textContent)
          .join("")
      );
    },
    querySelector(selector) {
      return shell ? nodes[selector] : null;
    },
    querySelectorAll() {
      return buttons;
    },
  };
  const motion = { reduced: false };
  const context = vm.createContext({
    document: { querySelector: () => panel },
    fetch,
    window: { matchMedia: () => ({ matches: motion.reduced }) },
    responseJSON: async (response) => response,
  });
  // Run the production state, adapter and explanation functions with only browser IO stubbed.
  vm.runInContext(source.slice(0, source.indexOf("const glossary =")), context);
  vm.runInContext(
    source.slice(source.indexOf("function counts("), source.indexOf("function sourceTypeCode(")),
    context,
  );
  vm.runInContext(
    source.slice(
      source.indexOf("function sourceTypeCode("),
      source.indexOf("function previewURL("),
    ),
    context,
  );
  vm.runInContext(
    source.slice(
      source.indexOf("function renderReadout("),
      source.indexOf("function explanationKey("),
    ),
    context,
  );
  vm.runInContext(
    source.slice(
      source.indexOf("function checksFromInspect("),
      source.indexOf("function addResult("),
    ),
    context,
  );
  vm.runInContext(
    source.slice(
      source.indexOf("function explanationKey("),
      source.indexOf("function renderActions("),
    ),
    context,
  );
  vm.runInContext("function result(){return state.results[state.active];}", context);
  const state = vm.runInContext("state", context);
  state.results.push(
    { id: "one", state: "Valid", manifest_count: 1, checks: [], trust_profile: "standard" },
    { id: "two", state: "Trusted", manifest_count: 2, checks: [], trust_profile: "lab" },
  );
  return { context, state, panel, nodes, motion };
}

test("completed results automatically request real AI once; mode clicks share the pending request", async () => {
  let finish;
  const calls = [];
  const { context, state } = harness((url, options) => {
    calls.push({ url, body: JSON.parse(options.body) });
    return new Promise((resolve) => {
      finish = resolve;
    });
  });
  const item = { ...state.results[0], id: "auto" };
  item.checks = [
    { kind: "success", scope: "activeManifest", code: "claimSignature.validated" },
    { kind: "success", scope: "activeManifest", code: "assertion.hashedURI.match" },
  ];
  vm.runInContext(
    source.slice(
      source.indexOf("function addResult("),
      source.indexOf("async function ensureAssetSha256("),
    ),
    context,
  );
  context.render = () => {};
  context.routeFromHash = () => "guide";
  state.explainMode = "detail";
  context.addResult(item);
  assert.equal(state.explainMode, "simple");
  const same = context.explainCurrent("simple");
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, "/api/v1/ai/summaries");
  assert.ok(
    calls[0].body.report.explanation_context.facts.some(
      (f) => f.code === "claimSignature.validated",
    ),
  );
  finish({ data: { summary: "실제 API 응답" } });
  await same;
  await context.scheduleAiSummary(item);
  assert.equal(calls.length, 1);
  assert.equal(state.explanations.get("auto:simple").source, "ai");
});

test("local unconfigured AI skips automatic calls while a configured server requests them", async () => {
  const calls = [],
    h = harness(async () => {
      calls.push(1);
      return { data: { summary: "서버 AI 요약" } };
    });
  vm.runInContext("aiConfigured=false", h.context);
  await h.context.scheduleAiSummary(h.state.results[0]);
  assert.equal(calls.length, 0);
  vm.runInContext("aiConfigured=true", h.context);
  await h.context.scheduleAiSummary(h.state.results[0]);
  assert.equal(calls.length, 1);
});

test("unsupported model recommendations and old cached next steps are replaced by available site actions", async () => {
  const unsupported =
    "추가 분석이 필요하다면 이미지의 편집 이력이나 비검증 영역을 별도로 확인할 수 있습니다.";
  const h = harness(async () => ({
    data: {
      explanation: {
        summary: "검사를 완료했습니다.",
        meaning: "서명 결과를 확인했습니다.",
        next_step: unsupported,
        limit: "출처 기록 검사입니다.",
        findings: [],
      },
    },
  }));
  await h.context.explainCurrent("simple");
  assert.doesNotMatch(h.panel.innerHTML, /추가 분석|비검증 영역|편집 이력/);
  assert.match(h.panel.innerHTML, /검사 상세에서 서명과 파일 결합의 검사 근거를 확인하세요/);
  h.state.explanations.get("one:simple").next_step = unsupported;
  h.context.renderAiPanel(h.state.results[0]);
  assert.doesNotMatch(h.panel.innerHTML, /비검증 영역/);
});

test("inspect adapter preserves report identity, hashes and PQ evidence in both response shapes", () => {
  const { context } = harness();
  const evidence = {
    id: "stored-id",
    created_at: "2026-11-03T00:00:00Z",
    state: "Trusted",
    sha256: "sha256",
    sha3_256: "sha3",
    pq_evidence: { status: "VALID" },
    checks: [],
    report_saved: true,
    trust_profile: "lab",
    thumbnail: "preview",
    mime: "image/jpeg",
    store: { active_manifest: "m1", manifests: { m1: {} } },
  };
  for (const raw of [evidence, { data: evidence }]) {
    const actual = context.normalizeInspectResult(
      raw,
      { name: "image.jpg", size: 100 },
      "standard",
      12,
    );
    for (const field of [
      "id",
      "created_at",
      "sha256",
      "sha3_256",
      "pq_evidence",
      "report_saved",
      "trust_profile",
      "thumbnail",
    ]) {
      assert.deepEqual(actual[field], evidence[field]);
    }
    assert.equal(actual.manifest_count, 1);
  }
});

test("late AI errors remain attached to the requested file and mode", async () => {
  let reject;
  const { context, state, panel, nodes } = harness(
    () =>
      new Promise((_, fail) => {
        reject = fail;
      }),
  );
  const pending = context.explainCurrent("detail");
  state.active = 1;
  context.renderAiPanel(state.results[1]);
  assert.equal(nodes[".ai-explanation-wait"].hidden, true);
  reject(new Error("Service unavailable"));
  await pending;
  assert.ok(!panel.innerHTML.includes("Service unavailable"));
  state.active = 0;
  context.renderAiPanel(state.results[0]);
  assert.ok(panel.innerHTML.includes("Service unavailable"));
  state.explainMode = "simple";
  context.renderAiPanel(state.results[0]);
  assert.ok(!panel.innerHTML.includes("Service unavailable"));
});

test("only explicit untrusted codes become warnings; hash, signature and unknown failures stay failures", () => {
  const { context } = harness();
  const checks = [
    { code: "signingCredential.untrusted", kind: "failure" },
    { code: "timeStamp.untrusted", kind: "informational" },
    { code: "assertion.dataHash.mismatch", kind: "failure" },
    { code: "claimSignature.mismatch", kind: "failure" },
    { code: "signingCredential.revoked", kind: "failure" },
    { code: "new.unknown.failure", kind: "failure" },
    { code: "claimSignature.validated", kind: "success" },
    { code: "signingCredential.ocsp.skipped", kind: "informational" },
  ];
  const original = JSON.stringify(checks);
  assert.deepEqual(JSON.parse(JSON.stringify(context.displayCounts({ checks }))), {
    success: 1,
    failure: 4,
    warning: 2,
    informational: 1,
  });
  assert.equal(context.checkPresentation(checks[2]).label, "실패");
  assert.equal(context.checkPresentation(checks[0]).label, "신뢰 미확인");
  assert.equal(JSON.stringify(checks), original, "SDK evidence must not be rewritten");
});

test("pending AI requests keep the answer mounted; only changed answers animate", async () => {
  let resolve;
  const { context, state, nodes } = harness(
    () =>
      new Promise((done) => {
        resolve = done;
      }),
  );
  context.renderAiPanel(state.results[0]);
  const output = nodes[".ai-explanation-output"],
    before = output.innerHTML,
    animations = output.animations.length;
  const pending = context.explainCurrent("simple");
  assert.equal(output.innerHTML, before);
  assert.equal(output.animations.length, animations);
  assert.equal(output.attributes["aria-busy"], "true");
  resolve({ data: { summary: "새롭게 생성된 답변" } });
  await pending;
  assert.ok(output.innerHTML.includes("새롭게 생성된 답변"));
  assert.ok(output.animations.length > animations);
  assert.equal(output.attributes["aria-busy"], "false");
  const after = output.animations.length;
  context.renderAiPanel(state.results[0]);
  assert.equal(output.animations.length, after, "An unchanged cached answer must not flicker");
});

test("reduced motion shows updated explanations without animation", () => {
  const { context, state, nodes, motion } = harness();
  motion.reduced = true;
  context.renderAiPanel(state.results[0]);
  assert.ok(nodes[".ai-explanation-output"].innerHTML.includes("출처 기록은 유효"));
  assert.equal(nodes[".ai-explanation-output"].animations.length, 0);
});

test("missing records never become passed checks", () => {
  const { context, panel } = harness();
  context.renderReadout({ state: "NoManifest", manifest_count: 0, checks: [] });
  assert.ok(panel.innerHTML.includes("판단 불가"));
  assert.ok(!panel.innerHTML.includes(">통과<"));
});

test("a damaged file can have a trusted signer; ingredient trust must not substitute for the current signer", () => {
  const { context, panel } = harness();
  const item = {
    state: "Invalid",
    manifest_count: 1,
    checks: [
      { code: "signingCredential.trusted", kind: "success", scope: "activeManifest" },
      { code: "assertion.dataHash.mismatch", kind: "failure", scope: "activeManifest" },
    ],
  };
  context.renderReadout(item);
  assert.ok(panel.innerHTML.includes(">실패<"));
  assert.ok(panel.innerHTML.includes(">확인<"));
  item.checks[0].scope = "ingredient";
  context.renderReadout(item);
  assert.ok(!panel.innerHTML.includes(">확인<"));
});

test("AI input prioritizes failure evidence and excludes filenames and metadata; successful results are cached", async () => {
  const requests = [];
  const { context, state, panel } = harness(async (url, options) => {
    requests.push({ url, body: JSON.parse(options.body) });
    return { data: { summary: "Verified explanation" } };
  });
  Object.assign(state.results[0], {
    filename: "private-person.jpg",
    store: { private: "not for AI" },
    pq_evidence: { status: "INVALID" },
    checks: [
      ...Array.from({ length: 25 }, () => ({ kind: "success", code: "claimSignature.validated" })),
      { kind: "failure", code: "assertion.dataHash.mismatch" },
    ],
  });
  await context.explainCurrent("detail");
  await context.explainCurrent("detail");
  assert.equal(requests.length, 1);
  const { body, url } = requests[0];
  assert.equal(url, "/api/v1/ai/summaries");
  assert.equal(body.audience, "researcher");
  assert.equal(body.report.checks[0].code, "assertion.dataHash.mismatch");
  assert.equal(body.report.checks.length, 20);
  assert.equal(body.report.trust_scope, "SDK_DEFAULT");
  assert.equal(body.report.pq_status, "INVALID");
  assert.ok(!JSON.stringify(body).includes("private"));
  assert.ok(panel.innerHTML.includes("Verified explanation"));
});

test("PQC explanation follows verification status and never treats unreadable evidence as absent", () => {
  const { context, state, nodes } = harness();
  for (const [status, expected] of [
    ["VALID", "서명 검사를 통과"],
    ["INVALID", "오류가 확인"],
    ["UNVERIFIED", "확인하지 못"],
    ["NOT_PRESENT", "조회하지 않아"],
  ]) {
    const item = {
      id: status,
      state: "Valid",
      checks: [],
      pq_evidence: { present: status !== "NOT_PRESENT", status },
    };
    assert.ok(context.pqPlain(item).includes(expected));
    state.results[0] = item;
    state.active = 0;
    context.renderAiPanel(item);
    assert.ok(nodes[".ai-explanation-output"].innerHTML.includes(expected));
  }
  assert.equal(
    context.pqDetails({ state: "Error", pq_evidence: { present: false, status: "NOT_PRESENT" } })
      .status,
    "UNVERIFIED",
  );
});

test("embedded P1 in browser is reported as unverified", () => {
  const { context } = harness();
  const item = {
    state: "Valid",
    processing_mode: "browser",
    store: {
      active_manifest: "m1",
      manifests: {
        m1: {
          assertions: [
            {
              label: "org.pq-c2pa.p1",
              data: { signature_algorithm: "ML-DSA-65", payload: { m0_active_manifest: "source" } },
            },
          ],
        },
      },
    },
  };
  const pq = context.pqDetails(item);
  assert.equal(pq.present, true);
  assert.equal(pq.status, "UNVERIFIED");
  assert.equal(pq.sourceManifest, "source");
});

test("v3-shaped inspection data preserves the asset SHA-256 without making trust assumptions", () => {
  const { context } = harness();
  const hash = "a".repeat(64);
  const result = context.normalizeInspectResult(
    {
      data: {
        asset: {
          filename: "converted.png",
          media_type: "image/png",
          size_bytes: 1234,
          sha256: hash,
        },
        classic_c2pa: { validation_status: "TRUSTED" },
      },
    },
    { name: "fallback.png", size: 100 },
    "lab",
    5,
  );
  assert.equal(result.filename, "converted.png");
  assert.equal(result.size, 1234);
  assert.equal(result.mime, "image/png");
  assert.equal(result.sha256, hash);
  assert.equal(result.state, "Unknown");
});

test("missing file hash is computed from the uploaded bytes without replacing valid server hashes", async () => {
  const c = vm.createContext({ crypto: require("node:crypto").webcrypto, Uint8Array });
  vm.runInContext(
    source.slice(
      source.indexOf("async function ensureAssetSha256("),
      source.indexOf("async function verifyFiles("),
    ),
    c,
  );
  let calls = 0;
  const file = {
    arrayBuffer: async () => {
      calls++;
      return new TextEncoder().encode("sample");
    },
  };
  const missing = {};
  await c.ensureAssetSha256(missing, file);
  assert.equal(
    missing.sha256,
    require("node:crypto").createHash("sha256").update("sample").digest("hex"),
  );
  const existing = { sha256: "a".repeat(64) };
  await c.ensureAssetSha256(existing, file);
  assert.equal(calls, 1);
  const broken = {};
  await c.ensureAssetSha256(broken, {
    arrayBuffer: async () => {
      throw Error("failed");
    },
  });
  assert.equal(broken.sha256, null);
});

test("AI is not told that external P1 is absent when only the image was inspected", async () => {
  let sent;
  const { context, state } = harness(async (_url, options) => {
    sent = JSON.parse(options.body);
    return { data: { summary: "설명" } };
  });
  state.results[0].pq_evidence = { present: false, status: "NOT_PRESENT" };
  await context.explainCurrent("simple");
  assert.equal(sent.report.pq_status, "UNKNOWN");
});
test("unified AI requests retain Classic inspection alongside the V4 evidence", async () => {
  let sent;
  const { context, state } = harness(async (_url, o) => {
    sent = JSON.parse(o.body);
    return { data: { summary: "통합 설명" } };
  });
  vm.runInContext(
    "v4Module={aiEvidence:job=>({conversion_id:job.conversion_id,status:job.status})}",
    context,
  );
  state.results[0].conversion_v4 = {
    conversion_id: "conv_" + "a".repeat(32),
    status: "COMPLETED",
    result: {
      trust_status: "TRUSTED",
      p1_validation: {
        claim_signature: "VALID",
        hard_binding: "VALID",
        soft_binding: "VALID",
        assertion_hashes: "VALID",
        ingredient_references: "VALID",
        source_evidence: "VALID",
        classic_validation: "SDK_VALIDATED",
        profile: "pq-c2pa-jumbf-haetae3-1",
        container: "JUMBF",
        signer: "FRAMEWORK_PINNED_SIGNER",
        conformance: "EXPERIMENTAL_PQ_PROFILE",
      },
    },
  };
  state.results[0].checks = [{ kind: "success", code: "claimSignature.validated" }];
  await context.explainCurrent("simple");
  assert.equal(sent.report.status, "COMPLETED");
  assert.equal(sent.report.classic_inspection.state, "Valid");
  assert.equal(sent.report.classic_inspection.checks[0].code, "claimSignature.validated");
  assert.equal(sent.report.classic_inspection.pq_status, "VALID");
});
test("external responses without server times do not invent a server inspection timestamp", () => {
  const { context } = harness();
  const item = context.normalizeInspectResult(
    { state: "NoManifest", store: {}, checks: [] },
    { name: "x.png", size: 10, type: "image/png" },
    "lab",
    321,
  );
  assert.equal(item.created_at, null);
  assert.equal(item.elapsed_ms, null);
  assert.equal(item.request_elapsed_ms, 321);
});
test("structured AI explanations show grounded sections and reuse the answer without regeneration", async () => {
  let count = 0;
  const { context, state, nodes } = harness(async () => ({
    data: {
      summary: "검사 요약",
      explanation: {
        summary: "파일은 일치하고 PQC는 미확인입니다.",
        meaning: "확인된 항목과 미확인 항목을 나눠 읽으세요.",
        next_step: "검사 상세에서 미확인 사유를 확인하세요.",
        limit: "장면의 사실 여부는 별도입니다.",
        findings: [{ fact_id: "C2PA", explanation: `C2PA 근거 해설 ${++count}` }],
      },
    },
  }));
  await context.explainCurrent("detail");
  assert.match(nodes[".ai-explanation-output"].innerHTML, /결과의 의미/);
  assert.match(nodes[".ai-explanation-output"].innerHTML, /다음에 할 일/);
  assert.match(nodes[".ai-explanation-output"].innerHTML, /C2PA 근거 해설 1/);
  await context.explainCurrent("detail");
  assert.equal(count, 1);
  assert.doesNotMatch(source, /data-explain-refresh|다시 생성/);
});
test("server connection errors are not described as image corruption, and context excludes private values", () => {
  const { context } = harness();
  const item = {
    state: "Error",
    filename: "private-name.png",
    error: "C2PA 검사 서버가 연결되지 않았습니다.",
    store: { private: "secret" },
    pqc_process: { status: "UNAVAILABLE" },
  };
  const explanation = context.localExplanation(item, "simple");
  assert.match(explanation.summary, /서버 연결/);
  assert.doesNotMatch(explanation.meaning, /파일 형식이나 손상/);
  const evidence = JSON.stringify(context.summaryContext(item));
  assert.doesNotMatch(evidence, /private-name|secret/);
  assert.match(evidence, /SERVICE_UNAVAILABLE/);
});
test("unrecognized AI evidence references and contradictory typed verdicts fall back without changing the SDK result", async () => {
  for (const data of [
    { summary: "틀린 설명", findings: [{ fact_id: "INVENTED", explanation: "없는 근거" }] },
    { summary: "틀린 판정", verdict: "Trusted" },
  ]) {
    const { context, state } = harness(async () => ({ data }));
    await context.explainCurrent("simple");
    assert.equal(state.results[0].state, "Valid");
    assert.equal(state.explanations.get("one:simple").source, "built_in");
    assert.ok(state.explainErrors.has("one:simple"));
  }
});

function restoredItem() {
  const p1 = {
    profile: "pq-c2pa-jumbf-haetae3-1",
    container: "JUMBF",
    signature_algorithm: "HAETAE-3",
    claim_signature: "VALID",
    hard_binding: "VALID",
    soft_binding: "VALID",
    assertion_hashes: "VALID",
    ingredient_references: "VALID",
    source_evidence: "VALID",
    classic_validation: "SDK_VALIDATED",
    signer: "FRAMEWORK_PINNED_SIGNER",
    conformance: "EXPERIMENTAL_PQ_PROFILE",
  };
  return {
    id: "restored",
    state: "Trusted",
    input_inspection: { state: "NoManifest", store: {} },
    store: { active_manifest: "m1", manifests: { m0: {}, m1: {} } },
    checks: [
      { kind: "success", code: "claimSignature.validated", scope: "activeManifest" },
      { kind: "success", code: "assertion.dataHash.match", scope: "activeManifest" },
    ],
    conversion_v4: {
      status: "COMPLETED",
      result: { trust_status: "TRUSTED", resolution_mode: "RESTORED_CLASSIC", p1_validation: p1 },
    },
  };
}
test("restoration explanations include observed before/after records, verified P1 checks and positive Classic evidence", () => {
  const { context } = harness(),
    item = restoredItem(),
    snapshot = JSON.stringify(item);
  const evidence = context.summaryContext(item, "detail"),
    byId = Object.fromEntries(evidence.facts.map((f) => [f.id, f]));
  assert.match(byId.INPUT_C2PA.status, /^0개/);
  assert.match(byId.MANIFEST_STORE.status, /^2개/);
  assert.equal(byId.PROCESSING.status, "C2PA 복구 · 기존 P1 재검증");
  assert.match(byId.PQC.meaning, /HAETAE-3/);
  assert.match(byId.PQC.meaning, /P1 서명 통과/);
  assert.ok(evidence.focus_fact_ids.includes("INPUT_C2PA"));
  assert.ok(evidence.focus_fact_ids.includes("MANIFEST_STORE"));
  assert.ok(
    evidence.facts.some((f) => f.code === "claimSignature.validated" && f.status === "통과"),
  );
  assert.equal(JSON.stringify(item), snapshot);
  const basic = context.summaryContext(item, "simple");
  assert.deepEqual([...basic.focus_fact_ids], ["C2PA", "PQC"]);
});
test("missing output and failed P1 checks never become successful recovery evidence; unknown record counts stay unknown", () => {
  const { context } = harness();
  for (const fault of ["unreadable", "invalid", "unverified-p1"]) {
    const item = restoredItem();
    if (fault === "unreadable") {
      item.state = "Error";
      item.store = {};
    }
    if (fault === "invalid") item.state = "Invalid";
    if (fault === "unverified-p1") delete item.conversion_v4.result.p1_validation.hard_binding;
    const facts = context.summaryContext(item, "detail").facts;
    assert.equal(facts.find((f) => f.id === "PROCESSING").status, "필수 검사 확인 미완료");
    if (fault === "unreadable")
      assert.equal(facts.find((f) => f.id === "MANIFEST_STORE").status, "기록 수 미확인");
  }
});
test("focused detail evidence prioritizes failures, deduplicates repeated checks and never includes arbitrary raw messages", () => {
  const { context } = harness(),
    item = restoredItem();
  item.checks.push({
    kind: "failure",
    scope: "activeManifest",
    code: "assertion.dataHash.mismatch",
    message: "private raw message",
    explanation: "private instruction",
  });
  item.checks.push(
    ...Array.from({ length: 20 }, () => ({
      kind: "success",
      code: "claimSignature.validated",
      scope: "activeManifest",
    })),
  );
  const evidence = context.summaryContext(item, "detail");
  assert.ok(evidence.facts.length <= 10);
  assert.ok(evidence.focus_fact_ids.length <= 6);
  const failing = evidence.facts.find((f) => f.code === "assertion.dataHash.mismatch");
  assert.ok(evidence.focus_fact_ids.includes(failing.id));
  assert.equal(evidence.facts.filter((f) => f.code === "claimSignature.validated").length, 1);
  assert.doesNotMatch(JSON.stringify(evidence), /private/);
});
test("duplicate or excessive model references fall back while retaining original checks", async () => {
  for (const findings of [
    [
      { fact_id: "C2PA", explanation: "one" },
      { fact_id: "C2PA", explanation: "two" },
    ],
    Array.from({ length: 7 }, () => ({ fact_id: "PQC", explanation: "repeat" })),
  ]) {
    const { context, state } = harness(async () => ({
      data: { explanation: { summary: "요약", findings } },
    }));
    await context.explainCurrent("detail");
    assert.equal(state.explanations.get("one:detail").source, "built_in");
    assert.equal(state.results[0].state, "Valid");
  }
});
test("the same mode button can obtain AI after a configuration failure and then reuses the successful answer", async () => {
  let calls = 0;
  const { context, state } = harness(async () => {
    if (++calls === 1) throw Error("AI 요약 서비스 설정을 확인해야 합니다.");
    return {
      data: {
        explanation: {
          summary: "서명과 파일 결합은 유효하지만 서명자 신뢰는 미확인입니다.",
          meaning: "확인한 범위에서 결과를 이용하세요.",
          next_step: "검사 상세에서 신뢰 미확인 항목을 확인하세요.",
          limit: "사진 내용의 사실 여부는 별도입니다.",
          findings: [
            { fact_id: "C2PA", explanation: "서명과 파일이 일치합니다." },
            { fact_id: "PQC", explanation: "외부 보호 기록은 확인하지 못했습니다." },
          ],
        },
      },
    };
  });
  await context.explainCurrent("simple");
  assert.equal(state.explanations.get("one:simple").source, "built_in");
  await context.explainCurrent("simple");
  assert.equal(state.explanations.get("one:simple").source, "ai");
  assert.equal(state.explainErrors.has("one:simple"), false);
  await context.explainCurrent("simple");
  assert.equal(calls, 2);
});
