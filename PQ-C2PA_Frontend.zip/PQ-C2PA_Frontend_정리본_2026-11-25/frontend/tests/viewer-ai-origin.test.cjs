// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
const ctx = vm.createContext({});
vm.runInContext(source.slice(0, source.indexOf("const glossary =")), ctx);
vm.runInContext(
  source.slice(source.indexOf("function sourceTypeCode("), source.indexOf("function previewURL(")),
  ctx,
);
function item(action, agents = []) {
  return {
    state: "Trusted",
    store: {
      active_manifest: "active",
      manifests: {
        active: {
          assertions: [
            { label: "c2pa.actions.v2", data: { softwareAgents: agents, actions: [action] } },
          ],
        },
      },
    },
  };
}
test("AI generation and attributed action tool are shown only when the record states them", () => {
  const result = ctx.aiOrigin(
    item(
      {
        action: "c2pa.created",
        digitalSourceType: "http://cv.iptc.org/newscodes/digitalsourcetype/trainedAlgorithmicMedia",
        softwareAgentIndex: 0,
      },
      [{ name: "Example Generator", version: "2" }],
    ),
  );
  assert.equal(result.toolLabel, "이미지를 만든 도구");
  assert.equal(result.kind, "created");
  assert.equal(result.tool, "Example Generator · 2");
  assert.match(result.caption, /출처 기록/);
});
test("AI edits and generative media use are not presented as fully AI-generated images", () => {
  assert.equal(
    ctx.aiOrigin(
      item({ action: "c2pa.edited", digitalSourceType: "compositedWithTrainedAlgorithmicMedia" }),
    ).kind,
    "edited",
  );
  assert.equal(
    ctx.aiOrigin(item({ action: "c2pa.placed", digitalSourceType: "trainedAlgorithmicMedia" }))
      .kind,
    "media",
  );
});
test("missing or non-AI records do not assert the image is not AI-generated", () => {
  for (const data of [
    { state: "NoManifest" },
    item({ action: "c2pa.created", digitalSourceType: "digitalCapture" }),
    item({ action: "c2pa.edited", digitalSourceType: "algorithmicallyEnhanced" }),
  ]) {
    const info = ctx.aiOrigin(data);
    assert.equal(info.kind, "unknown");
    assert.doesNotMatch(info.label, /AI로 생성하지 않았/);
  }
});
test("a manifest generator or signer is not invented as the AI generation tool", () => {
  const value = item({ action: "c2pa.created", digitalSourceType: "trainedAlgorithmicMedia" });
  value.signature = { common_name: "Claim Signer" };
  value.software = [{ name: "Claim software" }];
  const info = ctx.aiOrigin(value);
  assert.equal(info.tool, "");
  assert.match(ctx.renderAiOrigin(value), /기록되지 않음/);
  assert.match(ctx.renderAiOrigin(value), /기록 작성 도구/);
});
test("untrusted or invalid records get a warning and names are escaped", () => {
  const value = item({
    action: "c2pa.created",
    digitalSourceType: "trainedAlgorithmicMedia",
    softwareAgent: "<img src=x>",
  });
  value.state = "Invalid";
  const html = ctx.renderAiOrigin(value);
  assert.match(html, /검증에 실패/);
  assert.match(html, /&lt;img src=x&gt;/);
  assert.doesNotMatch(html, /<img src=x>/);
});

test("parentOf history recovers a recorded generation tool without confusing the current writer", () => {
  const value = item({ action: "c2pa.opened", softwareAgent: "Update writer" });
  value.store.manifests.active.ingredients = [
    { relationship: "parentOf", active_manifest: "previous" },
  ];
  value.store.manifests.previous = {
    assertions: [
      {
        label: "c2pa.actions.v2",
        data: {
          softwareAgents: [{ name: "Generator", version: "3" }],
          actions: [
            {
              action: "c2pa.created",
              digitalSourceType: "trainedAlgorithmicMedia",
              softwareAgentIndex: 0,
            },
          ],
        },
      },
    ],
  };
  const info = ctx.aiOrigin(value);
  assert.equal(info.toolLabel, "이미지를 만든 도구");
  assert.equal(info.kind, "inherited");
  assert.equal(info.tool, "Generator · 3");
  assert.match(info.caption, /이전/);
});
test("components and unrelated manifests are not attributed to the current image", () => {
  const value = item({ action: "c2pa.opened" });
  value.store.manifests.active.ingredients = [
    { relationship: "componentOf", active_manifest: "other" },
  ];
  value.store.manifests.other = {
    assertions: [
      {
        label: "c2pa.actions",
        data: {
          actions: [
            {
              action: "c2pa.created",
              digitalSourceType: "trainedAlgorithmicMedia",
              softwareAgent: "Other",
            },
          ],
        },
      },
    ],
  };
  assert.equal(ctx.aiOrigin(value).kind, "unknown");
  assert.equal(ctx.aiOrigin(value).tool, "");
});
test("history traversal handles cycles and keeps the nearest current generation separate", () => {
  const value = item({
    action: "c2pa.created",
    digitalSourceType: "trainedAlgorithmicMedia",
    softwareAgent: "Current",
  });
  value.store.manifests.active.ingredients = [
    { relationship: "parentOf", active_manifest: "previous" },
  ];
  value.store.manifests.previous = {
    ingredients: [{ relationship: "parentOf", active_manifest: "active" }],
    assertions: [
      {
        label: "c2pa.actions",
        data: {
          actions: [
            {
              action: "c2pa.created",
              digitalSourceType: "trainedAlgorithmicMedia",
              softwareAgent: "Old",
            },
          ],
        },
      },
    ],
  };
  assert.equal(ctx.aiOrigin(value).tool, "Current");
  assert.equal(ctx.aiRecordManifests(value).length, 2);
});

test("a recorded creation tool is shown as a lead without declaring AI when the source type is missing", () => {
  const value = item({ action: "c2pa.created", softwareAgent: { name: "Gemini" } });
  assert.equal(ctx.aiOrigin(value).kind, "unknown");
  assert.equal(ctx.aiOrigin(value).creationTool, "Gemini");
  const html = ctx.renderAiOrigin(value);
  assert.match(html, /이미지를 만든 도구/);
  assert.match(html, /Gemini/);
  assert.match(html, /AI 사용 여부는 확인되지 않았습니다/);
});
test("missing C2PA and unavailable inspection explain different causes", () => {
  assert.match(ctx.renderAiOrigin({ state: "NoManifest" }), /C2PA 출처 기록이 없습니다/);
  assert.match(
    ctx.renderAiOrigin({ state: "RemoteUnavailable" }),
    /출처 기록을 확인하지 못했습니다/,
  );
});
