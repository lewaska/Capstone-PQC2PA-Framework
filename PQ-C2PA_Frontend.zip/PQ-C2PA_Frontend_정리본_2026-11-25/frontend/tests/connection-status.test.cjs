// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path");
const modulePromise = import(
  "data:text/javascript;base64," +
    fs.readFileSync(path.join(__dirname, "../viewer/connection-status.js")).toString("base64")
);
test("configured, reachable and unconfigured AI states are not confused", async () => {
  const m = await modulePromise;
  assert.equal(m.aiConnection({ configured: false }).available, false);
  assert.equal(m.aiConnection({ configured: true, status: "unverified" }).available, true);
  assert.match(m.aiConnection({ configured: true, status: "unverified" }).message, /연결을 확인/);
  assert.equal(
    m.aiConnection({ configured: true, status: "reachable", ai_generation: false }).available,
    false,
  );
  assert.equal(
    m.aiConnection({ configured: true, status: "authentication_required" }).available,
    false,
  );
  assert.match(
    m.connectionText({ pqc: { status: "unverified" }, classic: { status: "reachable" } }),
    /PQC: 주소 설정됨 · 연결 미확인/,
  );
});
