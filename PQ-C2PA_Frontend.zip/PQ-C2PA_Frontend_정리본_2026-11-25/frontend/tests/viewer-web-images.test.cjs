// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
function harness(fetch) {
  const nodes = new Map(),
    selected = [];
  const $ = (name) => {
    if (!nodes.has(name))
      nodes.set(name, {
        hidden: false,
        disabled: false,
        checked: false,
        value: "",
        textContent: "",
        innerHTML: "",
        addEventListener() {},
      });
    return nodes.get(name);
  };
  const $$ = (name) => (name === "[data-page-image]:checked" ? selected : []);
  const state = { busy: false, results: [], explanations: new Map(), explainMode: "simple" };
  const context = vm.createContext({
    $,
    $$,
    state,
    fetch,
    URL,
    AbortController,
    esc: String,
    validRemote: (raw) => raw,
    clearError() {
      $("#error").hidden = true;
      $("#error").textContent = "";
    },
    setBusy: (x) => (state.busy = x),
    updateProcessingMode() {},
    responseJSON: async (response) => {
      if (response.status >= 400) throw Error(response.message || "failed");
      return response.body;
    },
    explanationKey: (item, mode) => `${item.id}:${mode}`,
    requestAiSummary: async (item) => ({ source: "ai", summary: `설명 ${item.id}` }),
    addResult: (item) => state.results.push(item),
  });
  vm.runInContext(
    source.slice(
      source.indexOf("function checksFromInspect("),
      source.indexOf("function addResult("),
    ),
    context,
  );
  vm.runInContext(
    source.slice(
      source.indexOf("const pageState ="),
      source.indexOf("async function verifySample("),
    ),
    context,
  );
  return { context, state, nodes, selected, $ };
}
test("only the first ten page images are offered, previewed and analyzable", async () => {
  const images = Array.from({ length: 25 }, (_, n) => ({ url: `https://example.com/${n}.jpg` }));
  const { context, $ } = harness(async () => ({ status: 200, body: { images } }));
  await context.discoverPageImages("https://example.com/post");
  assert.equal($("#page-image-count").textContent, "10개");
  assert.equal($("#page-candidates").hidden, false);
  assert.equal(vm.runInContext("pageState.images.length", context), 10);
  assert.match($("#page-status").textContent, /25개를 찾았습니다/);
  assert.match($("#page-status").textContent, /최대 10장/);
  const list = $("#page-image-list").innerHTML;
  assert.equal((list.match(/<img /g) || []).length, 10);
  assert.match(list, /src="https:\/\/example\.com\/0\.jpg"/);
  assert.doesNotMatch(list, /10\.jpg/);
  assert.match(list, /referrerpolicy="no-referrer"/);
  assert.match(list, /loading="lazy"/);
});
test("a server-side cap keeps the total found count in the status message", async () => {
  const images = Array.from({ length: 10 }, (_, n) => ({ url: `https://example.com/${n}.jpg` }));
  const { context, $ } = harness(async () => ({
    status: 200,
    body: { images, found_count: 14, max_images: 10 },
  }));
  await context.discoverPageImages("https://example.com/post");
  assert.equal($("#page-image-count").textContent, "10개");
  assert.match($("#page-status").textContent, /14개를 찾았습니다/);
  const small = harness(async () => ({
    status: 200,
    body: { images: images.slice(0, 3), found_count: 3 },
  }));
  await small.context.discoverPageImages("https://example.com/post");
  assert.doesNotMatch(small.$("#page-status").textContent, /최대 10장/);
});
test("invalid new page input clears stale candidates and the previous image-field error", async () => {
  let requests = 0;
  const { context, $ } = harness(async () => {
    requests++;
    return { status: 200, body: { images: [{ url: "https://example.com/old.jpg" }] } };
  });
  await context.discoverPageImages("https://example.com/old");
  $("#error").textContent = "이전 이미지 URL 오류";
  $("#error").hidden = false;
  context.validRemote = () => {
    throw Error("공개 HTTPS 주소를 입력해 주세요.");
  };
  await context.discoverPageImages("invalid");
  assert.equal(requests, 1);
  assert.equal($("#page-candidates").hidden, true);
  assert.equal(vm.runInContext("pageState.images.length", context), 0);
  assert.equal($("#error").hidden, true);
  assert.equal($("#error").textContent, "");
  assert.match($("#page-error").textContent, /HTTPS/);
  assert.equal($("#page-status").hidden, true);
});
test("a failed new discovery never leaves the old page images available to analyze", async () => {
  let requests = 0;
  const { context, $ } = harness(async () =>
    ++requests === 1
      ? { status: 200, body: { images: [{ url: "https://example.com/old.jpg" }] } }
      : { status: 400, message: "페이지 접근 실패" },
  );
  await context.discoverPageImages("https://example.com/old");
  await context.discoverPageImages("https://example.com/new");
  assert.equal($("#page-candidates").hidden, true);
  assert.equal(vm.runInContext("pageState.images.length", context), 0);
  assert.match($("#page-error").textContent, /접근 실패/);
  assert.equal($("#page-status").hidden, true);
});
test("batch retains successful results and reports oversize items without stopping other files", async () => {
  const requests = [];
  let count = 0;
  const { context, state, selected, $ } = harness(async (url, options) => {
    requests.push({ url, body: JSON.parse(options.body) });
    count++;
    return count === 2
      ? { status: 413 }
      : { status: 200, body: { id: `id${count}`, mime: "image/jpeg", state: "NoManifest" } };
  });
  vm.runInContext(
    'pageState.images=[{url:"https://example.com/1.jpg"},{url:"https://example.com/2.jpg"},{url:"https://example.com/3.jpg"}]',
    context,
  );
  selected.push(...[0, 1, 2].map((i) => ({ dataset: { pageImage: String(i) } })));
  $("#page-ai-summary").checked = true;
  $("#trust-profile").value = "lab";
  $("#private-mode").checked = true;
  await context.analyzePageImages();
  assert.equal(requests.length, 3);
  assert.equal(state.results.length, 2);
  assert.match(state.results[1].page_analysis.failures[0], /500 MB/);
  assert.equal(state.results[1].page_analysis.completed, 2);
  assert.equal(requests[0].body.save_report, false);
  assert.equal(state.explanations.get("id1:simple").source, "ai");
  assert.equal(state.explanations.get("id3:simple").source, "ai");
});
