// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");

function harness(hash = "#verify") {
  const classes = new Set(),
    elements = new Map(),
    events = {};
  const body = {
    classList: {
      contains: (n) => classes.has(n),
      add: (n) => classes.add(n),
      remove: (n) => classes.delete(n),
      toggle(n, flag) {
        flag ? classes.add(n) : classes.delete(n);
      },
    },
  };
  const $ = (key) => {
    if (!elements.has(key))
      elements.set(key, {
        hidden: true,
        dataset: {},
        classList: { toggle() {} },
        setAttribute() {},
        removeAttribute() {},
        addEventListener(name, fn) {
          (this.listeners ??= {})[name] = fn;
        },
        scrollIntoView() {},
      });
    return elements.get(key);
  };
  const links = ["verify", "guide"].map((page) => ({ ...$(page), dataset: { page } }));
  const state = {
    results: [],
    active: 0,
    detail: "checks",
    explanations: new Map(),
    localUrls: new Map(),
  };
  const location = {
    href: "http://127.0.0.1:8766/viewer/" + hash,
    pathname: "/viewer/",
    search: "",
    hash,
  };
  const window = {
    scrollY: 0,
    scrollTo({ top }) {
      this.scrollY = top;
    },
    addEventListener: (name, fn) => (events[name] = fn),
  };
  const entries = [{ url: location.href, state: null }];
  let position = 0;
  function useURL(url) {
    const parsed = new URL(url, location.href);
    Object.assign(location, {
      href: parsed.href,
      pathname: parsed.pathname,
      search: parsed.search,
      hash: parsed.hash,
    });
  }
  function move(offset) {
    if (position + offset < 0 || position + offset >= entries.length) return;
    position += offset;
    useURL(entries[position].url);
    events.popstate?.();
    events.hashchange?.();
  }
  const history = {
    get state() {
      return entries[position].state;
    },
    replaceState(s, _, url) {
      entries[position] = { state: s, url: new URL(url, location.href).href };
      useURL(url);
    },
    pushState(s, _, url) {
      entries.splice(position + 1);
      entries.push({ state: s, url: new URL(url, location.href).href });
      position++;
      useURL(url);
    },
    back: () => move(-1),
    forward: () => move(1),
  };
  const context = vm.createContext({
    $,
    $$: () => links,
    state,
    document: { body },
    window,
    history,
    location,
    params: new URLSearchParams(),
    requestAnimationFrame: (fn) => fn(),
    result: () => state.results[state.active],
  });
  vm.runInContext(
    source.slice(source.indexOf("const navigation ="), source.indexOf("const unifiedReady =")),
    context,
  );
  return { context, state, body, window, location, history, entries, links, $ };
}

test("guide round trip restores the selected image, tab, explanations and file URLs without reanalysis", () => {
  const { context, state, body, window, $ } = harness();
  state.results.push({ id: "first", sha256: "one" }, { id: "second", sha256: "two" });
  state.active = 1;
  state.explanations.set("second:simple", { summary: "기존 해설" });
  state.localUrls.set("second", "blob:existing");
  const results = state.results,
    explanations = state.explanations;
  context.rememberResultView();
  window.scrollY = 240;
  context.navigatePage("guide");
  assert.equal(body.classList.contains("show-guide"), true);
  assert.equal($("#results").hidden, true);
  context.navigatePage("verify");
  assert.equal(body.classList.contains("has-results"), true);
  assert.equal($("#results").hidden, false);
  assert.equal(state.results, results);
  assert.equal(state.active, 1);
  assert.equal(state.detail, "checks");
  assert.equal(state.explanations, explanations);
  assert.equal(state.localUrls.get("second"), "blob:existing");
  assert.equal(window.scrollY, 240);
});

test("browser back and forward restore the correct page with the existing result", () => {
  const { context, state, history, body, location } = harness();
  state.results.push({ id: "result" });
  context.rememberResultView();
  context.navigatePage("guide");
  history.back();
  assert.equal(location.hash, "#verify");
  assert.equal(body.classList.contains("has-results"), true);
  history.forward();
  assert.equal(location.hash, "#guide");
  assert.equal(body.classList.contains("show-guide"), true);
  history.back();
  assert.equal(body.classList.contains("has-results"), true);
  assert.equal(state.results.length, 1);
});

test("starting another analysis preserves old results and guide navigation keeps the intake preview", () => {
  const { context, state, body, $ } = harness();
  state.results.push({ id: "kept" });
  context.rememberResultView();
  context.navigatePage("verify", { view: "intake" });
  $("#upload-preview").hidden = false;
  assert.equal(body.classList.contains("has-results"), false);
  context.navigatePage("guide");
  context.navigatePage("verify");
  assert.equal(body.classList.contains("has-results"), false);
  assert.equal($("#upload-preview").hidden, false);
  context.navigatePage("verify", { view: "results" });
  assert.equal(body.classList.contains("has-results"), true);
  assert.equal(state.results[0].id, "kept");
});

test("results finishing while the guide is open never replace the guide page", () => {
  const { context, state, body, $ } = harness();
  context.navigatePage("guide");
  state.results.push({ id: "completed-in-background" });
  context.rememberResultView();
  assert.equal(body.classList.contains("show-guide"), true);
  assert.equal(body.classList.contains("has-results"), false);
  assert.equal($("#results").hidden, true);
  context.navigatePage("verify");
  assert.equal($("#results").hidden, false);
  assert.equal(state.results[0].id, "completed-in-background");
});

test("direct guide visits use the normal menu and repeated menu clicks do not add duplicate history", () => {
  const { context, location, entries, body } = harness("#guide");
  context.navigatePage("verify");
  assert.equal(location.hash, "#verify");
  assert.equal(entries.length, 2);
  assert.equal(body.classList.contains("has-results"), false);
  context.navigatePage("verify");
  context.navigatePage("verify");
  assert.equal(entries.length, 2);
});

test("the integrated inspection menu reopens existing results from intake without a return button", () => {
  const { context, state, history, body, links } = harness();
  state.results.push({ id: "kept" });
  context.rememberResultView();
  history.back();
  assert.equal(body.classList.contains("has-results"), false);
  links.find((link) => link.dataset.page === "verify").listeners.click({ preventDefault() {} });
  assert.equal(body.classList.contains("has-results"), true);
  assert.equal(state.results[0].id, "kept");
  history.back();
  assert.equal(body.classList.contains("has-results"), false);
  history.forward();
  assert.equal(body.classList.contains("has-results"), true);
  assert.equal(state.results.length, 1);
});

test("logo opens the top of the lobby while retaining analyzed files and their existing results", () => {
  const { context, state, body, window, history, links, $ } = harness();
  window.scrollY = 580;
  context.navigatePage("guide");
  state.results.push({ id: "first" }, { id: "second" });
  state.active = 1;
  state.explanations.set("second:simple", { summary: "기존 해설" });
  state.localUrls.set("second", "blob:kept");
  context.navigatePage("verify", { view: "results" });
  window.scrollY = 240;
  const results = state.results,
    explanations = state.explanations;
  let prevented = false;
  $(".logo").listeners.click({
    preventDefault() {
      prevented = true;
    },
  });
  assert.equal(prevented, true);
  assert.equal(body.classList.contains("has-results"), false);
  assert.equal($("#results").hidden, true);
  assert.equal(window.scrollY, 0);
  assert.equal(state.results, results);
  assert.equal(state.active, 1);
  assert.equal(state.explanations, explanations);
  assert.equal(state.localUrls.get("second"), "blob:kept");
  history.back();
  assert.equal(body.classList.contains("has-results"), true);
  assert.equal(window.scrollY, 240);
  history.forward();
  assert.equal(body.classList.contains("has-results"), false);
  assert.equal(window.scrollY, 0);
  links.find((link) => link.dataset.page === "verify").listeners.click({ preventDefault() {} });
  assert.equal(body.classList.contains("has-results"), true);
  assert.equal(state.results.length, 2);
  assert.equal(state.active, 1);
});

test("logo returns from the guide to the lobby and repeated lobby clicks reset scroll without duplicating history", () => {
  const { context, state, body, window, location, entries, $ } = harness();
  state.results.push({ id: "kept" });
  context.rememberResultView();
  context.navigatePage("guide");
  $(".logo").listeners.click({ preventDefault() {} });
  assert.equal(location.hash, "#verify");
  assert.equal(body.classList.contains("show-guide"), false);
  assert.equal(body.classList.contains("has-results"), false);
  assert.equal(window.scrollY, 0);
  $("#upload-preview").hidden = false;
  const count = entries.length;
  window.scrollY = 710;
  $(".logo").listeners.click({ preventDefault() {} });
  assert.equal(window.scrollY, 0);
  assert.equal(entries.length, count);
  assert.equal($("#upload-preview").hidden, false);
  assert.equal(state.results[0].id, "kept");
});
