// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
const conversionModule = import(
  "data:text/javascript;base64," +
    fs.readFileSync(path.join(__dirname, "../viewer/conversion-v4.js")).toString("base64")
);
function harness({ module = null, results = [] } = {}) {
  const elements = new Map();
  function $(key) {
    if (!elements.has(key))
      elements.set(key, {
        value: "",
        checked: false,
        hidden: true,
        textContent: "",
        innerHTML: "",
        classList: { add() {}, remove() {} },
        scrollIntoView() {},
      });
    return elements.get(key);
  }
  const ctx = vm.createContext({
    $,
    $$: () => [],
    state: { busy: false, results },
    v4Module: module,
    FORMAT_EXTENSIONS: new Set(["jpg", "jpeg", "png"]),
    BROWSER_MAX_SIZE: 1000000,
    SERVER_MAX_SIZE: 1000000,
    clearError() {},
    toast() {},
    sizes: (n) => String(n),
    esc: String,
    URL: { createObjectURL: () => "blob:test", revokeObjectURL() {} },
    crypto: { subtle: { digest: async (_, buffer) => buffer } },
    globalThis: null,
  });
  ctx.globalThis = ctx;
  vm.runInContext(
    source.slice(
      source.indexOf("const PREVIEW_HASH_LIMIT"),
      source.indexOf('$("#upload-preview-list").addEventListener'),
    ),
    ctx,
  );
  ctx.getItems = () => vm.runInContext("pendingState.items", ctx);
  return { ctx, $ };
}
const file = (name, byte) => ({
  name,
  size: 1,
  type: "image/png",
  arrayBuffer: async () => new Uint8Array([byte]).buffer,
});
test("successive selections append to preview and duplicate files are skipped", async () => {
  const { ctx, $ } = harness();
  await ctx.stageFiles([file("first.png", 1)]);
  await ctx.stageFiles([file("second.png", 2), file("duplicate.png", 1)]);
  const items = ctx.getItems();
  assert.equal(items.length, 3);
  assert.equal(items[0].duplicate, false);
  assert.equal(items[2].duplicate, true);
  assert.match($("#upload-preview-count").textContent, /2 \/ 3/);
  assert.equal(items[2].duplicateReason, "selection");
  assert.match($("#upload-preview-list").innerHTML, /이번 선택에 같은 사진/);
  assert.doesNotMatch($("#upload-preview-list").innerHTML, /이미 분석한 사진/);
  items.splice(0, 1);
  ctx.refreshPendingDuplicates();
  assert.equal(items[1].duplicate, false);
});

function completedResult(mode = "ADD_SOFT_BINDING") {
  return {
    sha256: "09",
    state: "Trusted",
    pqc_process: { status: "COMPLETED" },
    conversion_v4: {
      conversion_id: "conv_" + "a".repeat(32),
      status: "COMPLETED",
      result: {
        filename: "output.png",
        trust_status: "TRUSTED",
        resolution_mode: mode,
        classic_action: mode,
        manifest_pair_id: "pair_" + "b".repeat(32),
        fingerprint_base64: "AAQ=",
        p1_validation: {
          profile: "pq-c2pa-jumbf-haetae3-1",
          container: "JUMBF",
          manifest_id: "urn:c2pa:protected",
          assertion_hashes: "VALID",
          ingredient_references: "VALID",
          source_evidence: "VALID",
          classic_validation: "SDK_VALIDATED",
          claim_signature: "VALID",
          hard_binding: "VALID",
          soft_binding: "VALID",
          signer: "FRAMEWORK_PINNED_SIGNER",
          conformance: "EXPERIMENTAL_PQ_PROFILE",
        },
      },
    },
  };
}
test("Classic-only results never block a fresh PQC request for the same bytes", async () => {
  const module = await conversionModule;
  for (const state of ["Trusted", "Valid", "NoManifest", "Invalid", "Error"]) {
    const { ctx, $ } = harness({ module, results: [{ sha256: "09", state }] });
    await ctx.stageFiles([file("again.png", 9)]);
    assert.equal(ctx.getItems()[0].duplicate, false, state);
    assert.equal($("#upload-preview-start").disabled, false, state);
    assert.doesNotMatch($("#upload-preview-list").innerHTML, /이미 분석한 사진/);
  }
});
test("restored output can be reuploaded even when an older completed result has exactly the same hash", async () => {
  const module = await conversionModule,
    { ctx, $ } = harness({
      module,
      results: [completedResult("EXISTING_OUTPUT"), completedResult("RESTORED_CLASSIC")],
    });
  await ctx.stageFiles([file("restored.png", 9)]);
  assert.equal(ctx.getItems()[0].duplicate, false);
  assert.equal(ctx.getItems()[0].restored, true);
  assert.equal($("#upload-preview-start").disabled, false);
  assert.match($("#upload-preview-list").innerHTML, /복구된 이미지 · 재검사 및 PQC 처리 대상/);
  assert.doesNotMatch($("#upload-preview-list").innerHTML, /이미 분석한 사진/);
  // Reinspection has now verified this output's PQC. Only subsequent selection skips it.
  ctx.state.results.push(completedResult("EXISTING_OUTPUT"));
  ctx.refreshPendingDuplicates();
  ctx.renderPending();
  assert.equal(ctx.getItems()[0].duplicateReason, "protected");
  assert.equal($("#upload-preview-start").disabled, true);
  assert.match($("#upload-preview-list").innerHTML, /PQC 보호 완료 · 이미 분석한 사진/);
});
test("only completed PQC results with all required checks block repeat selection", async () => {
  const module = await conversionModule;
  for (const mode of ["ADD_SOFT_BINDING", "REUSE_EXISTING", "EXISTING_OUTPUT", "EXISTING_SOURCE"]) {
    const { ctx, $ } = harness({ module, results: [completedResult(mode)] });
    await ctx.stageFiles([file("protected.png", 9)]);
    assert.equal(ctx.getItems()[0].duplicateReason, "protected", mode);
    assert.equal($("#upload-preview-start").disabled, true, mode);
  }
  const changes = [
    (r) => {
      r.conversion_v4.status = "PROCESSING";
    },
    (r) => {
      r.conversion_v4.status = "FAILED";
    },
    (r) => {
      r.conversion_v4.result.p1_validation.hard_binding = "INVALID";
    },
    (r) => {
      delete r.conversion_v4.result.manifest_pair_id;
    },
    (r) => {
      r.state = "Error";
    },
    (r) => {
      r.state = "Invalid";
    },
    (r) => {
      r.pqc_process.status = "OUTPUT_UNAVAILABLE";
    },
    (r) => {
      r.conversion_v4.result.resolution_mode = "UNKNOWN";
    },
  ];
  for (const change of changes) {
    const item = completedResult();
    change(item);
    const { ctx, $ } = harness({ module, results: [item] });
    await ctx.stageFiles([file("retry.png", 9)]);
    assert.equal(ctx.getItems()[0].duplicate, false);
    assert.equal($("#upload-preview-start").disabled, false);
  }
  const sample = completedResult();
  sample.conversion_v4.sample_id = "present";
  Object.assign(sample.conversion_v4.result, {
    storage_mode: "EPHEMERAL",
    sample_session_id: "sample_" + "c".repeat(32),
    manifest_pair_id: null,
  });
  const temp = harness({ module, results: [sample] });
  await temp.ctx.stageFiles([file("sample-upload.png", 9)]);
  assert.equal(
    temp.ctx.getItems()[0].duplicate,
    false,
    "Temporary sample protection must not block permanent registration",
  );
});
test("a failed later request stays retryable and SHA-256 comparison is case insensitive", async () => {
  const module = await conversionModule,
    { ctx } = harness({
      module,
      results: [
        completedResult(),
        { sha256: "09", state: "Trusted", pqc_process: { status: "UNAVAILABLE" } },
      ],
    });
  await ctx.stageFiles([file("retry.png", 9)]);
  assert.equal(ctx.getItems()[0].duplicate, false);
  const item = completedResult();
  item.sha256 = "A1";
  const other = harness({ module, results: [item] });
  await other.ctx.stageFiles([file("protected.png", 161)]);
  assert.equal(other.ctx.getItems()[0].duplicateReason, "protected");
});
test("unsupported images are not offered for analysis and maximum remains ten per batch", async () => {
  const { ctx } = harness();
  await ctx.stageFiles([
    file("bad.webp", 1),
    ...Array.from({ length: 11 }, (_, i) => file(`${i}.png`, i)),
  ]);
  assert.equal(ctx.getItems().length, 10);
  assert.match(ctx.getItems()[0].problem, /JPG 또는 PNG/);
});
test("concurrent drops finish duplicate checks before analysis is enabled", async () => {
  const { ctx, $ } = harness();
  let resolve;
  const first = {
    ...file("first.png", 7),
    arrayBuffer: () =>
      new Promise((r) => {
        resolve = r;
      }),
  };
  const task = ctx.stageFiles([first]);
  await ctx.stageFiles([file("second.png", 7)]);
  assert.equal($("#upload-preview-start").disabled, true);
  resolve(new Uint8Array([7]).buffer);
  await task;
  assert.equal(ctx.getItems()[1].duplicate, true);
  assert.equal($("#upload-preview-start").disabled, false);
});

test("successive drops on intake add files, while results and URL mode do not start intake", () => {
  const handlers = {},
    elements = new Map(),
    calls = [];
  let showingResults = false;
  const $ = (key) => {
    if (!elements.has(key)) elements.set(key, { classList: { add() {}, remove() {} } });
    return elements.get(key);
  };
  const state = { busy: false, mode: "file", results: [{ id: "existing" }] };
  const ctx = vm.createContext({
    $,
    state,
    document: {
      body: { classList: { contains: (name) => name === "has-results" && showingResults } },
      querySelector: () => null,
    },
    window: {
      addEventListener: (name, fn) => {
        handlers[name] = fn;
      },
    },
    routeFromHash: () => "verify",
    intakeFiles: (files) => calls.push(files),
  });
  vm.runInContext(
    source.slice(
      source.indexOf("function isFileDrag("),
      source.indexOf('$("#files-toggle").onclick'),
    ),
    ctx,
  );
  let prevented = false;
  const a = file("a.png", 1),
    b = file("b.png", 2);
  const event = (files) => ({
    dataTransfer: { types: ["Files"], files },
    preventDefault() {
      prevented = true;
    },
  });
  handlers.dragover(event([a]));
  assert.equal(prevented, true);
  handlers.drop(event([a]));
  handlers.drop(event([b]));
  assert.equal(calls.length, 2);
  assert.equal(calls[0][0], a);
  assert.equal(calls[1][0], b);
  assert.equal(state.results.length, 1);
  showingResults = true;
  handlers.drop(event([a]));
  showingResults = false;
  state.mode = "url";
  handlers.drop(event([a]));
  assert.equal(calls.length, 2);
});
