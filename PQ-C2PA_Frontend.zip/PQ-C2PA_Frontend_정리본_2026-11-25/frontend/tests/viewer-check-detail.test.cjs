// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm");
const src = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
const slice = (from, to) => src.slice(src.indexOf(from), src.indexOf(to));
const modulePromise = import(
  "data:text/javascript;base64," +
    fs.readFileSync(path.join(__dirname, "../viewer/conversion-v4.js")).toString("base64")
);
async function context() {
  const c = vm.createContext({});
  vm.runInContext(src.slice(0, src.indexOf("const glossary =")), c);
  vm.runInContext(slice("const glossary =", "let activeTerm = null"), c);
  vm.runInContext(slice("function checkPresentation(", "function sourceTypeCode("), c);
  vm.runInContext(slice("function renderSummary(", "function renderBatch("), c);
  vm.runInContext(slice("// 서명·검증 환경과 파일 정보는", "function renderJsonTree("), c);
  vm.runInContext(slice("function renderJsonTree(", "function renderHistory("), c);
  vm.runInContext(slice("function renderManifest(", "function shortSvg("), c);
  vm.runInContext(slice("function publicReferences(", "function renderDetail("), c);
  vm.runInContext(
    'function activeManifest(i){return i.store?.manifests?.[i.store.active_manifest]||{}};function aiOrigin(){return {kind:"unknown",label:"확인할 선언 없음"}}',
    c,
  );
  c.__module = await modulePromise;
  vm.runInContext("v4Module=__module", c);
  return c;
}
function item() {
  return {
    filename: "photo.png",
    mime: "image/png",
    size: 2048,
    sha256: "a".repeat(64),
    state: "Valid",
    trust_profile: "lab",
    signature: { common_name: "Classic signer", issuer: "Lab CA", alg: "ES256" },
    checks: [
      { code: "signingCredential.untrusted", kind: "failure", scope: "activeManifest" },
      {
        code: "assertion.dataHash.match",
        kind: "success",
        scope: "activeManifest",
        explanation: "data hash valid",
      },
      {
        code: "claimSignature.validated",
        kind: "success",
        scope: "activeManifest",
        url: "self#jumbf=/c2pa/m1",
      },
    ],
    store: {
      active_manifest: "m1",
      manifests: {
        m1: {
          signature_info: { common_name: "Classic signer", issuer: "Lab CA", alg: "ES256" },
          assertions: [],
        },
      },
    },
    pqc_process: { status: "FAILED", message: "이미지에서 C2PA Manifest를 찾지 못했습니다." },
  };
}
const rowOf = (html, title) =>
  html
    .split('<article class="check ')
    .find((part) => part.includes(`<strong>${title}</strong>`))
    ?.split("</article>")[0] || "";

test("original check wording is restored and repeated matching references share one card without losing raw evidence", async () => {
  const c = await context(),
    value = item();
  value.checks = ["c2pa.icon", "c2pa.actions.v2", "c2pa.hash.data"].map((label) => ({
    code: "assertion.hashedURI.match",
    kind: "success",
    scope: "activeManifest",
    url: `self#jumbf=/c2pa/m1/c2pa.assertions/${label}`,
  }));
  const before = JSON.stringify(value.checks),
    html = c.renderCheckDetail(value);
  assert.equal((html.match(/<strong>출처 기록 간 연결 확인<\/strong>/g) || []).length, 1);
  assert.match(html, /출처 기록이 참조하는 데이터의 해시값이 일치합니다\./);
  assert.doesNotMatch(html, /동일한 검사 결과|check-group-count/);
  assert.doesNotMatch(html, /check-context|핑거프린트 기록의 무결성 확인|아이콘의 무결성 확인/);
  assert.equal(c.displayCounts(value).success, 3);
  assert.equal(JSON.stringify(value.checks), before);
});

test("failed checks and different explanations are never merged into passing results", async () => {
  const c = await context(),
    value = item();
  value.checks = [
    { code: "assertion.hashedURI.match", kind: "success", scope: "activeManifest" },
    { code: "assertion.hashedURI.match", kind: "success", scope: "activeManifest" },
    { code: "assertion.hashedURI.mismatch", kind: "failure", scope: "activeManifest" },
    { code: "custom.failure", kind: "failure", explanation: "첫 번째 실패 원인" },
    { code: "custom.failure", kind: "failure", explanation: "다른 실패 원인" },
  ];
  let html = c.renderCheckDetail(value);
  assert.equal((html.match(/<article class="check success">/g) || []).length, 1);
  assert.equal((html.match(/<article class="check failure">/g) || []).length, 3);
  assert.match(html, /첫 번째 실패 원인/);
  assert.match(html, /다른 실패 원인/);
  vm.runInContext("state.checkFilter='failure'", c);
  html = c.renderCheckDetail(value);
  assert.doesNotMatch(html, /<article class="check success">/);
  assert.equal(c.displayCounts(value).failure, 3);
});
test("check rows no longer expose raw SDK code blocks", async () => {
  const c = await context(),
    html = c.renderCheckDetail(item());
  assert.doesNotMatch(html, /원본 검사 코드|check-code|SDK 분류|self#jumbf/);
  assert.doesNotMatch(html, /SDK 원본 분류는 각 항목에서/);
});
test("signature environment sits in the signer-trust row and file info in the file-binding row", async () => {
  const c = await context(),
    html = c.renderCheckDetail(item());
  const signer = rowOf(html, "서명자 신뢰 확인"),
    binding = rowOf(html, "파일과 출처 기록의 일치 확인"),
    signature = rowOf(html, "출처 기록의 서명 검증");
  assert.match(signer, /data-section="technical"><summary>서명·검증 환경<\/summary>/);
  assert.match(signer, /Classic signer/);
  assert.match(binding, /data-section="file"><summary>파일 정보<\/summary>/);
  assert.match(binding, /photo\.png/);
  assert.match(binding, /a{64}/);
  assert.doesNotMatch(signature, /data-section=/);
  assert.equal((html.match(/data-section="technical"/g) || []).length, 1);
  assert.equal((html.match(/data-section="file"/g) || []).length, 1);
});
test("the PQC-tab JSON inspector replaces the old raw manifest folder directly below the check evidence", async () => {
  const c = await context(),
    html = c.renderCheckDetail(item());
  assert.doesNotMatch(html, /원본 출처 기록 · JSON|manifest-select/);
  assert.match(html, /검사 데이터 · JSON/);
  assert.match(html, /data-json-source/);
  assert.match(html, /PQC 처리 응답/);
  assert.ok(html.indexOf('class="check-rows"') < html.indexOf('class="result-json"'));
  assert.doesNotMatch(html, /data-section="anchors"|시간 정보·공개 참조/);
});
test("folders fall back below the list when no matching check exists, and no PQC response is invented", async () => {
  const c = await context(),
    value = { ...item(), state: "NoManifest", checks: [], store: {} };
  delete value.pqc_process;
  const html = c.renderCheckDetail(value);
  assert.match(html, /<div class="evidence-folders"><details data-section="technical">/);
  assert.match(html, /data-section="file"/);
  assert.match(html, /검사 데이터 · JSON/);
  assert.doesNotMatch(html, /PQC 처리 응답/);
  const ingredientOnly = {
    ...item(),
    checks: [{ code: "signingCredential.trusted", kind: "success", scope: "ingredient" }],
  };
  assert.doesNotMatch(
    rowOf(c.renderCheckDetail(ingredientOnly), "서명자 신뢰 확인"),
    /data-section="technical"/,
  );
});
