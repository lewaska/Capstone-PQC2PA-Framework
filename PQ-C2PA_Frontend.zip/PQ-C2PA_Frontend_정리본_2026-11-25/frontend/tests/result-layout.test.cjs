// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path");
const modulePromise = import(
  "data:text/javascript;base64," +
    fs.readFileSync(path.join(__dirname, "../viewer/conversion-v4.js")).toString("base64")
);
function fixture() {
  const fingerprint = "QUJDRA==",
    classicId = "urn:c2pa:classic-example";
  return {
    job: {
      conversion_id: "conv_" + "a".repeat(32),
      status: "COMPLETED",
      source: { filename: "input.png", classic_c2pa: { validation_status: "VALID" } },
      result: {
        filename: "output.png",
        trust_status: "TRUSTED",
        classic_action: "ADD_SOFT_BINDING",
        manifest_pair_id: "pair_" + "b".repeat(32),
        fingerprint_base64: fingerprint,
        p1_signature_info: { common_name: "P1 signer from API", issuer: "P1 issuer from API" },
        p1_validation: {
          profile: "pq-c2pa-jumbf-haetae3-1",
          container: "JUMBF",
          manifest_id: "urn:c2pa:p1-example",
          signature_algorithm: "HAETAE-3",
          assertion_hashes: "VALID",
          ingredient_references: "VALID",
          source_evidence: "VALID",
          classic_validation: "SDK_VALIDATED",
          claim_signature: "VALID",
          hard_binding: "VALID",
          soft_binding: "VALID",
          signer: "FRAMEWORK_PINNED_SIGNER",
          timestamp: "M0_TOKEN_EXISTING",
          revocation: "NOT_CHECKED",
          conformance: "EXPERIMENTAL_PQ_PROFILE",
        },
      },
    },
    classic: {
      filename: "output.png",
      state: "Trusted",
      store: {
        active_manifest: classicId,
        manifests: {
          [classicId]: {
            signature_info: {
              alg: "ES256",
              common_name: "Classic signer from SDK",
              issuer: "Classic issuer from SDK",
            },
            ingredients: [
              {
                relationship: "parentOf",
                active_manifest: "urn:c2pa:source-example",
                title: "input.png",
              },
            ],
            assertions: [
              {
                label: "c2pa.soft-binding",
                data: {
                  alg: "io.iscc.v0",
                  display: "ISCC:EXAMPLE-ONLY",
                  value_base64: fingerprint,
                },
              },
            ],
          },
        },
      },
    },
    input: {
      filename: "input.png",
      state: "Valid",
      store: { active_manifest: "urn:c2pa:source-example" },
    },
  };
}
module.exports = { fixture };
test("reference layout uses real Classic metadata and independently folded cards connected by the observed matching fingerprint", async () => {
  const m = await modulePromise,
    { job, classic, input } = fixture(),
    html = m.renderResult(job, { classic, input, actions: "unified" });
  assert.match(html, /PQC 보호 기록을 자동으로 생성했습니다/);
  assert.match(html, /같은 ISCC 지문/);
  assert.match(html, /urn:c2pa:classic-example/);
  assert.match(html, /Classic signer from SDK/);
  assert.match(html, /P1 signer from API/);
  assert.match(html, /HAETAE-3/);
  assert.equal((html.match(/class="pq-record-detail"/g) || []).length, 2);
  assert.doesNotMatch(html, /<details[^>]* open/);
  assert.doesNotMatch(
    html,
    /data-unified-report|data-unified-download|result-json|data-json-source/,
  );
});
test("missing and mismatched fingerprints never claim an observed match, and missing certificate/times stay unavailable", async () => {
  const m = await modulePromise,
    { job, classic, input } = fixture();
  classic.store.manifests[classic.store.active_manifest].assertions = [];
  delete job.result.p1_signature_info;
  let html = m.renderResult(job, { classic, input });
  assert.doesNotMatch(html, /같은 ISCC 지문/);
  assert.doesNotMatch(html, /P1 signer from API/);
  assert.match(html, /등록 시각/);
  assert.match(html, /정보 없음/);
  classic.store.manifests[classic.store.active_manifest].assertions = [
    { label: "c2pa.soft-binding", data: { alg: "io.iscc.v0", value_base64: "OTHER" } },
  ];
  html = m.renderResult(job, { classic, input });
  assert.match(html, /지문 불일치/);
  assert.doesNotMatch(html, /같은 ISCC 지문/);
});
test("recovered, converted and protected downloads use the same verified asset contract with clear labels", async () => {
  const m = await modulePromise,
    { job } = fixture();
  assert.equal(m.imageDownloadInfo(job).label, "PQC 변환 이미지 다운로드");
  job.result.resolution_mode = "RESTORED_CLASSIC";
  assert.equal(m.imageDownloadInfo(job).label, "복구된 이미지 다운로드");
  assert.equal(m.imageDownloadInfo(job).enabled, true);
  assert.match(
    m.renderResult(job, { input: { state: "NoManifest" } }),
    /입력 C2PA 없음 · DB 기록으로 복구/,
  );
  job.result.resolution_mode = "EXISTING_OUTPUT";
  assert.equal(m.imageDownloadInfo(job).label, "PQC 보호 이미지 다운로드");
  job.result.p1_validation.hard_binding = "INVALID";
  assert.equal(m.imageDownloadInfo(job).enabled, false);
});
test("URL-only inspection is not displayed as a failed PQC conversion or fabricated record connection", async () => {
  const m = await modulePromise;
  const job = {
    status: "SKIPPED",
    source: { filename: "club-01.webp" },
    error: { message: "URL에서는 C2PA만 검사했습니다." },
  };
  const html = m.renderResult(job, {
    classic: { filename: "club-01.webp", state: "NoManifest" },
    actions: "unified",
  });
  assert.match(html, /PQC 처리를 실행하지 않았습니다/);
  assert.match(html, /C2PA 기록 없음/);
  assert.match(html, /URL에서는 C2PA만 검사했습니다/);
  assert.match(html, /P1 DB 조회/);
  assert.doesNotMatch(
    html,
    /PQC 보호를 확인하지 못했습니다|필수 검사를 통과하지|data-unified-download|data-record="p1"/,
  );
  assert.doesNotMatch(html, /data-unified-report|result-json|data-json-source/);
  assert.equal(m.canDownload(job), false);
  const invalid = m.renderResult(job, { classic: { state: "Invalid" } });
  assert.match(invalid, /C2PA 검증 실패/);
});
test("missing C2PA Manifest swaps only the heading and notice texts", async () => {
  const m = await modulePromise,
    original = m.renderResult(
      {
        conversion_id: "conv_" + "b".repeat(32),
        status: "FAILED",
        source: { filename: "x.png" },
        result: null,
        error: { code: "OTHER", message: "다른 오류" },
      },
      { notice: "다른 오류 (OTHER)", actions: "unified" },
    );
  const failed = {
    conversion_id: "conv_" + "a".repeat(32),
    status: "FAILED",
    source: { filename: "plain.png" },
    result: null,
    error: {
      code: "ClassicC2PANotFoundError",
      message: "이미지에서 C2PA Manifest를 찾지 못했습니다.",
    },
  };
  const html = m.renderResult(failed, {
    notice: "이미지에서 C2PA Manifest를 찾지 못했습니다. (ClassicC2PANotFoundError)",
    actions: "unified",
  });
  assert.match(html, /<h2>이미지에서 C2PA Manifest를 찾지 못했습니다<\/h2>/);
  assert.match(
    html,
    /<p class="v4-result-notice" role="status">PQC 보호를 확인하지 못했습니다\.<\/p>/,
  );
  assert.doesNotMatch(html, /<h2>PQC 보호를 확인하지 못했습니다/);
  assert.doesNotMatch(html, /v4-result-notice[^>]*>이미지에서/);
  const unavailable = m.renderResult(
    {
      status: "UNAVAILABLE",
      source: { filename: "plain.png" },
      error: { message: "이미지에서 C2PA Manifest를 찾지 못했습니다." },
    },
    { notice: "이미지에서 C2PA Manifest를 찾지 못했습니다." },
  );
  assert.match(unavailable, /<h2>이미지에서 C2PA Manifest를 찾지 못했습니다<\/h2>/);
  // Same markup and classes as any other failed result: only the texts change places.
  const shape = (value) => value.replace(renderedJson(value), "").replace(/>[^<]*</g, "><");
  assert.equal(shape(html), shape(original));
  assert.match(original, /<h2>PQC 보호를 확인하지 못했습니다<\/h2>/);
  assert.match(original, /v4-result-notice[^>]*>다른 오류 \(OTHER\)/);
});
function renderedJson(html) {
  const at = html.indexOf('<section class="result-json"');
  return at < 0 ? "" : html.slice(at, html.indexOf("</section>", at) + 10);
}
test("HAETAE-3 backend: pinned public key, block soft-binding value, recovery and unresolved-candidate notices", async () => {
  const m = await modulePromise,
    { job, classic, input } = fixture();
  delete job.result.p1_signature_info;
  job.result.p1_validation.signature_info = {
    alg: "HAETAE-3",
    common_name: "PQ-C2PA HAETAE-3 Signer",
    issuer: "Local pinned public key (not an X.509 certificate)",
    key_reference: "haetae3:sha256:" + "c".repeat(64),
  };
  job.result.p1_validation.source_manifest_id = "urn:c2pa:m0-from-p1";
  let html = m.renderResult(job, { classic, input });
  assert.match(html, /서명 공개키/);
  assert.match(html, /haetae3:sha256:c{64}/);
  assert.match(html, /urn:c2pa:m0-from-p1/);
  assert.match(html, /서버에 고정된 HAETAE 공개키/);
  classic.store.manifests[classic.store.active_manifest].assertions = [
    { label: "c2pa.soft-binding", data: { alg: "io.iscc.v0", blocks: [{ value: "QUJDRA==" }] } },
  ];
  html = m.renderResult(job, { classic, input });
  assert.match(html, /같은 ISCC 지문/);
  job.result.resolution_mode = "RESTORED_CLASSIC";
  html = m.renderResult(job, { classic, input: { state: "NoManifest" } });
  assert.match(html, /출처 기록 복구·재검증 완료/);
  assert.match(html, /입력 C2PA 없음 · DB 기록으로 복구/);
  job.result.resolution_mode = "EXISTING_OUTPUT";
  assert.match(m.renderResult(job, { input: { state: "NoManifest" } }), /입력 C2PA 없음</);
  const failed = {
    conversion_id: job.conversion_id,
    status: "FAILED",
    source: { filename: "input.png" },
    result: null,
    error: { code: "AMBIGUOUS_MATCH", message: "후보가 여러 개입니다" },
  };
  html = m.renderResult(failed, {});
  assert.match(html, /보호 기록 후보를 확정하지 못했습니다/);
  assert.doesNotMatch(html, /data-unified-download(?![^>]*disabled)/);
  job.result.p1_validation.profile = "pq-c2pa-jumbf-1";
  assert.throws(() => m.readJob({ data: job }), /HAETAE-3/);
  assert.equal(m.canDownload(job), false);
});
test("PQC result omits the JSON panel while the separate inspector and top download actions remain", async () => {
  const m = await modulePromise,
    { job, classic, input } = fixture();
  job.error = { message: "</code><script>alert(1)</script>" };
  const record = { validation_id: "val_" + "a".repeat(32), checks: [] },
    html = m.renderResult(job, { classic, input, record, actions: "unified" });
  assert.doesNotMatch(
    html,
    /data-unified-download|data-unified-report|<script>|result-json|data-json-source/,
  );
  assert.match(html, /&lt;script&gt;/);
  const json = m.renderJsonInspector(job, { classic, input, record });
  assert.match(json, /result-json-code/);
  assert.match(json, /JSON 검색/);
  assert.match(json, /전체 복사/);
  const sources = m.jsonSources(job, { classic, input, record });
  assert.deepEqual(
    sources.map((s) => s.id),
    ["classic", "pqc", "registration", "input-store", "input"],
  );
  assert.equal(sources[1].value, job);
  assert.equal(sources[2].value, record);
  assert.equal(sources[3].value, input.store);
  assert.equal(sources[4].value, input);
  const index = fs.readFileSync(path.join(__dirname, "../viewer/index.html"), "utf8");
  assert.equal((index.match(/id="download-result-image"/g) || []).length, 1);
  assert.equal((index.match(/id="download-pdf"/g) || []).length, 1);
});
test("Manifest Store readout distinguishes missing records from an incomplete inspection without altering source JSON", async () => {
  const m = await modulePromise,
    { job, classic } = fixture(),
    before = JSON.stringify(classic.store);
  classic.store.manifests["urn:c2pa:previous"] = { title: "original.png" };
  const snapshot = JSON.stringify(classic.store),
    current = m.jsonSources(job, { classic })[0];
  assert.deepEqual(m.manifestStoreInfo(current), {
    count: 2,
    active: classic.store.active_manifest,
    state: "Trusted",
    activePresent: true,
  });
  assert.match(m.renderManifestReadout(current), /2개/);
  assert.match(m.renderManifestReadout(current), /urn:c2pa:classic-example/);
  assert.equal(JSON.stringify(classic.store), snapshot);
  assert.notEqual(snapshot, before);
  assert.equal(
    m.manifestStoreInfo({ manifestStore: true, value: {}, inspectionState: "NoManifest" }).count,
    0,
  );
  assert.equal(
    m.manifestStoreInfo({ manifestStore: true, value: {}, inspectionState: "Error" }).count,
    null,
  );
  assert.match(
    m.renderManifestReadout({ manifestStore: true, value: {}, inspectionState: "Error" }),
    /검사 미완료/,
  );
  assert.equal(m.renderManifestReadout(m.jsonSources(job, { classic })[1]), "");
  const broken = {
    manifestStore: true,
    value: { active_manifest: "<img src=x>", manifests: {} },
    inspectionState: "Invalid",
  };
  assert.equal(m.manifestStoreInfo(broken).activePresent, false);
  assert.match(m.renderManifestReadout(broken), /대응하는 매니페스트를 읽지 못했습니다/);
  assert.doesNotMatch(m.renderManifestReadout(broken), /<img/);
});
test("recovery proof shows actual before/after counts only after readable valid output and verified P1", async () => {
  const m = await modulePromise,
    { job, classic } = fixture();
  job.result.resolution_mode = "RESTORED_CLASSIC";
  classic.store.manifests["urn:c2pa:previous"] = { title: "original.png" };
  const input = { state: "NoManifest", store: {} },
    html = m.renderResult(job, { classic, input, actions: "unified" });
  assert.match(html, /출처 기록 복구·재검증 완료/);
  assert.match(html, /매니페스트 0개/);
  assert.match(html, /매니페스트 2개 확인/);
  assert.match(html, /data-json-jump="classic">복구된 Manifest Store JSON 보기/);
  assert.equal((html.match(/data-json-jump=/g) || []).length, 1);
  const sources = m.jsonSources(job, { classic, input });
  assert.equal(sources.find((s) => s.id === "classic").value, classic.store);
  assert.equal(sources.find((s) => s.id === "input-store").value, input.store);
  for (const invalid of [
    null,
    { state: "Error", store: {} },
    { ...classic, state: "Invalid" },
    { ...classic, store: { active_manifest: "unreadable", manifests: classic.store.manifests } },
  ]) {
    const pending = m.renderResult(job, { classic: invalid, input });
    assert.match(pending, /복구 결과 확인이 필요합니다/);
    assert.doesNotMatch(
      pending,
      /출처 기록 복구·재검증 완료|class="recovery-evidence"|v4-result-icon good/,
    );
  }
  assert.doesNotMatch(
    m.renderResult(job, { classic, input, isOutput: false }),
    /출처 기록 복구·재검증 완료/,
  );
  job.result.fingerprint_base64 = "MISMATCH";
  assert.doesNotMatch(m.renderResult(job, { classic, input }), /출처 기록 복구·재검증 완료/);
  job.result.p1_validation.hard_binding = "INVALID";
  assert.doesNotMatch(
    m.renderResult(job, { classic, input }),
    /출처 기록 복구·재검증 완료|class="recovery-evidence"/,
  );
});
test("recovery cannot invent an input count when the input inspection failed", async () => {
  const m = await modulePromise,
    { job, classic } = fixture();
  job.result.resolution_mode = "RESTORED_CLASSIC";
  const html = m.renderResult(job, { classic, input: { state: "Error" } });
  assert.match(html, /기록 수 미확인/);
  assert.doesNotMatch(html, /매니페스트 0개/);
});
test("JSON shortcut clears stale search, selects current store and respects reduced motion without inspecting again", () => {
  const vm = require("node:vm"),
    source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
  const body = source.slice(
    source.indexOf("function showManifestJSON("),
    source.indexOf('$("#detail-panel").oninput ='),
  );
  for (const reduced of [true, false]) {
    const select = {
        value: "pqc",
        options: [{ value: "classic" }, { value: "input-store" }, { value: "pqc" }],
      },
      search = { value: "old search" },
      calls = [];
    const panel = {
      querySelector: (key) =>
        ({
          "[data-json-source]": select,
          "[data-json-search]": search,
          ".result-json-code": { focus: (options) => calls.push(["focus", options.preventScroll]) },
        })[key],
      scrollIntoView: (options) => calls.push(["scroll", options.behavior, options.block]),
    };
    const state = { detail: "summary" },
      context = vm.createContext({
        state,
        $: () => panel,
        selectDetail: (detail) => {
          state.detail = detail;
          calls.push(["tab", detail]);
        },
        updateResultJSON: (p) => {
          assert.equal(p, panel);
          calls.push(["update", select.value, search.value]);
        },
        window: {
          matchMedia: (query) => {
            assert.equal(query, "(prefers-reduced-motion: reduce)");
            return { matches: reduced };
          },
        },
      });
    vm.runInContext(body, context);
    context.showManifestJSON();
    assert.equal(select.value, "classic");
    assert.equal(search.value, "");
    assert.equal(state.detail, "checks");
    assert.deepEqual(calls, [
      ["tab", "checks"],
      ["update", "classic", ""],
      ["scroll", reduced ? "auto" : "smooth", "start"],
      ["focus", true],
    ]);
  }
});
