// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm");
const source = fs
  .readFileSync(path.join(__dirname, "../viewer/pdf-report.js"), "utf8")
  .replace(/^import .*;$/gm, "")
  .replace(/^export \{.*\};$/gm, "")
  .replace(/^export /gm, "");
function context() {
  const pages = [];
  const document = {
    createElement() {
      const drawn = [],
        ctx = {
          font: "18px sans",
          scale() {},
          setTransform() {},
          fillRect() {},
          save() {},
          restore() {},
          drawImage() {},
          fillText(text, x, y) {
            drawn.push({ text, x, y });
          },
          measureText(text) {
            const size = Number(/([\d.]+)px/.exec(this.font)?.[1] || 18);
            return {
              width: [...String(text)].reduce(
                (n, c) => n + size * (c.charCodeAt(0) > 255 ? 1 : 0.61),
                0,
              ),
            };
          },
        };
      const canvas = { getContext: () => ctx, drawn };
      pages.push(canvas);
      return canvas;
    },
  };
  const c = vm.createContext({ document });
  vm.runInContext(source, c);
  return { c, pages };
}
function item() {
  const long = "긴 한글 항목 및 경로 ".repeat(100);
  return {
    filename: long,
    mime: "image/png",
    size: 200000,
    sha256: "a".repeat(64),
    sha3_256: "b".repeat(64),
    state: "Invalid",
    trust_profile: "lab",
    checks: Array.from({ length: 500 }, (_, i) => ({
      kind: i < 40 ? "failure" : "success",
      code: `test.code.${i}`,
      scope: "activeManifest",
      explanation: long,
    })),
    signature: {
      common_name: long,
      issuer: long,
      alg: "es256",
      cert_serial_number: long,
      time: "2026-11-20T00:00:00.123Z",
    },
    software: [{ name: long }],
    store: {
      active_manifest: "urn:c2pa:example",
      manifests: {
        "urn:c2pa:example": {
          assertions: [{ label: "c2pa.hash.data", data: { alg: "sha256", hash: "c".repeat(64) } }],
        },
      },
    },
    input_inspection: {
      verification_timing: {
        started_at: "2026-11-20T00:00:00.123Z",
        completed_at: "2026-11-20T00:00:01.456Z",
      },
    },
    verification_timing: {
      started_at: "2026-11-20T00:00:02.123Z",
      completed_at: "2026-11-20T00:00:03.456Z",
    },
    verification_run: {
      started_at: "2026-11-20T00:00:00.123Z",
      completed_at: "2026-11-20T00:00:04.456Z",
      events: Array.from({ length: 100 }, (_, i) => ({
        at: "2026-11-20T00:00:01.123Z",
        code: `ERROR_${i}`,
        message: long,
      })),
    },
    actions: Array.from({ length: 100 }, () => ({ action: "c2pa.created", softwareAgent: long })),
    conversion_v4: {
      status: "COMPLETED",
      result: {
        resolution_mode: "RESTORED_CLASSIC",
        trust_status: "TRUSTED",
        manifest_pair_id: "pair_" + "a".repeat(32),
        fingerprint_base64: "x".repeat(400),
        p1_validation: {
          manifest_id: "urn:c2pa:1234",
          profile: "pq-c2pa-jumbf-haetae3-1",
          container: "JUMBF",
          signature_algorithm: "HAETAE-3",
          assertion_hashes: "VALID",
          ingredient_references: "VALID",
          source_evidence: "VALID",
          classic_validation: "SDK_VALIDATED",
          claim_signature: "VALID",
          hard_binding: "VALID",
          soft_binding: "VALID",
          signer: "FRAMEWORK_PINNED_SIGNER",
          conformance: "EXPERIMENTAL_PQ_PROFILE",
          timestamp: "M0_TOKEN_EXISTING",
        },
      },
    },
  };
}
function meta() {
  return {
    docNo: "PQC-TEC-test",
    kind: "상세분석",
    issuedText: "2026-11-21 12:00:00 (UTC+09:00), 서버 발급",
    issuance: {
      doc_no: "PQC-TEC-test",
      verification_code: "TEST-CODE",
      signature: { status: "SIGNED", algorithm: "HAETAE-3" },
    },
  };
}
test("both bounded templates fit without dropping pages under long metadata, many failures, actions and events", () => {
  for (const method of ["submissionReport", "technicalReport"]) {
    const { c, pages } = context(),
      m = meta(),
      r = c.createRenderer(m),
      sample = item();
    c[method](r, sample, {
      meta: m,
      options: {
        applicant: "신청인".repeat(100),
        contactPhone: "010-0000-0000",
        submitTo: "제출처".repeat(100),
        purpose: "목적".repeat(200),
      },
      preview: null,
    });
    const result = r.finish();
    assert.equal(result.length, method === "submissionReport" ? 3 : 4);
    assert.ok(pages.every((p) => p.drawn.length > 0));
    const text = pages.flatMap((p) => p.drawn.map((t) => t.text)).join("\n");
    assert.match(text, /첨부/);
    assert.match(text, /HAETAE-3/);
    assert.match(text, /Classic 기록 복구/);
    assert.doesNotMatch(text, /참고문헌|https:\/\//);
  }
});
test("no-manifest and unavailable PQC produce two readable pages and never claim a passed signature", () => {
  const { c, pages } = context(),
    m = meta(),
    r = c.createRenderer(m);
  c.technicalReport(
    r,
    {
      filename: "plain.jpg",
      mime: "image/jpeg",
      size: 100,
      state: "NoManifest",
      checks: [],
      pqc_process: { status: "UNAVAILABLE", message: "서버 연결 실패" },
    },
    { meta: m, options: {} },
  );
  assert.equal(r.finish().length, 2);
  const text = pages.flatMap((p) => p.drawn.map((t) => t.text)).join("\n");
  assert.match(text, /서버 연결 실패/);
  assert.doesNotMatch(text, /서명·파일 결합 검사 통과|P1 클레임 서명.*통과/);
});
test("whole-file and signed-content hashes have distinct labels and grouping retains failure scope", () => {
  const { c } = context(),
    sample = item();
  assert.equal(c.contentHashes(sample.store.manifests["urn:c2pa:example"])[0][1], "c".repeat(64));
  sample.checks = [
    { kind: "failure", code: "assertion.dataHash.mismatch", scope: "activeManifest" },
    { kind: "failure", code: "assertion.dataHash.mismatch", scope: "activeManifest" },
    { kind: "failure", code: "assertion.dataHash.mismatch", scope: "ingredientDeltas" },
  ];
  const rows = c.compactChecks(sample);
  assert.equal(rows.length, 2);
  assert.match(rows[0][1], /×2/);
  assert.notEqual(rows[0][3], rows[1][3]);
});
test("small technical evidence shares a page with Classic details instead of adding a sparse code page", () => {
  const { c, pages } = context(),
    m = meta(),
    r = c.createRenderer(m);
  const sample = item();
  sample.filename = "image.png";
  sample.signature = { alg: "es256", common_name: "Signer", issuer: "Own CA" };
  sample.checks = [
    { kind: "success", code: "claimSignature.validated", scope: "activeManifest" },
    { kind: "success", code: "assertion.dataHash.match", scope: "activeManifest" },
  ];
  sample.software = [];
  sample.actions = [];
  sample.input_inspection = null;
  c.technicalReport(r, sample, { meta: m, options: {} });
  assert.equal(r.finish().length, 3);
  assert.match(pages[1].drawn.map((t) => t.text).join("\n"), /검증 상태 코드/);
});
test("a completed response with no P1 identity or binding identifier is still unverified in the PDF", () => {
  const { c } = context(),
    sample = item();
  delete sample.conversion_v4.result.p1_validation.manifest_id;
  assert.equal(c.pqEvidence(sample).status, "UNVERIFIED");
});
