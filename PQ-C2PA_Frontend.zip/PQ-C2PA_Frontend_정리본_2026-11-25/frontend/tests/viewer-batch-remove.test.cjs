// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm");
const src = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
function harness(count, active) {
  const nodes = new Map(),
    calls = { render: 0, intake: 0, toast: [], revoked: [] };
  const node = () => ({
    hidden: false,
    innerHTML: "",
    textContent: "",
    querySelector: () => null,
    getBoundingClientRect: () => ({ top: 0, bottom: 0, left: 0, right: 0 }),
    focus() {},
  });
  const $ = (name) => {
    if (!nodes.has(name)) nodes.set(name, node());
    return nodes.get(name);
  };
  const results = Array.from({ length: count }, (_, i) => ({
    id: `r${i}`,
    filename: `f${i}.png`,
    state: "Trusted",
    store: { active_manifest: `m${i}` },
  }));
  const state = {
    results,
    active,
    localUrls: new Map(results.map((r) => [r.id, `blob:${r.id}`])),
    explanations: new Map(results.map((r) => [`${r.id}:simple`, {}])),
    explainErrors: new Map(),
    selectedManifest: null,
    checkFilter: "warning",
  };
  const c = vm.createContext({
    $,
    state,
    esc: String,
    stateLabels: { Trusted: "신뢰 확인" },
    reportImages: new Map(),
    unifiedTasks: new Map(results.map((r) => [r.id, {}])),
    URL: { revokeObjectURL: (u) => calls.revoked.push(u) },
    toast: (m) => calls.toast.push(m),
    showIntake: () => calls.intake++,
    render: () => calls.render++,
    result: () => state.results[state.active],
  });
  vm.runInContext(
    src.slice(src.indexOf("function renderBatch("), src.indexOf("function renderVerdict(")),
    c,
  );
  return { c, state, calls, $ };
}
test("each analysis file row carries its own delete button next to the select button", () => {
  const { c, state, $ } = harness(3, 1);
  c.renderBatch();
  const html = $("#batch-list").innerHTML;
  assert.equal((html.match(/class="batch-item"/g) || []).length, 3);
  assert.equal((html.match(/data-remove-result="\d"/g) || []).length, 3);
  assert.match(html, /data-result-index="1"[^>]*>|class="active" data-result-index="1"/);
  assert.match(html, /aria-label="f2\.png 목록에서 삭제"/);
  assert.doesNotMatch(html, /<button[^>]*>[^<]*<button/);
});
test("deleting keeps the selected file when possible and releases its preview resources", () => {
  let h = harness(4, 2);
  h.c.removeResult(0);
  assert.deepEqual(
    h.state.results.map((r) => r.id),
    ["r1", "r2", "r3"],
  );
  assert.equal(h.state.active, 1);
  assert.equal(h.state.results[h.state.active].id, "r2");
  assert.deepEqual(h.calls.revoked, ["blob:r0"]);
  assert.equal(h.state.localUrls.has("r0"), false);
  assert.equal(h.state.explanations.has("r0:simple"), false);
  assert.equal(h.state.checkFilter, "warning");
  assert.equal(h.calls.render, 1);
  assert.match(h.calls.toast[0], /f0\.png/);
  h = harness(4, 3);
  h.c.removeResult(3);
  assert.equal(h.state.active, 2);
  assert.equal(h.state.selectedManifest, "m2");
  assert.equal(h.state.checkFilter, "all");
  h = harness(4, 1);
  h.c.removeResult(3);
  assert.equal(h.state.active, 1);
});
test("deleting the last file returns to the intake screen", () => {
  const h = harness(1, 0);
  h.c.removeResult(0);
  assert.equal(h.state.results.length, 0);
  assert.equal(h.calls.intake, 1);
  assert.equal(h.calls.render, 0);
  assert.equal(h.$("#file-count").textContent, "0개");
  h.c.removeResult(5);
  assert.equal(h.calls.intake, 1);
});
