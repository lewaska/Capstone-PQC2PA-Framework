// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path");
const root = path.join(__dirname, ".."),
  load = (name) =>
    import(
      "data:text/javascript;base64," +
        fs.readFileSync(path.join(root, "viewer", name)).toString("base64")
    );
const modulePromise = load("recovery-sample.js");
const png = fs.readFileSync(path.join(root, "assets/samples/c2pa-present.png"));
function chunks(bytes) {
  let pos = 8;
  const out = [];
  while (pos < bytes.length) {
    const end = pos + bytes.readUInt32BE(pos) + 12;
    out.push({ type: bytes.toString("ascii", pos + 4, pos + 8), bytes: bytes.subarray(pos, end) });
    pos = end;
  }
  return out;
}
const parts = chunks(png),
  metadata = parts.find((p) => p.type === "caBX").bytes;
test("PNG deletion preserves every other chunk and original source without changing image data", async () => {
  const { removePngC2pa } = await modulePromise,
    before = Buffer.from(png),
    result = Buffer.from(removePngC2pa(png));
  assert.deepEqual(png, before);
  assert.deepEqual(
    result,
    Buffer.concat([
      png.subarray(0, 8),
      ...parts.filter((p) => p.type !== "caBX").map((p) => p.bytes),
    ]),
  );
  assert.deepEqual(
    result,
    fs.readFileSync(path.join(root, "assets/samples/c2pa-recovery-demo.png")),
  );
  assert.ok(chunks(result).every((p) => p.type !== "caBX"));
  const padded = Buffer.concat([Buffer.alloc(7), png, Buffer.alloc(5)]);
  assert.deepEqual(Buffer.from(removePngC2pa(padded.subarray(7, -5))), result);
});
test("malformed, absent, duplicate or truncated metadata does not produce a demo image", async () => {
  const { removePngC2pa } = await modulePromise,
    stripped = removePngC2pa(png);
  const malformed = [
    Buffer.alloc(40),
    stripped,
    png.subarray(0, -2),
    Buffer.concat([png, Buffer.from([0])]),
    Buffer.concat([png.subarray(0, -12), metadata, png.subarray(-12)]),
  ];
  const badLength = Buffer.from(png);
  badLength.writeUInt32BE(0xffffffff, 8);
  malformed.push(badLength);
  for (const sample of malformed) assert.throws(() => removePngC2pa(sample));
});
