// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const src = fs.readFileSync(path.join(__dirname, "../viewer/pdf-report.js"), "utf8");
const context = vm.createContext({});
vm.runInContext(
  'const safe = (value, max=600) => String(value ?? "").replace(/[\\r\\t]+/g, " ").slice(0,max);',
  context,
);
vm.runInContext(
  src.slice(src.indexOf("const DECLARED_KEYS"), src.indexOf("const caseText")),
  context,
);
vm.runInContext(
  src.slice(
    src.indexOf("function declaredValues("),
    src.indexOf("export async function prepareIssuance"),
  ),
  context,
);
test("contact number appears as unverified in the PDF but is not included in issuance declaration data", () => {
  const options = { applicant: "테스트", contactPhone: "010-0000-1234", purpose: "검증 요청" };
  assert.match(context.requesterText(options), /010-0000-1234 \*/);
  assert.doesNotMatch(context.requesterText(options), /인증하지 않음/);
  const values = JSON.parse(JSON.stringify(context.declaredValues(options)));
  assert.deepEqual(values, { applicant: "테스트", purpose: "검증 요청" });
  assert.ok(!JSON.stringify(values).includes(options.contactPhone));
  assert.ok(!context.requesterText({ applicant: "테스트" }).includes("연락처"));
});

test("PDF describes absent embedded P1 as external DB not queried", () => {
  const ctx = vm.createContext({ terse: (s) => s });
  vm.runInContext(
    src.slice(src.indexOf("function pqConclusion("), src.indexOf("function notes(")),
    ctx,
  );
  assert.match(ctx.pqConclusion({ status: "NOT_PRESENT" }), /외부 DB.*조회하지 않아/);
  assert.match(ctx.pqConclusion({ status: "VALID" }), /외부 DB.*조회하지 않음/);
});

test("HTTP 405 from issuance is shown as unregistered and does not prevent report creation", async () => {
  const context = vm.createContext({
    postJSON: async () => {
      let error = new Error("Method Not Allowed");
      error.status = 405;
      throw error;
    },
  });
  const viewer = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
  vm.runInContext(
    viewer.slice(
      viewer.indexOf("async function requestIssuance("),
      viewer.indexOf("async function sealIssuance("),
    ),
    context,
  );
  const result = await context.requestIssuance(
    { prepareIssuance: async () => ({}) },
    {},
    "technical",
    {},
  );
  assert.equal(result.offline, true);
  assert.match(result.reason, /405/);
});
