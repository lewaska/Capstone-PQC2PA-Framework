// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm");
const source = fs
  .readFileSync(path.join(__dirname, "../viewer/pdf-report.js"), "utf8")
  .replace(/^import .*;$/gm, "")
  .replace(/^export \{.*\};$/gm, "")
  .replace(/^export /gm, "");
function fixture() {
  return {
    filename: "output.png",
    mime: "image/png",
    size: 80,
    sha256: "a".repeat(64),
    state: "Valid",
    trust_profile: "lab",
    processing_mode: "server",
    checks: [
      { kind: "success", code: "claimSignature.validated" },
      { kind: "success", code: "assertion.dataHash.match" },
    ],
    store: {
      active_manifest: "classic-id",
      manifests: {
        "classic-id": { assertions: [{ label: "c2pa.actions", data: { actions: [] } }] },
      },
    },
    signature: { common_name: "Classic signer", alg: "es256" },
    actions: [],
    ingredients: [],
    metadata: {},
    conversion_v4: {
      conversion_id: "conv_" + "a".repeat(32),
      status: "COMPLETED",
      result: {
        filename: "output.png",
        trust_status: "TRUSTED",
        classic_action: "REUSE_EXISTING",
        resolution_mode: "RESTORED_CLASSIC",
        manifest_pair_id: "pair_" + "b".repeat(32),
        fingerprint_base64: "AAQ=",
        validation_id: null,
        p1_validation: {
          profile: "pq-c2pa-jumbf-haetae3-1",
          container: "JUMBF",
          manifest_id: "p1-id",
          assertion_hashes: "VALID",
          ingredient_references: "VALID",
          source_evidence: "VALID",
          classic_validation: "SDK_VALIDATED",
          claim_signature: "VALID",
          hard_binding: "VALID",
          soft_binding: "VALID",
          signer: "FRAMEWORK_PINNED_SIGNER",
          timestamp: "M0_TOKEN_EXISTING",
          revocation: "NOT_CHECKED",
          conformance: "EXPERIMENTAL_PQ_PROFILE",
        },
      },
    },
  };
}
test("both report formats retain Classic sections and include detached V4 recovery and nullable registration evidence", () => {
  const context = vm.createContext({});
  vm.runInContext(source, context);
  for (const body of ["submissionReport", "technicalReport"]) {
    const calls = [];
    const renderer = new Proxy(
      {},
      {
        get:
          (_target, name) =>
          (...args) => {
            calls.push([name, args]);
            return 0;
          },
      },
    );
    context[body](renderer, fixture(), {
      options: { applicant: "신청인", contactPhone: "010-1234-5678" },
      meta: {
        docNo: "test",
        issued: new Date("2026-11-16T00:00:00Z"),
        issuedText: "시험 시각",
        issuedDot: "2026.11.16",
        issuedLong: "2026년 11월 16일",
        snapshotHash: "a".repeat(64),
      },
      env: {},
      preview: null,
      currentImage: null,
      manifestThumb: null,
    });
    const text = JSON.stringify(calls);
    assert.match(text, /Classic signer/);
    assert.match(text, /Classic C2PA/);
    assert.match(text, /PQC 보호 및 검사 실행 기록/);
    assert.match(text, /Classic 기록 복구 · 기존 P1 재사용/);
    assert.match(text, /pq-c2pa-jumbf-haetae3-1/);
    assert.match(text, /기존 M0 토큰 사용/);
    assert.match(text, /등록 검증 ID가 없거나 기록을 조회하지 못함/);
    assert.doesNotMatch(
      text,
      /이미지 내 P1 서명 검사|외부 DB 미조회|인증하지 않음|사용자 정의 Assertion\(org.pq-c2pa.p1\)/,
    );
  }
});
test("V4 report never treats incomplete or failed P1 checks as valid", () => {
  const c = vm.createContext({});
  vm.runInContext(source, c);
  const item = fixture();
  assert.equal(c.pqEvidence(item).status, "VALID");
  item.conversion_v4.result.p1_validation.source_evidence = "INVALID";
  assert.equal(c.pqEvidence(item).status, "INVALID");
  item.conversion_v4.result.p1_validation.source_evidence = undefined;
  assert.equal(c.pqEvidence(item).status, "UNVERIFIED");
});
test("both unified reports explain an unavailable PQC service without treating it as absent embedded P1", () => {
  const c = vm.createContext({});
  vm.runInContext(source, c);
  for (const body of ["submissionReport", "technicalReport"]) {
    const item = fixture();
    delete item.conversion_v4;
    item.filename = "input.png";
    item.pqc_process = { status: "UNAVAILABLE", message: "PQC 서버 연결 실패" };
    const calls = [];
    const renderer = new Proxy(
      {},
      {
        get:
          (_t, name) =>
          (...args) => {
            calls.push([name, args]);
            return 0;
          },
      },
    );
    c[body](renderer, item, {
      options: {},
      meta: {
        docNo: "test",
        issued: new Date("2026-11-16T00:00:00Z"),
        issuedText: "시험 시각",
        issuedDot: "2026.11.16",
        issuedLong: "시험",
        snapshotHash: "a".repeat(64),
      },
      env: {},
      preview: null,
      currentImage: null,
      manifestThumb: null,
    });
    const text = JSON.stringify(calls);
    assert.match(text, /Classic signer/);
    assert.match(text, /PQC 통합 처리 상태/);
    assert.match(text, /PQC 서버 연결 실패/);
    assert.match(text, /입력 이미지/);
    assert.doesNotMatch(text, /화면에서 검사한 P1은 이미지 내 기존 형식임|OpenSSL 3.5 이상 필요/);
  }
});
test("analysis has no applicant section and each report uses the selected photo timeline, not issuance time", () => {
  const c = vm.createContext({});
  vm.runInContext(source, c);
  const options = {
    applicant: "개인정보비밀",
    contactPhone: "010-0000-0000",
    submitTo: "기관비밀",
    purpose: "요청비밀",
  };
  const time = "2026-11-16T00:00:01.123Z",
    end = "2026-11-16T00:00:02.456Z";
  const item = fixture();
  item.verification_timing = { started_at: time, completed_at: end, clock_source: "server" };
  item.verification_run = {
    events: [
      {
        at: time,
        code: "RUN_STARTED",
        message: "선택한 사진만의 실행기록",
        filename: "output.png",
      },
    ],
  };
  assert.equal(JSON.stringify(c.analysisOptions(options)), "{}");
  for (const body of ["submissionReport", "technicalReport"]) {
    const calls = [];
    const r = new Proxy(
      {},
      {
        get:
          (_t, n) =>
          (...args) => {
            calls.push([n, args]);
            return 0;
          },
      },
    );
    c[body](r, item, {
      options,
      meta: {
        docNo: "test",
        issued: new Date("2026-11-17T00:00:00Z"),
        issuedText: "다음날 발급",
        issuedDot: "2026.11.17",
        issuedLong: "시험",
      },
      env: {},
    });
    const rendered = JSON.stringify(calls);
    assert.match(rendered, /선택한 사진만의 실행기록/);
    assert.match(rendered, /\.123/);
    assert.match(rendered, /\.456/);
    assert.match(rendered, /다음날 발급/);
    if (body === "technicalReport") {
      assert.doesNotMatch(rendered, /개인정보비밀|기관비밀|요청비밀|신청인/);
    } else assert.match(rendered, /개인정보비밀/);
  }
});
test("HAETAE reports do not describe the active P1 or report issuance as ML-DSA", () => {
  const c = vm.createContext({});
  vm.runInContext(source, c);
  const item = fixture();
  item.conversion_v4.result.p1_validation.signature_algorithm = "HAETAE-3";
  const issuance = {
    doc_no: "PQC-TEC-test",
    verification_code: "TEST-CODE",
    signature: { status: "SIGNED", algorithm: "HAETAE-3", public_key_sha256: "a".repeat(64) },
  };
  for (const method of ["submissionReport", "technicalReport"]) {
    const calls = [],
      r = new Proxy(
        {},
        {
          get:
            (_t, n) =>
            (...args) => {
              calls.push([n, args]);
              return 0;
            },
        },
      );
    c[method](r, item, {
      options: {},
      meta: {
        docNo: "PQC-TEC-test",
        issued: new Date(),
        issuedText: "server time",
        issuedDot: "date",
        issuedLong: "date",
        issuance,
      },
      env: {},
    });
    const text = JSON.stringify(calls);
    assert.match(text, /HAETAE-3/);
    assert.doesNotMatch(text, /P1, ML-DSA-65|발급 기록을 ML-DSA-65|발급 기록은 ML-DSA-65/);
  }
});
