// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm"),
  crypto = require("node:crypto");
const root = path.join(__dirname, ".."),
  source = fs.readFileSync(path.join(root, "viewer/viewer.js"), "utf8");
const expected = {
  absent: {
    file: "c2pa-absent.jpeg",
    filename: "C2PA 없음 샘플.jpeg",
    mime: "image/jpeg",
    sha: "a5188953e71c7d9e3dd6360252d457c6cd1cb357624506cf908edc1f92dd5f79",
  },
  present: {
    file: "c2pa-present.png",
    filename: "C2PA 있음 샘플.png",
    mime: "image/png",
    sha: "565ecf23ace5ac3e8e84de5bb1a002c3efe17f3abe6a87844dde028c44661f87",
  },
};
function harness(response) {
  const requests = [],
    files = [],
    errors = [],
    preparations = [],
    state = { busy: false };
  const ctx = vm.createContext({
    state,
    File,
    fetch: async (url, options) => {
      requests.push({ url, options });
      return response
        ? response(url)
        : {
            ok: true,
            blob: async () =>
              new Blob([fs.readFileSync(path.join(root, url.replace("/assets/", "assets/")))]),
          };
    },
    verifyFiles: async (batch, options) => {
      assert.equal(state.busy, false);
      files.push(batch);
      preparations.push(options);
    },
    error: (message) => errors.push(message),
    clearError() {},
    setBusy: (value) => {
      state.busy = value;
    },
    progress() {},
    startActivity() {},
    logActivity() {},
    unifiedReady: Promise.resolve(),
    v4Module: { createController() {}, canDownload() {} },
    v4Asset() {},
  });
  const excerpt = source.slice(
    source.indexOf("const SAMPLE_FILES ="),
    source.indexOf("async function loadReport("),
  );
  vm.runInContext(excerpt, ctx);
  return { ctx, requests, files, errors, state, preparations };
}
test("absent and present samples keep original bytes and use the ordinary upload flow", async () => {
  const h = harness();
  for (const [id, sample] of Object.entries(expected)) {
    await h.ctx.verifySample(id);
    const file = h.files.at(-1)[0];
    assert.equal(file.name, sample.filename);
    assert.equal(file.type, sample.mime);
    assert.equal(
      crypto
        .createHash("sha256")
        .update(Buffer.from(await file.arrayBuffer()))
        .digest("hex"),
      sample.sha,
    );
    assert.equal(h.requests.at(-1).url, "/assets/samples/" + sample.file);
    assert.equal(h.requests.at(-1).options.cache, "no-store");
  }
  assert.equal(h.errors.length, 0);
  assert.deepEqual(
    h.preparations.map((x) => x.sampleId),
    ["absent", "present"],
  );
});
test("deleted sample prepares a matching signed source and inspects its actual stripped bytes", async () => {
  const h = harness();
  await h.ctx.verifySample("removed");
  assert.equal(h.errors.length, 0);
  assert.equal(h.preparations[0].sampleId, "removed");
  assert.equal(h.requests[0].url, "/assets/samples/c2pa-recovery-demo.png");
  const file = h.files[0][0];
  assert.equal(file.name, "C2PA 삭제 복구 시연 샘플.png");
  assert.equal(file.type, "image/png");
  assert.equal(
    crypto
      .createHash("sha256")
      .update(Buffer.from(await file.arrayBuffer()))
      .digest("hex"),
    "a22e36f86355df45f6239f622b2666429b96c01b62cc59625c99dfb9e7c721ec",
  );
  assert.equal(
    crypto
      .createHash("sha256")
      .update(fs.readFileSync(path.join(root, "assets/samples/c2pa-removed.png")))
      .digest("hex"),
    "b01e3ea4177cf00169f97c4ac1381b30f25b3c8083e5c49f988ba5827536c8c8",
  );
});
test("sample fetch errors, empty files and failed preparation never launch inspection", async () => {
  for (const response of [{ ok: false }, { ok: true, blob: async () => new Blob([]) }]) {
    const h = harness(() => response);
    await h.ctx.verifySample("removed");
    assert.equal(h.files.length, 0);
    assert.equal(h.errors.length, 1);
    assert.equal(h.state.busy, false);
  }
});
test("sample buttons reject invalid ids and lock concurrent preparation", async () => {
  let release;
  const response = new Promise((resolve) => {
      release = resolve;
    }),
    h = harness(() => response);
  const first = h.ctx.verifySample("present");
  assert.equal(h.state.busy, true);
  await h.ctx.verifySample("removed");
  assert.equal(h.requests.length, 1);
  release({ ok: true, blob: async () => new Blob(["bytes"]) });
  await first;
  assert.equal(h.files.length, 1);
  assert.equal(h.state.busy, false);
  await h.ctx.verifySample("__proto__");
  assert.equal(h.requests.length, 1);
  assert.equal(h.errors.length, 1);
});
test("three sample cards explain real recovery preparation and the registry requirement", () => {
  const html = fs.readFileSync(path.join(root, "viewer/index.html"), "utf8");
  assert.deepEqual(
    [...new Set([...html.matchAll(/data-sample="([^"]+)"/g)].map((m) => m[1]))].sort(),
    ["absent", "present", "removed"],
  );
  assert.match(html, /C2PA 없는 이미지/);
  assert.match(html, /C2PA가 삭제된 이미지/);
  assert.match(html, /C2PA 있는 이미지/);
  assert.match(html, /임시 보호 기록으로 C2PA 삭제본을 실제로 복구/);
  assert.match(html, /샘플은 DB에 저장하지 않으며/);
  assert.match(html, /c2pa-recovery-demo\.png/);
});
