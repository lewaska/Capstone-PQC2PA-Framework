// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path");
const modulePromise = import(
  "data:text/javascript;base64," +
    fs.readFileSync(path.join(__dirname, "../viewer/conversion-v4.js")).toString("base64")
);
const id = "conv_" + "a".repeat(32),
  validationId = "val_" + "b".repeat(32);
const queue = () => ({
  conversion_id: id,
  status: "QUEUED",
  stage: "대기",
  progress_percent: 0,
  source: { filename: "private-name.png" },
  result: null,
  error: null,
});
function complete(mode = "ADD_SOFT_BINDING", withId = false) {
  return {
    ...queue(),
    status: "COMPLETED",
    stage: "완료",
    progress_percent: 100,
    result: {
      filename: "output.png",
      trust_status: "TRUSTED",
      validation_id: withId ? validationId : null,
      manifest_pair_id: "pair_" + "c".repeat(32),
      fingerprint_base64: "AAQ=",
      classic_action: mode,
      p1_validation: {
        profile: "pq-c2pa-jumbf-haetae3-1",
        container: "JUMBF",
        manifest_id: "urn:c2pa:test",
        assertion_hashes: "VALID",
        ingredient_references: "VALID",
        source_evidence: "VALID",
        classic_validation: "SDK_VALIDATED",
        claim_signature: "VALID",
        hard_binding: "VALID",
        soft_binding: "VALID",
        signer: "FRAMEWORK_PINNED_SIGNER",
        timestamp: "M0_TOKEN_EXISTING",
        revocation: "NOT_CHECKED",
        conformance: "EXPERIMENTAL_PQ_PROFILE",
      },
    },
  };
}
const file = () => new File(["fixture"], "input.png", { type: "image/png" });

test("temporary samples require all real validations and show fresh protection without a DB pair", async () => {
  const m = await modulePromise,
    job = complete();
  job.sample_id = "present";
  Object.assign(job.result, {
    storage_mode: "EPHEMERAL",
    sample_session_id: "sample_" + "d".repeat(32),
    manifest_pair_id: null,
  });
  assert.equal(m.canDownload(job), true);
  assert.equal(m.protectionStatus(job).kind, "created");
  assert.match(m.describeResolution(job)[0], /PQC 보호가 자동으로 생성되었습니다/);
  const html = m.renderResult(job, { actions: "unified" });
  assert.match(html, /샘플 임시 양자내성 기록/);
  assert.match(html, /영구 DB에는 저장하지 않습니다/);
  assert.doesNotMatch(html, />DB에 저장된 양자내성 기록/);
  job.result.p1_validation.hard_binding = "INVALID";
  assert.equal(m.canDownload(job), false);
  job.result.p1_validation.hard_binding = "VALID";
  delete job.sample_id;
  assert.equal(m.canDownload(job), false);
});

test("sample transport uses only the non-persistent POST and retains normal polling and validation", async () => {
  const m = await modulePromise,
    { sampleRequest } = await import(
      "data:text/javascript;base64," +
        fs.readFileSync(path.join(__dirname, "../viewer/sample-client.js")).toString("base64")
    );
  const calls = [],
    job = complete();
  job.sample_id = "present";
  Object.assign(job.result, {
    storage_mode: "EPHEMERAL",
    sample_session_id: "sample_" + "d".repeat(32),
    manifest_pair_id: null,
  });
  const request = sampleRequest("present", async (url, options) => {
    calls.push({ url, options });
    return { data: options?.method === "POST" ? { ...queue(), sample_id: "present" } : job };
  });
  const c = m.createController({ onChange() {}, onNotice() {}, request });
  await c.start(file());
  assert.equal(calls[0].url, "/api/v1/samples/present/conversions");
  assert.equal(calls[0].options.body, undefined);
  assert.equal(calls[1].url, `/api/v1/conversions/${id}`);
  assert.equal(c.getState().job, job);
  assert.ok(!calls.some((c) => c.url === "/api/v1/conversions"));
  assert.throws(() => sampleRequest("../x", () => {}));
});
test("single upload polls V4 until completion and constructs its own asset path", async () => {
  const m = await modulePromise,
    calls = [],
    states = [];
  let polls = 0;
  const controller = m.createController({
    onChange: (s) => states.push(s),
    onNotice() {},
    onInspect() {},
    delay: async () => {},
    request: async (url, options) => {
      calls.push({ url, method: options?.method });
      if (options?.method === "POST") return { data: queue() };
      return { data: ++polls === 1 ? { ...queue(), status: "PROCESSING" } : complete() };
    },
  });
  await controller.start(file());
  assert.equal(calls.filter((x) => x.method === "POST").length, 1);
  assert.equal(controller.getState().job.status, "COMPLETED");
  assert.equal(m.canDownload(controller.getState().job), true);
  assert.equal(m.assetPath(controller.getState().job), `/api/v1/conversions/${id}/asset`);
  assert.ok(states.some((s) => s.job?.status === "PROCESSING"));
});
test("FAILED is a job outcome and ambiguous matches do not offer download", async () => {
  const m = await modulePromise,
    notices = [];
  const failed = {
    ...queue(),
    status: "FAILED",
    error: { code: "AMBIGUOUS_MATCH", message: "후보가 여러 개입니다" },
  };
  const c = m.createController({
    onChange() {},
    onNotice: (...x) => notices.push(x),
    request: async (_u, o) => ({ data: o?.method === "POST" ? queue() : failed }),
  });
  await c.start(file());
  assert.match(notices[0][0], /AMBIGUOUS_MATCH/);
  assert.equal(m.canDownload(c.getState().job), false);
});
test("registration record is separate from current reuse and AI uses only observed evidence", async () => {
  const m = await modulePromise,
    job = complete("EXISTING_SOURCE", true);
  job.result.resolution_mode = "EXISTING_SOURCE";
  const record = {
    validation_id: validationId,
    overall_status: "TRUSTED",
    report: { private: "omit" },
    checks: [],
    timestamp_evidence: [],
  };
  const c = m.createController({
    onChange() {},
    onNotice() {},
    request: async (url, o) => ({
      data: o?.method === "POST" ? queue() : url.includes("/validations/") ? record : job,
    }),
  });
  await c.start(file());
  assert.equal(c.getState().record, record);
  const html = m.renderResult(job, { record });
  assert.match(html, /새 P1을 발급하지 않았습니다/);
  assert.match(html, /기존 발급 때 저장된 기록/);
  assert.match(html, /기존 M0 토큰 사용/);
  const sent = JSON.stringify(m.aiEvidence(job, record));
  assert.ok(!sent.includes("private-name"));
  assert.ok(!sent.includes('"private"'));
  assert.match(sent, /EXISTING_SOURCE/);
});
test("network recovery resumes GET without reuploading and rejects legacy profile", async () => {
  const m = await modulePromise;
  let uploads = 0,
    fail = true;
  const c = m.createController({
    onChange() {},
    onNotice() {},
    request: async (_u, o) => {
      if (o?.method === "POST") {
        uploads++;
        return { data: queue() };
      }
      if (fail) throw Error("network");
      return { data: complete() };
    },
  });
  await c.start(file());
  assert.equal(c.getState().paused, true);
  fail = false;
  await c.resume();
  assert.equal(uploads, 1);
  assert.equal(c.getState().job.status, "COMPLETED");
  assert.throws(
    () =>
      m.readJob({
        data: { ...complete(), result: { p1_validation: { profile: "PQ-C2PA-P1-JSON-v1" } } },
      }),
    /지원하지 않는 P1/,
  );
});
test("unexpected validation state blocks download, HTML is escaped and timestamp is not a date", async () => {
  const m = await modulePromise,
    job = complete();
  job.source.filename = "<img src=x>";
  job.result.p1_validation.hard_binding = "INVALID";
  assert.equal(m.canDownload(job), false);
  const html = m.renderResult(job);
  assert.match(html, /&lt;img src=x&gt;/);
  assert.doesNotMatch(html, /<img src=x>/);
  assert.match(html, /토큰 발급 시각이 아닙니다/);
  assert.match(html, /P1은 결과 이미지 안에 삽입되지 않습니다/);
});
test("existing P1 records are distinguished from a reused Classic manifest and restored records", async () => {
  const m = await modulePromise;
  for (const action of ["ADD_SOFT_BINDING", "REUSE_EXISTING"]) {
    const job = complete(action),
      html = m.renderResult(job);
    assert.equal(m.protectionStatus(job).kind, "created");
    assert.match(html, /PQC 보호 기록을 자동으로 생성했습니다/);
    assert.doesNotMatch(html, /이미 PQC로 보호된 이미지입니다|새 P1을 발급하지 않았습니다/);
  }
  for (const mode of ["EXISTING_OUTPUT", "EXISTING_SOURCE"]) {
    const job = complete("ADD_SOFT_BINDING");
    job.result.resolution_mode = mode;
    const html = m.renderResult(job);
    assert.equal(m.protectionStatus(job).kind, "existing");
    assert.match(html, /이미 PQC로 보호된 이미지입니다|PQC 보호 기록이 이미 있습니다/);
    assert.match(html, /새 P1을 발급하지 않았습니다/);
    assert.doesNotMatch(html, /PQC 자동 생성 완료/);
  }
  const restored = complete("ADD_SOFT_BINDING");
  restored.result.resolution_mode = "RESTORED_CLASSIC";
  assert.equal(m.protectionStatus(restored).kind, "restored");
  assert.equal(m.describeResolution(restored)[0], "C2PA 출처 기록을 복구했습니다");
  assert.match(m.renderResult(restored), /복구 결과 확인이 필요합니다/);
});
test("failed or unverified existing-record responses never claim PQC protection or creation", async () => {
  const m = await modulePromise;
  for (const state of ["FAILED", "PROCESSING", "invalid-binding", "untrusted"]) {
    const job = complete();
    job.result.resolution_mode = "EXISTING_OUTPUT";
    if (state === "invalid-binding") job.result.p1_validation.hard_binding = "INVALID";
    else if (state === "untrusted") job.result.trust_status = "UNKNOWN";
    else job.status = state;
    assert.equal(m.protectionStatus(job).kind, "unknown");
    const description = m.describeResolution(job).join(" ");
    assert.match(description, /보호를 확인하지 못했습니다/);
    assert.doesNotMatch(description, /이미 PQC로 보호된|자동으로 생성했습니다|재검증했습니다/);
  }
});
