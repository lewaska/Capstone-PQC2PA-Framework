// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path"),
  vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
const conversion =
  "data:text/javascript;base64," +
  fs.readFileSync(path.join(__dirname, "../viewer/conversion-v4.js")).toString("base64");
const pipeline = fs
  .readFileSync(path.join(__dirname, "../viewer/unified-processing.js"), "utf8")
  .replace(/["']\.\/conversion-v4\.js\?v=[^"']+["']/, JSON.stringify(conversion));
const modulePromise = import(
  "data:text/javascript;base64," + Buffer.from(pipeline).toString("base64")
);
const id = "conv_" + "a".repeat(32);
const queue = () => ({ conversion_id: id, status: "QUEUED", result: null });
function complete(mode = "ADD_SOFT_BINDING") {
  return {
    ...queue(),
    status: "COMPLETED",
    result: {
      filename: "output.png",
      trust_status: "TRUSTED",
      classic_action: mode,
      manifest_pair_id: "pair_" + "b".repeat(32),
      fingerprint_base64: "AAQ=",
      p1_validation: {
        profile: "pq-c2pa-jumbf-haetae3-1",
        container: "JUMBF",
        manifest_id: "urn:c2pa:test",
        assertion_hashes: "VALID",
        ingredient_references: "VALID",
        source_evidence: "VALID",
        classic_validation: "SDK_VALIDATED",
        claim_signature: "VALID",
        hard_binding: "VALID",
        soft_binding: "VALID",
        signer: "FRAMEWORK_PINNED_SIGNER",
        conformance: "EXPERIMENTAL_PQ_PROFILE",
      },
    },
  };
}
const input = () => new File(["original"], "input.png", { type: "image/png" });
const output = () => new File(["protected"], "output.png", { type: "image/png" });
const inspect = async (file) => ({
  filename: file.name,
  sha256: await file.text(),
  state: "Valid",
  store: { original_metadata: file.name },
  checks: [{ code: "claimSignature.validated" }],
});
const request = async (_url, o) => ({ data: o?.method === "POST" ? queue() : complete() });
test("every file selection opens the preview automatically without starting an upload", () => {
  const calls = [];
  const ctx = vm.createContext({ stageFiles: (files) => calls.push(files) });
  vm.runInContext(
    source.slice(source.indexOf("function intakeFiles("), source.indexOf("function validRemote(")),
    ctx,
  );
  const files = [input()];
  ctx.intakeFiles(files);
  assert.equal(calls.length, 1);
  assert.equal(calls[0][0], files[0]);
});
test("Classic and PQC run together; final metadata and hash refer to the protected output", async () => {
  const { createUnifiedTask } = await modulePromise;
  let classicStarted = false,
    posts = 0;
  const task = createUnifiedTask({
    inspect: async (file) => {
      classicStarted = true;
      return inspect(file);
    },
    loadAsset: async () => output(),
    delay: async () => {},
    request: async (url, o) => {
      if (o?.method === "POST") {
        assert.equal(classicStarted, true);
        posts++;
      }
      return request(url, o);
    },
  });
  const { item, file } = await task.start(input());
  assert.equal(posts, 1);
  assert.equal(file.name, "output.png");
  assert.equal(item.sha256, "protected");
  assert.equal(item.store.original_metadata, "output.png");
  assert.equal(item.input_inspection.sha256, "original");
  assert.equal(item.input_inspection.store.original_metadata, "input.png");
  assert.equal(item.conversion_v4.status, "COMPLETED");
});
test("unconfigured PQC service preserves the full Classic result without claiming protection", async () => {
  const { createUnifiedTask } = await modulePromise;
  const task = createUnifiedTask({
    inspect,
    loadAsset: () => assert.fail("must not download"),
    request: async () => {
      throw Error("PQC 서버가 연결되지 않았습니다.");
    },
  });
  const { item, file } = await task.start(input());
  assert.equal(file.name, "input.png");
  assert.equal(item.store.original_metadata, "input.png");
  assert.equal(item.checks.length, 1);
  assert.equal(item.conversion_v4, undefined);
  assert.equal(item.pqc_process.status, "UNAVAILABLE");
  assert.match(item.pqc_process.message, /연결되지/);
});
test("privacy, browser and oversized-file skip preserve Classic without sending a PQC request", async () => {
  const { createUnifiedTask } = await modulePromise;
  for (const skipReason of ["브라우저 전용", "기록 저장 안 함", "20 MiB 초과"]) {
    const task = createUnifiedTask({
      inspect,
      skipReason,
      request: () => assert.fail("PQC request forbidden"),
      loadAsset: () => assert.fail("download forbidden"),
    });
    const { item } = await task.start(input());
    assert.equal(item.pqc_process.status, "SKIPPED");
    assert.equal(item.pqc_process.message, skipReason);
    assert.equal(item.state, "Valid");
  }
});
test("failed or unverified jobs retain input inspection and never download a result", async () => {
  const { createUnifiedTask } = await modulePromise;
  const invalid = complete();
  invalid.result.p1_validation.hard_binding = "INVALID";
  for (const job of [
    { ...queue(), status: "FAILED", error: { code: "INVALID_C2PA", message: "C2PA 검증 실패" } },
    invalid,
  ]) {
    const task = createUnifiedTask({
      inspect,
      loadAsset: () => assert.fail("unverified download"),
      request: async (_u, o) => ({ data: o?.method === "POST" ? queue() : job }),
    });
    const { item } = await task.start(input());
    assert.equal(item.conversion_v4, undefined);
    assert.equal(item.sha256, "original");
    assert.equal(item.pqc_process.job, job);
    assert.ok(item.pqc_process.message);
  }
});
test("existing source and restoration return the existing protected asset and preserve original evidence", async () => {
  const { createUnifiedTask } = await modulePromise;
  for (const resolution_mode of ["EXISTING_OUTPUT", "EXISTING_SOURCE", "RESTORED_CLASSIC"]) {
    const job = complete();
    job.result.resolution_mode = resolution_mode;
    const task = createUnifiedTask({
      inspect,
      loadAsset: async () => output(),
      request: async (_u, o) => ({ data: o?.method === "POST" ? queue() : job }),
    });
    const { item } = await task.start(input());
    assert.equal(item.conversion_v4.result.resolution_mode, resolution_mode);
    assert.equal(item.sha256, "protected");
    assert.equal(item.input_inspection.sha256, "original");
  }
});
test("GET retry resumes the same job without a second upload and updates the protected output", async () => {
  const { createUnifiedTask } = await modulePromise;
  let fail = true,
    uploads = 0;
  const task = createUnifiedTask({
    inspect,
    loadAsset: async () => output(),
    request: async (_u, o) => {
      if (o?.method === "POST") {
        uploads++;
        return { data: queue() };
      }
      if (fail) throw Error("connection lost");
      return { data: complete() };
    },
  });
  const first = await task.start(input());
  assert.equal(first.item.pqc_process.paused, true);
  assert.equal(first.item.sha256, "original");
  fail = false;
  const next = await task.resume();
  assert.equal(uploads, 1);
  assert.equal(next.item.sha256, "protected");
  assert.equal(next.item.pqc_process.paused, false);
});
test("asset download failure does not attach output verification to the input bytes", async () => {
  const { createUnifiedTask } = await modulePromise;
  const task = createUnifiedTask({
    inspect,
    request,
    loadAsset: async () => {
      throw Error("download unavailable");
    },
  });
  const { item, file } = await task.start(input());
  assert.equal(file.name, "input.png");
  assert.equal(item.conversion_v4, undefined);
  assert.equal(item.pqc_process.status, "OUTPUT_UNAVAILABLE");
  assert.match(item.pqc_process.message, /입력 이미지/);
});
test("Classic service failure does not prevent server-side V4 validation and output inspection", async () => {
  const { createUnifiedTask } = await modulePromise;
  const task = createUnifiedTask({
    inspect: async (file) => {
      if (file.name === "input.png") throw Error("Classic service unavailable");
      return inspect(file);
    },
    request,
    loadAsset: async () => output(),
  });
  const { item } = await task.start(input());
  assert.equal(item.input_inspection.state, "Error");
  assert.equal(item.state, "Valid");
  assert.equal(item.conversion_v4.status, "COMPLETED");
});
test("each photo owns its timestamps; retry does not alter an earlier report snapshot", async () => {
  const { createUnifiedTask } = await modulePromise;
  let tick = 0,
    fail = true;
  const now = () => new Date(Date.UTC(2026, 10, 16, 1, 0, tick++)).toISOString();
  const make = () =>
    createUnifiedTask({
      inspect: async (file) => ({
        ...(await inspect(file)),
        verification_timing: {
          started_at: "2026-11-16T00:00:00.111Z",
          completed_at: "2026-11-16T00:00:00.222Z",
          clock_source: "server",
        },
      }),
      now,
      loadAsset: async () => output(),
      request: async (_u, o) => {
        if (o?.method === "POST") return { data: queue() };
        if (fail) throw Error("lost");
        return { data: complete() };
      },
    });
  const a = make(),
    b = make(),
    first = await a.start(input()),
    second = await b.start(new File(["second"], "second.png", { type: "image/png" }));
  assert.notEqual(first.item.verification_run.started_at, second.item.verification_run.started_at);
  assert.equal(first.item.verification_run.input_filename, "input.png");
  assert.equal(second.item.verification_run.input_filename, "second.png");
  assert.equal(
    first.item.verification_run.events.some((e) => e.filename === "second.png"),
    false,
  );
  const original = JSON.stringify(first.item.verification_run);
  fail = false;
  const retried = await a.resume();
  assert.equal(JSON.stringify(first.item.verification_run), original);
  assert.equal(retried.item.verification_run.started_at, first.item.verification_run.started_at);
  assert.notEqual(
    retried.item.verification_run.completed_at,
    first.item.verification_run.completed_at,
  );
  assert.ok(retried.item.verification_run.events.some((e) => e.code === "PQC_RESUME"));
  assert.ok(
    first.item.verification_run.events.some(
      (e) => e.server_timing?.completed_at === "2026-11-16T00:00:00.222Z",
    ),
  );
});
