// 회귀 검사: 이 파일이 담당하는 기능의 실제 반환값·상태·화면 출력을 확인한다.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const source = fs.readFileSync(path.join(__dirname, "../viewer/viewer.js"), "utf8");
const context = vm.createContext({});
vm.runInContext(source.slice(0, source.indexOf("const glossary =")), context);
vm.runInContext(
  source.slice(
    source.indexOf("const HISTORY_ACTIONS ="),
    source.indexOf("function renderPqResult("),
  ),
  context,
);
vm.runInContext("function renderJsonBox(label){ return label; }", context);
vm.runInContext(
  source.slice(
    source.indexOf("function renderHistory("),
    source.indexOf("function renderManifest("),
  ),
  context,
);
const item = () => ({
  state: "Trusted",
  store: { active_manifest: "m1", manifests: { m1: { title: "사진" } } },
  actions: [
    {
      action: "c2pa.opened",
      softwareAgent: { name: "<도구>", version: "1.0" },
      when: "2026-01-01T00:00:00Z",
    },
  ],
  ingredients: [{ title: "이전 파일", relationship: "parentOf" }],
});
test("explains recorded opening without claiming the file was edited and safely displays original data", () => {
  const html = context.renderHistory(item());
  assert.match(html, /파일 열기/);
  assert.match(html, /수정되었다는 뜻은 아닙니다/);
  assert.match(html, /&lt;도구&gt;/);
  assert.doesNotMatch(html, /<도구>/);
  assert.match(html, /이전 단계로 연결됨/);
  assert.match(html, /2026-01-01T00:00:00Z/);
  assert.match(html, /시간순이나 전체 과정을 보장하지 않습니다/);
  assert.match(html, /재료의 원본 기록 보기/);
});
test("unreadable provenance is distinct from a readable record with no recorded actions", () => {
  assert.match(
    context.renderHistory({ state: "Error", store: {}, actions: [], ingredients: [] }),
    /기록을 읽지 못해 제작·편집 작업을 확인할 수 없습니다/,
  );
  assert.match(
    context.renderHistory({ state: "NoManifest", store: {}, actions: [], ingredients: [] }),
    /C2PA 출처 기록을 찾지 못해 작업 이력을 볼 수 없습니다/,
  );
  const present = item();
  present.actions = [];
  present.ingredients = [];
  const html = context.renderHistory(present);
  assert.match(html, /편집이 없었다고 판단할 수는 없습니다/);
  assert.match(html, /재료를 사용하지 않았다는 뜻은 아닙니다/);
});
test("failed verification warns that the displayed contents need further review", () => {
  const untrusted = item();
  untrusted.state = "Invalid";
  assert.match(context.renderHistory(untrusted), /검증에 실패한 항목/);
});
test("unknown action names do not acquire a made-up interpretation", () => {
  const data = item();
  data.actions = [{ action: "unknown.action" }];
  const html = context.renderHistory(data);
  assert.match(html, /기타 기록된 작업/);
  assert.match(html, /unknown.action/);
  assert.match(html, /자세히 해석할 수 없습니다/);
});
